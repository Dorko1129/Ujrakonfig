`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/12/2026 12:32:53 PM
// Design Name: 
// Module Name: rom_module
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module rom_module(
input wire[2:0] address,
output wire[7:0] data

    );
    
    reg [7:0] rom [0:7];
    parameter init_data=64'h00C8F9AF64956CD4;
    
    integer i;
    
    initial
    begin
        for(i=0;i<8;i=i+1)
            rom[i] = init_data [63-i*8 -:8];
    end
    
    assign data = rom[address];
    
endmodule
