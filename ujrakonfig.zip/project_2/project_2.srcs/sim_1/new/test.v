`timescale 1ns / 1ps

module test;
    input clk;
    input [3:0] addr;
    output [7:0] spo;
    
    EX28_top EX28(.clk(clk),.(addr),.spo(spo));
    
    initial begin
    clk = 0;
    addr = 0;
    #100;
    
    always@(*)
        begin
            #50;
            clk <= ~clk;
        end
    
    always@(clk)
        begin
            addr = addr + 1;
        end
endmodule
S
