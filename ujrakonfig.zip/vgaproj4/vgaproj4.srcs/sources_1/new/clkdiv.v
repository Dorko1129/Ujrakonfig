`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/02/2026 10:35:51 AM
// Design Name: 
// Module Name: clkdiv
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clkdiv(
        input wire clk,
        input wire clr,
        output wire clk190,
        output wire clk25m,
        output wire clk3
    );
    
    reg[24:0] q;
    always @(posedge clk or posedge clr)
       begin
         if (clr==1)
            q<=0;
         else
            q <= q + 1;
       end
    assign clk190=q[18];
    assign clk25m=q[1];
    assign clk3=q[24];
endmodule
