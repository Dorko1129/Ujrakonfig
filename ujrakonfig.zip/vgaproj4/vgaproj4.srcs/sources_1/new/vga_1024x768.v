`timescale 1ns / 1ps

module vga_1024x768 (
    input wire clk,
    input wire clr,
    output reg hsync,
    output reg vsync,
    output reg [10:0] hc,
    output reg [10:0] vc,
    output reg vidon
);

// Pixel count per horizontal line: 1024 + 24 + 136 + 160 = 1344
parameter hpixels = 11'b10101000000;

// Number of vertical lines: 768 + 3 + 6 + 29 = 806
parameter vlines = 11'b01100100110;

// Horizontal back porch = 296 (136 + 160)
parameter hbp = 11'b00100101000;

// Horizontal front porch = 1320 (136 + 160 + 1024)
parameter hfp = 11'b10100101000;

// Vertical back porch = 35 (6 + 29)
parameter vbp = 11'b00000100011;

// Vertical front porch = 803 (6 + 29 + 768)
parameter vfp = 11'b01100100011;

// Enable horizontal counter
reg vsenable;


always@(*)
   begin
      if ( hc < 136)
         hsync=0;
      else
         hsync=1;
   end
   
   
always@(*)
     begin
        if (vc<6)
           vsync=0;
        else
           vsync=1;
      end

endmodule
