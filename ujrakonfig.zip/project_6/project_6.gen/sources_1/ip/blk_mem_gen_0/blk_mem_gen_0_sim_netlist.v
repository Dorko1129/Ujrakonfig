// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Mon Oct 26 12:57:05 2026
// Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/student/Documents/zsombor/project_6/project_6.gen/sources_1/ip/blk_mem_gen_0/blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_5,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_5,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module blk_mem_gen_0
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [2:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [2:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [2:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [2:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "3" *) 
  (* C_ADDRB_WIDTH = "3" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     2.87285 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "1" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "8" *) 
  (* C_READ_DEPTH_B = "8" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "8" *) 
  (* C_WRITE_DEPTH_B = "8" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  blk_mem_gen_0_blk_mem_gen_v8_4_5 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[2:0]),
        .regcea(1'b0),
        .regceb(1'b0),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[2:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
VHPlDkoDlWlBfBMvPBmGYmaek3s9hXXhjF28kllYPnaNm3TSnzzpXHWHc8Ye9/2L2yiQfJ1hTWou
Ia/zeQ8h9/dtr6QB5YkyW4wlb/LbMgXb+DGIXPSllNl0IMsRQIcQDbcQm1bO/nlhb+2pjxiuaQrl
DbvxoDwPs7z3LunRxsg=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lmIhoX8hXuc7tNV1sXY1K2/gXL7Y7Hq73qQF7+x03UWWTRd3uhGmVQtOMVbhIW+66UkWUHiD26zL
fzqGor8bgSNGpSFyS11k4TwLQT4OfAMGO8C9Qmmh4+VENBnpS9TW+wHzCv8oUwht7xYtYRZvOvYK
F3fMppz2sBkUd1lciw98ZE/UmNkhqBuMfIYF43j45DEJ55PBhOZNg91Ls4v3qBHyBAaYPFFoMry3
d5Fw1PZyFQSEOSSpwgyds2aN0g6oIwl7zm0LJrM9VDAOxBUE50hk+oHr4jj8J8UhHQJnlEHm1Idm
rvxKygNKRvfSpa90NYxZJFYgqnrMYg+19+9aZA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
VkyCjO2onoeZWEoYQ/4ue7X5mkHyTYVW9xjdoTsGS4GdP/Q64VaCZL/jr6R8DVDXPMnH7tRMrDpo
jpYBnyzSgOkfgqM+96ioC2fDyAaG4gYgGLmrBR6qK3/mxXwAZZX+GJ9R/eWXkc9h8xN+gsSSX6/M
jIQCgeT6q7PB4dWT6KY=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iub91V+TnhVlZCSLu6iKmFjix71y6/l83OPTs8uewWvkE7WcqYxEKi9fonXEkzAtWzuKwEUqnOlN
VBsNJqPUdKcd22q523mrdt89mpdosWD+hvZdO7ELhJniY5u9h49FFkubpN2JiUTcIcKEYxVNlds4
wyvaYUqbPVH5v2ooJwDdimS4GVn9HerCOgPwfshvQDNlMTxLcYju4v8BHMc5Rub9Q/ihvpQU74v2
ouZ9XIwA+C6pBLwvaqS8jE7HXOokgqJilaX/W/t+KEgiFry/txRTMU9WMD7tCN7lcfjCydmS3Lq+
3u6Hsr0S8BwNjcaDpZDnBTygUJd4JSqREnk33w==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
U46EWFmKmpZGaWfyL+dokyQtJtaOYsa7HCW/+fdtw9/yHKTWFpmqKBZngBj5rPkNhtTDDCJkqsYj
tUXg1j4tgIBaCQn9B0q/aG+B3gPLrudp9hLL25mVbsfiTzdekiV2hJMmhuMoavKKPJHC6zyW7kZi
80er82OQy8h+Df/fe6TRjH9xEt3/b80tRKUMbxkLfnnkAyyf1KfOhB6/uyI4mwXuQR+DsAbzybKR
YtXpOiW72tGrXTFlzcwbHamWZefqsilVpBw6V5dh33vYKGx50xwWpj76maAkpQrOpB7zufeldJe4
W1UOEN84AZdRTLkVSxamWo/wp8nP9fiGS/ItRw==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
qczgIJYpE/SzErzK7eWJBGcDFEzDLm8cKbwJbPXuM6YnJxx44W+E60R3war7K2QGFAkOoCDUtDC7
SghJGF32btaDLzeKm0tQ669sBtQmMIaBrlt7I9QBkNM8zN9GL92qxNC9o3UVWMOYy5BmH8nUPgcE
O6lRubeltlrTuDe7UJQ2nEPHcXjpUJJ8dxktyW+LovBy1OxW8g4GRAsmEJsoOEg0HuDdWcc4IshJ
PvwPJ7LblELAKsdkSt65y9VaklaEm7MlH4ImlgIa74TgRmutLUbWxM1QYhGE5rAzFhGU5i3RJOdx
L3N7GGGvLMW2z9NSHbIFX+/eNII9fNJ9nZbgLA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ti1NUgDv8YPk90APMwfu/mRr38QYwAxZfv0T6zQ89YS55t2EquEGVqrEafYX6rTydLOw8le1Oucv
f2oERpSSSTih/ScZneSZmuPE/Zh2BU1Ajv0j+/+0uEWXU+5lLPbDJjnapTmJXih1MYPf0SHpZZmE
BKj2IEBI9MPZlh6bxpa5BWJnyPdAvHf+UNaMXU9+pmbtrzUVebql4mFJu45Z3+ehmFY4FBW3zXMF
44C4TlHACLwL3vHVMCVfeKhgdVDbpE+/IFhTStz7mZ9h9RKGanQcs6YDVM1R+2RKA1QT1fX4FiQc
1V+FGmrm1ujxmFGXwpfNKByVlfCY0oWhRJCYYQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HuEXFK0NXt09xU2yxxjng1OLsT+ZEM4EhqBgpr9D2ljw2vDaMBrqEsRQTc2B9soDq3ewDduHJXBd
OGYxkPnoN6LhjULtB2nTgjcH6NxA4puZ1ZNcndDndVBo8rTW5W1OqHq6InAG0CqPpTIkuqz3ECPl
EysI++MCDfH6tIzlekxJFIJ1McJsTq5rFuLzMMcrmkBxgcayDpOcCFuzZzCczxmt/cCCIKmDybwT
OQXmOcLJoYLP4sFu6R9c6xO8i6p++crv2N3eIxZHKbek9xBBZqQM9EYuEtsbkqAs9XZpa16i5njR
BDFxTKcP6r7JgFALJE89AZhBbate5JXWp0v4ECZD18aEL17CipwcWPutNMdG1apzSPP5y59n7rMG
yxBPz1gKHc3Emkl4WcO0hjICxqmO6dMXoY8JvBSf6ry2l0sH9Ihr3Bq5WWmlhPHnoaNr5jl//vNe
KfToWtn97eoVSt1LnmXXnSpdigbHr0UIg8AdkpdkuNRaWdVicDdgSo49

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mokwst2bn6UxD6V9UdIgCIG1QQ/d0FiJqYGOTI2eHPV6YElaLjnJ8DnQmZnGS95o3x93FDOoa58C
RwYsX1fVoVtXkj1LuZq0k7q9vEe4T8xMjpkeYtIHY9k0Xhy1Lq/xRlfzGAf9fvf9e+f4r7aR/Sb/
uCZxxugG5niTwLENY1n3NthYL0jvo8Fmdw4Qg0nTCGWlVCws+09K0g9/lx6I9EcuHHemcHO3fOZG
lMc4NaPNozKwnyDMoWUkwiVxyFEPFaQLNYqzjvR+CqrWfhFLo96JWhL+eaDoNuZoBVYQtNH5ZwBL
BoO27Pw10lgcReGlZBz3BLO7T4ddynCx0+eSnw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
PiP7AjOQqqouyQMoBQqgWIDhUSViq94rIvGiIJ/UKMDspM/yXw1caE8AhWHTjYckC4yLpPAz5P6s
1Z6flzDPrzVwg4e59X2cc4IMCHhedna0rDO804njcc6amRDTeLsMLTkWfvomB4xwszm2AgT+PRnB
WHd09ZUDVFjiBXT+Oa9AicgGJHrX3w823yBPuAa704kje/SzgtiDpcTU1eLmLhLW7LpEd9KIHd9s
ER7Uk9Orws0Kq9PMTqMX4hMn5K5mFakOeOURiEbUjdv5RiIJ2g/PlQXSItM8fHsBTQa6fOaJwQTI
vHwK3a8ZBHpfT1YH+n7wNiNUZwD4SFXm1QVx4g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ul5ZfTHJwMctaNhYRortUZizYMPYRef7uYqPSuMkxsArnxI/cjGh+KRMwzV86hyp/6TXSJIjm5ec
2wX2UONdPN+DOJ84jYC4JbgJQrPnTj7ioD8uLX/WlyPcQzyF5keqFgj5eR5s13FskVWCuAWf5m9w
mhFEKFjVXDAr7gVgAJh/hL8P6Psrnf+LGfiM8JhnDepsHEYykGlpD3fzru2BGgqHWqPqFMcnyVGl
vysaIXiJz/eYKvO8RGcgd3DJAM/wPm9A0m/DWcmSnczOgTjoqkHcBg2H5uJMLvufzmjImi6LYEqq
v04ESDEN31cSUzqUYcayvMFOnI/WNsWbFIa5+Q==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 20176)
`pragma protect data_block
8e7KAANf9iCWYQHY47Hth7PorVd2FF4ixd00/TqUYPm7lTxck3J7PWwhCI48AfU0IqxgI/NpEX3r
sc3eIhqQKfjg67xd26XIJXeURvWI8zVRz0H1KWzOopxoMfL9W39sGthbY9+mX+StCRLxHkGScuQJ
2LrKl5zf8TapCvQbqRGudte74SkCK22iftohg9vEOLDzSEfLr/pv1v35URNmCIr8qbJP1d4uDy3Z
Lyv0Q8Y1ShlL2LLCs4MS5DX7D9zqMGdC44GzC6jcH/O7l7OpAug20f40uqkTbKXZwYP5jcG218Vj
rRTT2hfn6ZXJX3uZk1ZgFRgoek5VajtP1ESjc7fTzbBoegFBVo1O7DlVCFeYWvQJ+3b+QAKFP4bQ
rgt2FhOzBzRUCWGOZ+Vk6ewhDmpAcArq/UTfVtLRbtkgKajDp4llhI+I0UFd1BmfPTUUF+HmbZw7
JwzQuYZu6/0HUFQp9D8A6X93Xp+r2M5zBYJ8dSyF4M8Dg5czZezZCIDIJe+u1f7ieG0B5SpuRC9B
Q5KQD31UW0qx4nIbwheEK9BVXlvt0KL54NMJn7zgOMf975yCTcS6EUr+VMc15KrAPX8ezAOQJfg4
DzYz8N4AK/dupK3LVQm5pvCr+0VAn/4sdqEr1xYMfhkG3hYWUvwX8WyIrxJYzKlSd63ADVcoMmB9
icj9wxhBV42wsRHpxWAybwDtOJs17zU6NVs9ulcC/Ou/FjNprZXuSs6JHRYIyssmFD51F2zrBZAA
4HWwq3+ojgDRPiXci5739Sw3DEgHY+Ap63zPW9Uu70oHaF524LwaeoI3V9cQ8CGkzdsqLr/yrj13
CJaD4QOLeOOqNSCt8wcA9nQpyfnfsFwzT0xAlUltU8miN3dhbfnld1PEfeXJL/xr6pm3pjSUW80H
OsPm3bOwq8Xalkdjx6yJh0d9aDH37Gp5s3Xs1vqdhewxZKmMbI89S41w0r9aAzmnar+EUD1OtQZG
B7N8Doq5pq2tKhC2v4TVZRRclVn9HDywU/wB198spRDvgqSZMPUG3PGkP8SvMfFwB8Pla2q4RPuv
of+hMYcJY+LxVSdqZlCD4zejLNDTeLcAujJhivjA2Gt2t9V7rZag49YUwdk3hndsLf2VYuME2SR5
ULPFDFrIcaoM3GrlH0JWVtffBwyxAaf+zLWC9srwZ9ndMQLQMPDaBzdSSIAZoVKiMyYmMv66vn+8
gReFfYSvjh2AMIc6EZzSu+GjxAnO2wTo5OxayQrqin5Qw/hPpaD9CRYcGzjOhEFik74UjqEwVtqG
YhiFBL9yt2DRxDbaSACv+YEUUGRCw/PaJJl8R7OGGF5B0jkVMziZPpY75Z0hp9iSVwSITOU3d+7A
gQbcXxALzrIact51wG0/pKd/oWHtvti9R8LBUkEvnu/e3mL4tWOMhoRToC13p1+gsUVzr9o23fnm
Fig/diJ1QaVqd0/TnX6LUeq8F+FFsp+YEZM3RwHip6NFAAhhOC4Ri1xW1Ik9KwNq3yIhBUCIDPco
8H1x0P7WswZFkIdCzeqYH9KNRC7FbPvpxNiAH4rPQ1KkKlp4zv3AHyqliePWHB3EnAeqcd2GdTId
QYrTq+Pmq2LlkjVLNrcHDk7GOhY72K6JqC9zKiQ+mz6h5MLP6wckUisIpGbFTv+6NtXaE+LfBaZC
/rxxC0ULc2iHpQGotkkbLQ9LPMWpcBxY8l/JKD/e8WZ/nBO2JHzxwkgLNFw9TBm3FmeN3dCHyAX4
oBY3i1gdEvEXMYIZgu5Z97BRfwXI8NYIdbBlO9zgBGkXcZFNR4RnWZBUgyFVyEGx7CyxK7AflKQn
rwYGfncBvbcvnbCisl+YJTjGxc3s9B0hqHAI4VKxV+GsqhmKoC0R+vUiDfYDeQcCl4LxYUhnl8xq
fUEIUrThgL9JYe14lrASJEknlIE1hxZA5IsfG9vfi0/xtIeqxPJDwt8QYcnftw3f9c8UspvK2//w
L4g5sS/3rQHjoTcYz7bEugvDFJIKIFHej8n5Owam7t0e0Ip2+95/UxIQSWGYBwv4fE1hLLbCa/cK
5pb8xHkXOohC++OzUN3ngcGWp2ATqonaq7BbsZzQEHkAM2q5QV/KZECWdpHNunre3yAsdBvZlV9x
is1bUpswyvH9xbbxG2UQz6XXHfsSGEGB4bDX6S07bvH5OZrqAD20qWBNUtRpjDVMv1cwlhBVdmdz
t1FLsE5lsLfBayUU4E0BtJxmDr5hcBC4iay4AjrEUkEHJjeC0GE2MBYqV+wA4ymAt5Ei16Zg+p/U
dI2mnDU9X/0yHJ74jAD2VIb5sh8HX46FPuu+8pa72ZG9QbTjLW4aWl514vZ8zFLkSVxi4s/PjOOU
3OQlke/9f3jynBb/VPFlgyrL0jsJZsuoEr0Wc/4HaClVJCVxMply/gj7bx9+n94JqhxLiM/FkTr7
sqvWkxM0xoVdESdZllO8XxkiTcjfqWCv5leUjSPUftPU35p9Q9/ndQX0nUwDwZJ1luEln7ZCa/jT
VNmpW5nf1yd0gag/1yyoMPR8GfFBIk2a1w0T36JMAp5r+jW7Eh43qcJB3UVhX5VMPURMM/HsfTND
NgLChB8XM7w6YoFOyYPXJIt7vZ5/QjuthLafxG4+kCknv3YXJI/2CYrpW1Y02ljFo74vpxuu1M8w
ZaSDdUd/gz5JR3jrrjNTFcEtR0/fJzNojGLNd2vDhtV2Asd482mcS2cVL/0zz/njgf6VaemZbynm
1kZJn2Z5nOIjgN09KCNP5b09OzFRF++qon6nWhMwWa9yYy41P0ZlBWDklPJWN4xGux4WdiRLcV/0
AGBxkb0nT0Ov04OqiKg9WwZVfH5ZbpObMZuG0IFnSp1TzBq0llrJ4CyPMdINHNFfVgLserHj7vfD
uM8R4knSYZrehOWC+LDP9Sj4mzxZzWUPmHVQDTSCDlzQm8KpLMFUyJYnCRwV0IzFkvN13YZXnLd+
2GyFtQm0m12wdQ0TKt3FjOzCJr+G3Su1Ea9a2HgKTsT7IeqkVbDNTsB8CQtEXKC7FbKdWhu/8pkd
CSLI+WP+9bTdoyCuX+3bZbkq8E0+uq4hUvxPwTA+aW5kxEdU6zLSkwToqiLJnDJm+EuXnU4RgKaw
xcpYurTJlUusmq/0yd1aS2Pj6pOh8TA0Vv6ors99FDiUsrLxuvBcs2voXJ+bZSkycuyqXwTwUVr7
p3bAyEqZ26R20LWn35S0YgfWVLWeJplFySRIt0bZjCQkn2RZ1wooeusl6cmsXfPZ8lnhDW9a2IF4
EAHrtt3p7jVrLwmhdOSb6+HM2nx7Ce9jcKZNFjeY3GRL2f869s1Op5oW+fLFaxf54V7hNSXF80HM
n/9kDU7FNh+7wgqDrSzzXXDIZws4O5+3fJ5f79LhvDtIUwY9iaWWGqKoh3ShjYCxsnbyNu/Sr05a
oYq8+tDJbgHGwxOrOiqYsx/S71DRwPoRFBGhRGls2YOATf32JmtsG+WFT0UpV00JdaOyz6lBCG0z
j/0awj523cd6WhtVphlBXVp60GOr44GVY6xcHmkb/D6oRNXL3MF36IkBbZCiUQgwsVLrlTFlIuiR
6aHHishblnTpzlk8FNd8yOeyLlf7dsiuvYepYBmAQOHhcmYra5Mk0/31J0OPUmnrk6a8kfB5vLBg
9VknyDLmZVNZxsZbkD9YiOIApxiocJ+WM1oA7McaZFHlO8/UcnbPhT0PKAKAsAhComEo9x2fgkkh
WxkNzdM+c8i4Y2hYmERHCnxDm10sfxVsh0ospza086bsMmBvV/L6cBw5qROJcKAQUKdwD3ay/FXJ
74LaWlxyevgYRaaWg+qvNvc1rBZuB++0KTOFd+ltWs0T2OuB43ORzH9Orx0tU9AajRghZf7x/mo4
treod9A5TfpTh3vxsv1A+wKXxMTmrf/5k/zFnpyu9rMtliIa5oxvUTJbx4p0pHrOYDupzhfNSH+U
QI08lTwaHdypxDdK1/vThRFch2hRajwEg4jNe5/6BCf1QNcVYxQjUOa4K6o8J/0TbnauVFlxb1KZ
+EALhXqtzYxlboKHMYWxAt+TjTyjGbBpdo25bACcI8AO4G91/xCKaAcsvaeCjkubO/J0DLmy6LAF
lKRBRby0qlH7pXV3L4ms7YArZYzdm5WFSzfm4hlGuiL01W1166bPpdg+jDLcpGnviNrDN2IlvnNW
XnLg3BXyTGzGsxrce1Fz95ZLbnnwsT1YdFi+0wzjmc0HnKrx71EygKaqKgWVfxxcDoWLdhufgMDR
j2e78+t138S7miOU29qzqCdOfEg6IVxyqhGEIbFndw8C3r4wUHGfj7ARrDLUFvtjpUYIxJAeSuJQ
yX9ajQVUvTmQiJM8IiiiXkiGYZF671XaDp8DZSQepalC/8FZ2N9YNwSyIqXzHceligY2+R7CUwaM
ovWOgp97WvevubKR0nQcCA8aFzsD387sbh3hznSzh8biGp3NV6vJDItSGEzRX7s7RwzCJyF0a7bP
HKa/K9OJKnz0sUoqVnr16m662vJksNZjx2AM1CgyPQBxv1m4k8rqFOcP1f9GC6XCOyfdbJ877w99
/hIi0kSnSx54mG+WCZtAsFYShD2zvK0+3uHgUEH4EC+dDO4FI9RT+tYKIE4j3v/CbyqxRUffNMZY
gCNlFTNTrCH08C/5BtglGxuzi3howOY05bNWAJPsd4YNFokaMi/oLv9ifE7fsZbT0XfqJ36hpS3b
IAVwn8YA2I+WCIN685+vHfsknHDQJUnIqCJMwAWWv8ysJ6nFwP5a/tcP9oEXvODv/L8AtidydgW9
y4I35sKruJoRUIXF3QITWv5bc9YVpaYGI6w0CfGys6zN/EB1746BLiCK1gVB4UqTCvBg0RTJa847
VTMSg78eH0nxiNf7yua05O6cuUvCqSn3NxqWUcNnwvHaTQfcR2mrx9uNNST4FJArJh3auW6RrUNQ
ph4hlii4MKDp0MlOeHxG0cxDssIUD5mt2kuqtq2E4n7hm3MBx1tYoVvtpirMcDGj/iim85XhPzu+
KfXL0+ERSeU7LFi16ODPIlmgOfFXDnGgdYvzfLBmRdBLlW3QaY0o9OF8Mf339KOKhCPgl86NJmHX
En/hJASNURqu8Vi5mAQ7cKtmMj4b2Z+gPbsDM3WQaDB8ex77P1IHcmUA1nz47RdF50xm5RvHUmGW
0M6kXzg/79PrG+gvDeKJQZ9DgX6qD8C/UNhbxDsQVkD1CTkRWQ0I/QQRkrJZbbuIPJevi0zf3jVg
B74d7NORhjIHBAJ6doIL8fnFzNVENp0vXy3WkQRRMfgjvQHO/4V71trUo6eexAh5BCAxU9LgNXTv
YOyo3Woeeu9z5Y9KP5QP79AO3X+0JZZVSFAtnZ73VRroIPzAkp8OpbswHjEj4GdOD3/RfO0P2UGN
aFH2TY720QbWBGOk7PRIsrzOtT2GBOm8T1nb7Ok6cs7KWqRMTOivulg7rCnPplxCLSeXhHYTb762
eQh4BCHRyOoaGzl4NPi0B/DHXESJR77HilIrCnP9QOqWQwX246cUtXDw3q5A2pcBglzSLDv2WS5K
+/oXUgYVWzUgfdGdY8YN7iCR8/1Sgd6HQLEEk/mwNYQhnwKYm7SVxNSu9QL8/i0GRyL7bEybhA1A
acXzB1FhTGMKm7DgmWmmOnACVjBkED4EWbyo2iHPDQXEiuL2T6RwlVkhx6VBfNNkJqItqFD+Qetr
SO2338F4yOvsMCjUHBIMpgjPuerMceRMaHr1UE0cVa4N/ewhpLMCIDx/KOxzdj10PDdtLlIJ190r
ipaT+HVJjUsvfhLRq+ENpLi9y7hHflnUjh6GQ9QdWdzTDMbnTbEqMxQ0F5uW7v0Wup3q5KE7Oosk
AatmyC9VWb1kUy6GVGaKpyxg+yx99vrYYDicgF4wh/kNcNlhDWPcp1Pko1EjpGBJCcBQCztetWaK
J2DgMZMZctkb+ARZj3mm/xxOCqm39EnP9DICncMDzYbANswUHQQJ5MfSFOg0ZlC3oo0f/FPoYC8K
5yK6GwjUuOli8X1h6XslMqDsbo+zjSYfF51MOzXTfl3AB6Dfk1awgraQiB2tf6n6qkhQfOjN1PgQ
9JirfM8V412oM7TQ8mKqMeC8L7j/OPPkLzTxSnxTKdg2eWrLWVGNTW1tPrtwarqrbwaT9SyANa8Z
oxNiYWBeFog/uWbcP1drp2BPEbc03T6WLUC0k+Vn5PNzJN6ZvzN/hGTCUs8JOp5/aTzngYZpSLH8
N6tOFQKXzFliZHSULVRVEc/IrcOecaYvuxN4o752anlQgQ7YoGGTGXJV8cWl8RTiUR3v49o2dVkx
wz1GmUWUuFjKt4Q6ee13CbEjQtdthNGAdklQoeTFf86gUPUROFZ4r8gB9n1W63ASkZTw+49pjY2s
2JG7QWr0MbVJiPbc3+vTociOAdxu9JW5xxWAkTmPrGx4IbK/HooyZ/oYRGwTaB1mgxZLJJJIaaTk
wDB1aJVBPpX41+4OolezZuarlae/RfK62uLWXwHbXd094TSlVxXbmsEEIUFsAQY0QW0SHtc2kZxf
/74MGMYR+kzAN5p7awnfLzT6i+EPkA3RysZ51iJtEoRg/UHsVkVg4bg+UbdPP1pnW1080OJaV4Aa
3hZbdtgEs9FPtSbxrqGQAk4hXProX6BErlosPqrBXxBa98KET7PHSA0sr4jYjK6vhWGCosg/p2CS
Y0+6aOIUtl0hOYi3nly0+ywYJZnUn+6UmkirfggCycYGU/Kjrvi0jI1zXjkAu1BjtgQBVxskOL6A
bn48amXUsc8cHmtSXaGUkYreNs6wvmaTnBvN7OREUsIPy/IRFrSM6yMN6/yQhlfzhkTmyQrX0dkd
mzupDb5sBBdz+sz6rBkAYbvsu1cR40CS5Dq0hIChd06J+AypqWUR+vW9NdJmldowM6TT/DdZQ5Gu
GjNQ4BfncNPf9l3Sjp1DfeRSVWftDJy0pfy8cA3yzGGySDqzdKq6jIKh8efEolO9EqpOm+MxVrUy
j/MTqbPmwUe+bLNXumi9hC4rPZs6PpKoEbuzgz0xOnK4aetThg8gqWpBsgkF4ndEmQoJ6Tev3Wk1
VWWQVEC7KE+2QZcmgBzvFhxTiC+tRCESDS0H4MqSXyM0AV6uD2PuPe0ZIhLWNy0aRwTRjSKuZD5J
edTg+MBx4txy4BpGWoYjLcrJSNveSLPfzoa90ZnsFWkSJZGk4noO8/QcFT5gdrwDL9lyP6mGquMu
unIS3xjgJ21Wl3UOE6RBws13rxRdM8egDX4P7t4+zVQ3R/CgMOlvH8V/JZo/30kiPJDZIyCkb/fG
Ed3HbAuoDGl+pW/oswhAjBszdN5O86pdOYc8kde9T9UyzDBnjekJe2EQiIQ3Fc1FBLxcMBjLCLPu
+dE2WwysJuBbJebqAjituISp5TPGAZvoSjndO9tm0WSdfnvWaaPK12Hnky2TcU7RdlBkF3kbl89g
qkFaFrrd/8bVT0c/NZbCIXvO3gfza/ilP2DVAClKGdJZThGZtwfGQdLwOYFhy+YvSxHew9dNpQXj
SDWUsu6Mp12MkaAdiQRidddN7icokV2GA8z3Rp6Ui0TyQN4BUbhbRLsEEUz6p+31mlWD0GUEuKlo
SrLluLKn22GsMmAbXoNO+8qDwcFLSEOhxT70UJf6906YAzMYGVOGjXS0Cqvf3d3b7mWqXYMbQYoU
c0Dszixr3xH6bMF0uN/YHS1iGa1TCERlRd/fa9f0CMHJjwLmQ+T9zSR6EYXiXR1GYsHRF5IjG2cR
yWqadKAS4jpBO+2q4kkvPqfsKF/bmPI4hOJY0QlUEmvKgqhZgB9lhQBIUSQFROrMG74FpcxGtIxL
JYhUh3EUeJaqK4oSvy2ZLRpaADtBI9PQnsqWTLyYVyCWkYsPsjOHs1r/Xc5G6mlzSlaks7qJxF7t
TENuk9MQpBg2z8HbmafNM3SSBe74dUiKl/eq2NlZmsOEHAWdaqt4l/lgX1Xx70Nt+mozMnhsndkf
cGsyJK0fQO+dYbiBTX6dP5Le6O/miWQZsDzXK5Pw27P2vK735r1GUMPQR9F/FFkRE2d6XLLnTMZq
DwZM6npKFI4CQ/XxWlOHTzf4XkuAa2EK4mbKkEIbHUKTeXnO3DeNJlasywhmzb92dtibvRPYEY/k
WNSLvGWDMXgFKqG6gYy4O3oma0J84qp8a+Xabq9RZKxHyFndCXblSzkKFvtXxZlXGCddODJJWb1u
qWLzuZzKGb3Vs9w7dTT71ANVQdOYBU+eqEaHSH7UDGPFWMMGEpe4xouV+2017Dj7lcPy27TZDy8/
FQKdgg/+EBCnPeZaTP0dSSKaLyVf2/qlEe+aMXj96KGqexnWOLI9xFQpSrnoNNgQadw5syAXBqs2
kIcV/dNMT18MsZSitw/jmlRctiF1OU+9r0zUf7hHC3To86A7hyi0uMbKkgdRVjFD/dPKq7R9XBNT
l7OcNIa2UZS0NYhMg0PgxwIw1IZ7TPBMOgRKKeLt97nO6XoxKdWmo1DZTVTwpsImGkZ67o2zjQGj
HytUaKzrAtg/ExdN7ka3NmA+zLhZmecX+XIZGU9VBQIfnpdGC/jnccVRzsWOlajogz3nZAcbFbq7
NTfJimmSe7msqkN8uTrtOTAyPLZIgD/QwF+LfjKLzhbiU46iSerNP1enqBjt+GOMLGpwaUIQ/mcm
xlBvCxdixr5GqmGOqBR0ErcJntIrQy1dbXNl6evqkKJ39tPEsBeCGPUzyMtxPLCdeLSa9aAa319S
J0xTmpu2nJQ5ijrl/xjZrk4J7joR9mgt5oFUxEhbsGXVuujjutsa0HDBQIusgL1fjnnukicHYj9J
tB6HqJvlrjnVcceU+KlmqMJhZjAgjWrAxuvEBbT2aRddpJncyMFmnYYw2QT73Ek9CqOCvAdypbf2
i0I/22j4SBGH+1LzHc7bVmj60LvtUSOQfLT8QSKZoCCOD9sg7LO5mnsgwY0jKCyCYusCWTXWI7N3
L3uSjbRLWobVtteTIJwt+jACKE3bwGsRKqCTpHFZnXFs3t3ATWLr6UxqPi68UkiXELoHhSDS9FUe
GZx/vxgeVb55mzkH7cIbCHTcjVmiazjXuRECfFlmUzGpb71PyUeUWd+thiJhvW/A1o6mgi9VmtTR
Zur0U4JGvsLaKWselY6TPhd803dk8MZ7UzmywPk0zTblGbP54U17kS7ALD7YEzOMijgtOmJ377FT
n+eMN7DUb7tHLaV+KV6enO2374mpItKBF08hwm5oZSzDXskDXQYnwyv05C9tdz+gX7Cw1ZJ0IV03
hnJt833mIU++Z176NQJgiAqoTnQ0C06kLIO9OMVBwtvm8ulsz7mZlJuFq/SUPXJ1TaY7dpXBwpHN
38RRIOPUpA2aY83/9oc/NqjxJ5dCQhnH0FaF1sudnjOcqUVE/6VcMfwFZaYchTWkFmJTnA07g5mm
q/KF33BKvJDi14jGA6HWO49F8jCTkPPsVrkFa2fpLKgypXJGoN1DcFC6Z8lB7VFrsqiWcD71S28W
3TH7s3d1jIbPQ7qcjuwhB+Pr5IWDxjXZsxbfuhAD0XZBgijLPuCCebz5laLQ1qmzpe3GGCy8nLSS
1chqOWuqM4u/Zu7duevyoVDhq2fQY158eDgglZLEjUK2O9HQMSXXw1A5dIbXvcjMuEuoTX/X13q/
t4MuIrLRtNbXcED7thEVVxTJyw4rzPJo8esVqzmmIkR3zPnyDLibygJBB//w1JHg+t8bwB03YwlV
JmO9JSDceR9hsyRGi8nagtU2gx1J6/YVcthhq9QZm9apH2L7Bh/GUF+bkWz+TxeZvGI3T9yTPCv7
suKN7m8YgAyFRnF0FkVvoBeioCHgyRFucatsP2eBSqzUcYrfZdRDj1xMDOKluYDNjgaNeTyCjCkq
lEvVIhHhkuV+znx5DLTbKFmQLBQwqLr8UQOhyaHbU7nT1Z6BG1I9hoQYETlAmD2cOut4+aJRo8Jp
B7zkIlYhFtfMgXL3dYNpXrHZOrOzcqal/vMl2ueMOwmnCuqq4v5aI+YcLV101BzHlFZ7s7ZqzT2F
fSJIDI4Z2aoZBXcujM9j/AysdGYWgrn7SGqtO1K4XgEfcYN/TD23jNt2twLcOy4wayksVpE7/vNK
9V8NvxWDfI1F/4AvtYTxJX8vlcZJrPRpP5EJvu1sRnJnkHefPEV/HakcITEVe6dA1TJ7uQkZQ9mS
LxcKPDF5rdXmqkt/jTqZugh0hwydxMgsvp1bGniw8wqmIM55j6NdIkXaTcHG9JJvcBFY9ISjzeJb
rxebrgPeQolSMjNRGFfgzWShY/RaRSsEuDBM1i+0FL7F9XW86cicqjEKQGFAG3HQNsZOH0iihlk8
xyDKuEd0lTMTD195HzGe6Harce2VCYvZ6d1zOiHQqkpI14G2AuDYzNGfjypCYIoAQXBczYrjkzKB
9P89tCL8Qp9WbJoXIqM0KhxDAaHZ/OhFvtK7b1ivVxFu6SA5kS6mnNxbnJiUjIfmmqHn4nMp/wYl
TC/5fhaZ1xPkab21qcbFqlUoXBelwSXy/5/M7xzJ2sN3SSV1ShX7dgq+3J8NRQJCK0K1SigH7z7K
yAFsca1/H4qHnMh2T8MvYSQcJuMd6eOC4JMswaKX1p9FP/zDfIKIKmDv/50rCu7Yyzsfv1PFwjP5
/6hDBiddh3R20K7Cykg0hZsnpRrmT8PEEt7J85yeoW/92dBF5zZUwEtbdli9GbKFHa5TSbsDqshh
CmfAQvuReI/jIhnG89OxRA2a1mnXuskvMFUuTXaeTda3UrQ2jDl/knAA+ISGhMvuaOtxPsZ9zIk9
K1jFkOjkZCDDjpvswST//9pRoqde4tE/DsI0kFGJhrXkYposuEKh2D8mpasckd4b4Rz7HhyMfVUa
dEBQrd/O/wTv0oFxJ1e3zRKU++cD7TXhcNq3ecvzuqTj3c/sCrSPGhl+hXlrbMc8c3pH9hrWmvkA
hjZVFMevy+e+ZAiuDmgzIRxZiAzB97lW3acy+76HQallTiSFvR6iNrf3EB9NapDOyTvXp5KVf/M+
wx26r+TXVZG+ASjTncH6PhC9Js9bRZl6ba7/w2XP4T/aLOXCSrjeI7alHw3CUsh6Qlor95I/qU35
vBdeS4UniEXe9ByIz8aeuKJmFykGkRzvjx4ni5zKp2qMq+16k6eH0FVAsgV0y8VARLghD/ODfwk9
4EfTmGtM7ImQ6j+UOewWjQG/D4UxeCLXzPycNyVd8i5D28Z0rsvZVeVX+9EgTvbujS4QGejFBSE3
aP6C6ItESTyf5Jqc0CSADx34t6+jL5ECLAXJeQ0Ei2pha+a20mTPcigE+nKyfJIUqSNwmGwTCa8N
ruCx3Ytg2g2ne1SbXQickkLSnflye4IvjLhEp65gJUeG6V1nb4Vw44jAV1AsAtRfsEOr7DXLErRY
c2/7CN7LdLHrUZC0xw6/jkOMkws6fdzLdAc1xqoADmpxr4uhB21y4pL+5ji6ynEbpzDgjO2aRVhe
7C7f54pbU9oDIYOgaV+UnjuRE8PpAFMb8tJ9VvY9HY1cQQBqafTHm3Vkt2nMlelPlT89k3pGoA1Y
GRsikFVsk5dH7ZEHcKHn38a645Ue3iRWU1JiWpTAyj2YAd+tcTyfVURe8l9qaKuS2cK0p0A+Hgz8
IO4PaMgIxORLNr9yRexnNEd2Lt4pglBAM9+8U4UHFUoUtu7TCoSeQZJeqXmaRB6RTHrNAGbjnZ2v
RR5Hw3hmGiG4FQnzVjqHyouM7pmdVZhP40MPhy4dhGZKD40yMBDjfA7tDiOSIZGiDcH/uUAYDvJ8
ZGJoDTxDxGD6KWY2UGhlneUQnnGtWQQSrHivHumMF4K2CKBu/Lkcv8Mu4tEaKgSsLw0mNGm7c5f4
37KpwPMzyeYuuYxnjEbkk20BG9VH0RlnalG8AdN47VQCPrFNWD7Uu9G+EBzoNhqmS5C6c1/2J1Zx
36C6zr8CX76PDbIjHaiE9RnqDukch+wLN46HoD1TmNbgK+Q2Y/iiMnFIxsTD6HyJRWuU++vIhjD8
4Y7gpR6NxaERPfj6nhxMjHvKfvXDB59QwNREZFSsB3objBUSiMTfCFdrF03RggJuEpfxFGSANqvj
OUZ67TntipO3Nv3BGPhoZ/cq9hQ9BWu1xbjkZBqcVgosdpH0aQUktxkg/bpC8gWZCa7IZto8xH0O
Tj3Jg6JGGo/V8KzlhANRJlT/JcDBfDsrWxXGP3wo94BTIaFwCIPJ1W0XA6ime/05/zqBq8gYVo3n
2IjnzoO0NBiWykxHLtKxQyCJNZXEuc47pHPX2Jt4AqO0/lbpzDv8UCVB4QTQ6g9kCxh/HD3hSwVs
pXGMk3gAGPbbpNx+6im4th4sFvtFjSkHMhgEWhCwc7SPQyMHz/mWznyTKXj1/f+5BJZH2vZRf28n
Q90vGa6/t8Xk/x9muec3AGNHntuwuT1mMtLDw8Bijl+qmr8WiLatOqtx8pmbvL8xmuguiYHS0Tav
lOGwBvqVc/t5KKkXYDEo622Utz8hyIZQyMdfV0WSADUUbKEJiyvZktzSfkdQqWesHE3eMgyreb90
9+SQC/dPeju1SaruwyrtMCZgR4p14j3wSZPcFa6oodBMiBVlH6z0pGa3aNototlYIWvmGRSLn71P
FxIAfucMG+A1P/cdJXP8dEQDOXUwrWLuljDWRKtpekuephRtJ7+tdDHNWZ/QfUxgc+yaydAffu5E
oZNWo98O+Dj74jCvL9ElFAcyztf6N7ylDps4lsjEi11F2yjEbjtdQTrdavZ5+00qDz7xg56biDMq
PyPxxRPzdN81GhUGwbS4MRhSZmTUMMqiB0HfoFWfWQTm0r5jZkg0eNk9zFUVoGY2Zf19ppmHcgsR
H110QPlcglpO/TJNIbZwiA3D5uXyQtPyuNxWV/HaIG4xjPExftxcwY/XvRa5OXel9ukBWGnnrdkv
OXsDdz+IJXdvGSvhdW9I3eqgQ3tvlGLp2zoEgUwj+p8LUNNMI1qxa9re8KApF1bI5lXXsbBVBj8l
Fqx7Pa7AW2XE5e1YVMqiXqc7OAfXzAdYtvvYPlE0w3yV9Yuj/VGUsxqHcWiapt48i8ka/XtXK9nb
00WfH+erO0BNx5Mlgi0YQXF9M0aYzIdAjWVm8MN2+whkmx2XHAuAj4gbKHLLIOlLrYSxCmNa937+
GDboRy4BAcnR4VyfHfSoRwGibUy3ISPMp4qKHj7h0YDAKlRp72XTm5/pfKpsTy6fiuOnKn6If1cp
AcWloZqG6QCc/7cnln+BCpS9AIQaahlc77z6pGJ7pF6nAS8DgimgOAhJK7YKwtLmfDpDJdz/wOSR
T4csZ+CxG1lfk0ogF+rOJek8EXoyRpg6Bavzbno0jGRA9ZvfxPrSTS2jC8wSwpiC0OZbjUpnP5Y2
cvFrvAW9XK4H/v4y3L4/iZ0oS34zod/414Kw1P8Jz0osVLxhehEHIMTh3mlIwQPiX7J49RHM0QkX
34jlnBV7m8pRNcU6VSWIHZ/z5LMkQaibMmWGAOVLiyZhQpIe8InKImFiIwPkRkPd82Nquuy017Lf
d4aTzzbBBpk8aW4UrFmhDu19KHWR2nAD/ZQw61zfxxOq5TYi0tQiMUzvOKncnYeklOLl1KhqjNwE
UN/Qkp4SqYSAukHNwEv0/T97kAy3LnJZ/QfKm7NojGtt3zrlAOMLpjhE+wzq+5X8YLQlvwNTxHbY
QbBAhfvyKPvXC3CrafMVnW+H6Mzxm4fc17yNHAnUOqgo2VRBfs+qh8uJiFBUy/bz2M62+orCTbBV
DMegh2eVnq7gONKdhAP8EwviTXVvLz20lGBM6RvlIZRWZ0h1yw7bMQCKDmQENyJJHOa6GEz9v6el
jg5qM7XewkYoUovb1yg1M/+pDYbi7pHOdaaReud7Pf0T5UgAUf5Z9qpIM2dRFdoEIHaAP7v7FG/h
YI+l1Mf4IUfG3e+uJMTdLKo4S5BmXuBfNUOjUboumVNu1tvyObpm8dj7/eErzIEUofuaG+kic9xS
H0JRiSVQSBA/6e/XtIqHcqkV42nLV4IpQVDFax1gkoxhxbVUPJPw5iXywroKDp3VFCRWhv2pJS3s
ggiW3aP1kvpAyf6YKWnsYJXlsutjHcwZcbM+O7zXYlFK1lcwMcM7T+wT7AVdxAuJF+fbcvHrYTZz
RnRAU6HVFnLg9WvtRr0dPwiRjCI7QXC9UBvJtZVz3qtYe1wkHKa/v3Nnwe3c8quCwpizGgMuc2Ck
Uqhoa3/FyuX1D5w5P0D2naZZXH1oxtyV19d9jVrbY6Ii7/HTYu/DT7MPLM2FRqeknk7oRgVwOZbh
s096KEsvC7+5y4cJ7GvbPU3U/xOIvNGe6KYjI4YU06hW428zmA15SU00yl4ImNSozrVU/iueN298
/hDru4qAT0aO8g9W7NPwz1385ef3nnx0g7lDebWLGFlUyAFJsIHl1MNK2ppTDkkmX5YOHL825rWI
OwCoRDqxcX5pi7Z+QD7cpEy9KnMW51X+cvsOdBjgYLkuQ5OuHFqWxk0zZZfgKwtwmKkXSehAMLtv
FCRtp1Uxy7Zc2Djh/qPNfhmUQZRk723JIZTvPi/I7ItypCuvLgNI/86dJrHiKMKd1lnvRfAtCXXJ
QAULH8Mb4Z93ltVLPCGlpBMfREtgFr+i1RDYxEBZbNoRCNXxJAqlsGOwX/FQEM+J2VrKbDr6Vfqb
aym8eohsalfIFw/VIUMvc3CIGe1uG3G6O1D7m3rAtdWtj+sx/4mft/FnxR16c6VBkrxqsQN0UdSE
9FbXisY+jBOwXpWe6dCzxIhot1/crXK5bxA5D7Il+1xEh9HbyBjY2SFveLDTSsRZtHHGu3if1cC7
o9vDMycZ0l+QXVBdElUieUAYQhqKR6z0xRyYAqOxZNYmWCrAJSz9YHmGE+4j5zDWxt5FTR7wAU5z
NOHA6S86llOLeoZlpOe3BO4+6FpWpC7A+o3PLAfblurKzvOqhqf/rsM1WlzOP5zlAm7aLesu8wDJ
V216Ei/3U1VvhkANpEhoce+1vcpz4YFvNxFIzaKV2UK+pL6X9eazWOJpz3UpcjmF7bzBL7fgOust
cYAfBJ+fCDAYHZXrGVslbSKOuGNoIdgZMz8gmAGYJjRBm0C060PEedkcVtcd7xv2/5rVPTcLTnBM
3oXXVHxishVN2giB+Z0yDBevqyTiaOtU8uoorgR1NYxs+LxhxwL7SZPlihIi3oLgxbFSabOxmroA
ZJWDalJtH/LvVyeXdjH9CiNpqGGGfW+G+QznSQjw+oHOWiSy0j+mpH2efde23sCwacApNS/fwIdQ
upbLCNYU7tyijSJ1CxXuv1hzAqXPmOu1ed4tCHRhUm+ex1tlDJ4imNMBrQu2/oDvTO06POoEQ9Fg
NN6iQ9zA+gN4HnHjnTmh3qZyXQSJaEnnXZJHqW1lhuwEYJMdpjJs+ahQH5WfppXZRkkEJBi37J+G
8Nl+dhCh5tKTrMVL+8DNOm3HhVgi7fBNRPEDsO8yY5K1lKi6qVd+RjgmIrZPq2iDqijjIs41cPPt
5GpRCEDXueFBrimPowOhP/gJYnYFj9Uemqs2FpJYaYS3uBCKuiNsIeo8f65l5JBy/dGp1SeTkxxx
TGvWn+j72d43WQggSV1firf+6Y8VcHWT2SmqrbImjdhdICMh1heXLcEYMlc0YyH337VHLg49G3Hl
4pDwsIkMUbM9pzl9bLxl6lkpKkDlSi8/vBsU9vZxzw4r8qYKXSUYTnLcCyJAvjG3IbfPPNj8UwlA
zKqntdCpqA27QsUMxmVLn+Ol01b50snCNYW8oKHogR7FGrEBHwGRsrR9NPCsKKZm7KGUY4L36sX1
YChZlLgQo9fvLVQFF6yWjBqEc9KclprqyNMk+CrIF6ydp0W7zqGGPZIxnV4kgsh/0MkMjqJ1xKJr
UZl57eR+B/Sy2D5EqtvCroJwkV9WZbIT7BdgpaQozNAv8t+FGG/u+HObOwwNH7LhL8QBsTzyMCM/
Qvk4BmkcYgCA30nFeRqoiCzWaeg52ZL1KVLMK//ZRooKlmI3zvqFRZjIA16tfP326J8S6kyGJYGQ
a0CFCYip1xVXR2s9XxAJibnzfZQ7SIsNdAmAgzPBqgMMIhgM5iFcKkK/sXNol0Q5IGJ3fYRzLINX
rN91H8U6l3wwWpNWK1d5v3Z3Hg4rSAv6BqxW4Q5NK6aQ3haMHg792GrgNaL2Ehgx52UDBd7D9kit
IBKdI5IIpKt1bgUsso36nA+9Z4QaepJwwLsrTE4kn8svOY/laf0ciA3zRSbMdQa92p3OkkA/TAXW
72Cd+THbxUbya28pyDP//GvCthGfNuo35P/GocXyx9OB4uOkqjrs1EYN74KedWbd2PquoCVCqVxp
z/ILiWIBwRWM2nHMGOmHKgtvGjGX9olO0z0/+SbvLUEhkddZjUdHtQqFaK3SUwZ722kaS2LrinD5
NR/JV/RX7dHX23m8UNO81PvllYoJy9fybmVVlFVc84r6aS2IEDQvu/vuL6LVNjKr+NAgtPnQoJkA
P2uT0ZDE+xBijkZU1IMCM0GPVAuupAt3M0gsUbirbvG5n3Dwy8YOBphx5G+gnowzLU6PpTdW7j6N
nnkczd6sdTrOEE2X5fTwbGYqg9zwC5XXWrYSRL3hKCL/4UV8NT1tyTTxh4fGnYejW16OAJqMDl6l
DSZzD5uMOHVlPyxK5IJfddzhvxJHjZe5YGX/ZykrRaJXAtKhjwKXaPnGOOFDTnAqNBXaUjJCcW73
gN7k/c337TmWX6PwYjtoIjNywd/+3KWJuh0yTY3RJ+ntaDejOLCqL4WnKDSDamBBnS+4ey/MSeuw
8tRGpzQNzT5eoNDE1A4iN76WDTK4zoh6/giCz8KhPS/TurM0CdSoZgl+lBJoNpxv0vIAHwGJ9tJq
5aoGQNRl1XTBjJjPQVcnAroPCIW9jz3H4AxOFhPUK+gvU4FLRYuXWmGw1Dv1Isl22b79UHy++Js/
P5g0LI6jP+nHmMiqhgWEfhtly7jUr4sO5j+QRd9Gz5uUp9/h//OTxPnUgoRHLcYmgw9+gOZAG53X
wMTCpRsIZ6QOundysMcn9GoLaZ73bUre6ejKwTvAl/xr6taGeeLqVCZWnwVM7G9zItCWy3MCtLe5
BjLBNX3NC6FtAsaUzg0ORhhnKP5FaPgCgE7uYoqYFbLDgogJ0FRMtMvUV1dJWP8d78JEmPklGvNu
yiyqy7A3idsaQcRu3iXq0bVL7FyGJ1gtCOFGx+t/QNkMaK4etFmB0R9DouIt6UptqbW632NH+scZ
MLfmg+E2vcDyRFOk3Gjvix9CXMlzZF7clvp/JCNQ1KTNS9Y6MnCCEDmeuSTfyB4Foeb3yRbODadN
7lJTxe7YuQEogSkbgnG/GB5KZzmNvXukhksW9wtZ3v8ohUQwgZrgECf2jPF1TxLiPtEUnuiG16GE
pue0MolaqX7lWYI50Kf+zOKAGjcuVxT5mjk9rhHuRHooKKI1xUwMOM198hFmNCJLO2vd/dwSgphs
p9VahjqYQRC7Blf6DME7wItdyzxKUl/ongqcg87DvKQQB6ICW3ec+IBZOUi+MLgDP1lNis6PUnYd
84tyWYiyh6tr0qPpxcFnRhbkNb0oENRhZ8kQEOQiEtkyPYvMWVUc2QK8lbpHGsnj92DCRGap/mgx
ryjRP6uGncAJeYmbt5seYptFQAp6kYIvNuaglzbW1hNnHLbttdl0zWtwVbNdwKHLHbjnxD49FHqv
NVsjAh8S8aze0B3iL5TWJBO5IyDWzXIkJvXJ+bh98BjUWTJJKXU6qMmKCP0qdOZfkSIOvrp9ymXN
mfCYzkAlbyE1Nl+M08hLU6m0Q9q/SUGn3xmY3yMUqMR0k2kn2safyagpAXDvJQI3YdzSbQvkzNX7
MqTP2dlUbxuQc9rbOMyYGyWvfMi8/z/x/QbZFYm7gqa5Fz0up8Mj8REDc7h0A7fWUl+UEjBh0C5f
0xsUKnoZHH+OLKnDOtf+a5f8K0URwQq0PPwSflfOR+qfB2f7JiCd9Z61oSCMQW3XcS0JZdXA/Mhb
8rFXl5xuhWqg9tlbl+IfO7kerwSk3kCvV5Ar/ElY/KIONsKcqeeBuZxljYOR+nb2KzKqvsJRo52o
NmRTMc3jAapYvQAU75csx8sesP4Vr3J5Qn2WdVXQvNZ8qz9tWmnPmnRWXmzMDhkS/OrzMsk5hxLh
Lkz4dVo75JXi5cuwjZyQrLC6MGDh2IdxPfOAhs7ebN4cAaAWrkF4hHQ/+UHWGqwZzme4nTRCew57
V/GUhZNOj4Iwep6ypdH9zSaSiLAAVe4cLRsTrlKZT0JEzx/IhFFE+t0vl/DpYxW10jFcEJ2qdYli
KQWv03rRQ5Db8fS0KzdnXQtoH0yEr5MW40HGlKnSrJRCT6Udm5UjOBEt+9oUwygGokC5aVkyghu+
dUekg9FIKp6Ce39HfHyqFRbzu60GBECS4C9ZRL0EN2/8jgve802/C8tsHKDq+R4bVR3e4W0VGDek
9bVy6vmSmWVUddmw5ohvNe0AhTK7mqrkn89jge/zLBWEVxSUCpv2FhtfulQ/yo7f8Ujd+zON+qct
W2+6h2EncxrzwENO17nTHylMYp2ygEs/AnebnKuAYVZKtKdNRxklc26yZ7vcDtqUEOcxfcimeeIY
7Ejkot7tuLI9jOCsDhu+t+UeTlOvDv2WNwv4YDilG4S0qI/MBhg5CWmQ+sznzUUWjUXdHyOM416t
X/qD6mhxhjXHO4d3iJFm7/7W/A2zGl1NTNp6oNtBmWrUAGBL2HTsLiDkZMPIAxOj77e7eoHuL1dU
jA6D+4mLDe39Vi7JVIAhbgzCLVPi2JjyjYLK4LLc/76ia7F/evyC0zqPQxzX5jUVp4cCjiT4xNg7
nYnEnRZJc3SGvXUEAUP9PzXDZ6vFlgCP69V7sIZap4PUopUlAvF0L0Z33LIRQIp31+DeTiDPvyz6
QP3SnQ0TRahM2/e5mGqiuL9oWxTNxtJdAH3O6GDEylV89hz6py8Dk7x4hE956oxXMtJGjlUUaH+C
OXD3mM6iTSfzePjTVjxoyuoj6KXGKTl0fcCZdMi4q1DUtpk5fkWVf3i1WOhslaBvQKINUdlzThUD
beGLWJ6zoRw2++rET2DqMfd96OgrJ/UOpih8iehy903/HlIw5L8yzbqyxqZJi8GJs8RDJ7cUUM/Y
RWzSRreoSKMAlmTb+CJAp9qrDryf+V/yV0QKx3mLm+4y0CuLLnUXNIskVTu70caP2Nlig1XtSf1R
flCuuRPZgrBdvkBNn4IAiM6eHqMIELeoBu1nRevRMMuwtNiHguYTyXOE8LdtrBsLcUXdFDt2C35D
iBFA+9/aEjpZ1EVvph74D4mzfdmnxppE+IeF08iQFi5/GHd5Vk1u0B0kJIO2Ireb2DWrLUmrid+D
NndWfhvrHvNXQdm8CHIlz+oGZogGFKD2gznShtrwLLU5izkGmw0PEIk4Uovozj+Aj7x2VFGkebXI
OH8csHlW1ZSxCDl3R/X+l7O0ZCo/k3Fp/hudNX/+7cfPxNwwTXikyYMXALBQdgtOBNyCDwiPOKKv
+6nE5MS0YD5kmRao8Ktptr2SZzOwTkq46KczPqjAxdlwmX2WMyfJ1Akz0FmVzDz4ePsafnCsyreg
qrgIjSpFteo9JTF7U0PH+Im7tBK/quIvKaB8xePXDT0Yx7y8j3vdX1gACyCckvSHss4g6Z1wi4HY
UHfMhViMnnalHakm2tkB5XrnFFNzGTILKK8qoCH1JwSubf1VzuCFMXV0dR0jCw/ezVR0nrV6OA87
HrACszx1prtwmrDhyyMmAi0k7osVqTEHTOwPviEdOC0JWpyj7c9Zxc7RpGBrlv/MeoWSURiqYXZ9
50TBBx2Y6dnrA0gfVoDv7LKbBIXa47n5SD0OvoWHCpv9StwYyO4NZ6Qcc87peBbqkqyhO0WHH2Nj
DrQeL21BUXxaHCHejLifgMRXoGtPsWwbY78BiovOnV9J8cmQyBQTo+jYDXXTqeiEYpWbri+vsFku
PNKH0rtCx3QNcN4yXeuLtt5lREwWYGHkF5dkgpIy/o4XgWgMGZWpomq/cQqT+NgSRYly2qKaqcfv
z3wl+C/vfiIW/4ETPxhKoovNDkceUMwK/E/eOrUkb1mGgXb68YEyTbKyF8F81LtyGVqnLSz1nmxE
1OU27UgKrhpaPoO6eDnlAioLCJGQygXfhjO1IEW3edByvKiazj+/Ri9EYWwW7uM+p0ei/sWE9t7G
ZULGQe1HF6MhU8VoS7RF4Iv/74rqXlQKW0nQKIwms0yQVSNUO1RMR1PsBQ3wsX5C/sVOaxSxzoCx
1T9U2u4FXjY80R53220EO5puMoVGbisgnY+vwAtNTlC8R5zt7s1Cti2/5COAhOXnjrTq+LPQF8M1
H07I86gvXVaNKulC1qBF5pMHxtXsUWKfZj5iF7qBC4xol3EWp5paGj95eT/o4Yx9S6RM2nx4Xnsz
uTtQXicDJsi/1CUGHEe8GLh4nigKjNKKvWuHvJB0liGTqltcpOU9BXx7k5h0bgur7yhm8GSYQoet
Dn/zsoH7O1eJXC+T4vVzQN2YNKF1aEfPYZVGPEtFrbLnewz5tPvHsv8h3k8cBKxqMTB2LGhWO229
e+Jo9SxM6Al8BEj5y/s7uKGLvtcwruxylQQYoSq9TjnyUzIOck65yCfS4mxe4QmOwcvLneL3Eu9i
lN/BirRYRKv7FaSf4Z3s4GyQUJrxDNamt2x7424WDqbce36iwIxHD4bc/bLmdpGFa4DGF/7d1MvA
ZZ0s2d8SIMEBvc/WqrFrYAvernXFRjQW+DFTTPaX+nc0E1imXRwmzisYfK70GNBUMokBYVUum1xC
08yDVM5ZUOuTCfqJREywK1imI3qVV+KYN5wmEZFixTHHmyjWoPJpaKNeF4/Nc37F3pO/2RapLqnM
cGCuSze2MuvcJluoibmVI1bLagkNZuQ2G5gVCbsSnCZhzD7yaMzNbH0F0IDEY4p3vnTQGrLcf/6W
mOpQkT/OtQHwWzq/BbOsLwspwVnXYdy3S0DNTKo9966nQaAi/mkO+EI8vFN8C49jy25L5iuHRtd3
/3qG8f/hq+dlxhVc34Dh1EIR9aZgFrcHsloQyS0aELkmG5Pg7bQjunnrCFv/IWqrwMXyCQ3BlO4R
va6MdaoqnyA7QKICwf2wHvssWoM96DlY3wHtRTg/8RCqWzy49KNenj6lFIt4/qilEi8LFcfGBR99
XE6uIwb8Kv8bCehPKmIiNvv8HiFnUIZIj/eYTXiSyvXkhxhrDukW21Hy8BPX0+SajzuESsIk5HkG
Q4NwlJbmSflIi1IxXHzRad8XUuiqsXcQF8f9tboEKSaHyHk7gB5lhCntmkhOgtFAzyGmyxUt/eXs
U7wQI02PV1ZAg75LB3/QZTdVnihpdOqcB+rqFr9D0L1b3e/sntjwwCDY96QsHaYSha/qFCvZ0f5+
gY0fz/Z1F+tCzyRVZQSqnmS2vpVLyfQwewoFJBsjGmaHenRqrzGkPEkbQpw6jfoJKEW/x1X4s9jy
l1ErmzXJlkZTAhBcW0h5cf3LBOHouluyIGC+RXymCt/BS4tlWXXcihomwdDF2zfDn+Ym6ES5Kjq0
fTigwQp3ukuluKHmV1K3lIjuB4r6MRCpPagwZ+faJJIRBC11xXvKCRX4/PQYkGGDmGUQ6tZigt41
9SlAgMbb12aY1HlBJya9c5RQR/jb3nSIzcUyW0LA13f2XSKxbP9CLlrV0vce56hAT+yLhKAXbmqx
rXUy8BoNnV8krphVM9yIE4uwT1NLmWVg/QY6fZhEgeXWsQzxCpWx98jCDMXbX6a0USknViNuM1PY
jVirlvkywD0GWDINVMjw9IJEiOGkGNdK2DHCuEg3Cl0R0zeJ1EGAfndWCf3o5iUgg9LysH22jzS4
5h6Hs+KD/AEyJgunMU+NqLZpuYruEcvLvfl4iNqnSfcIJqBM3uRdiN68+es/5PBdCQtQ8M6rwZW3
QJMJFRFMnGd2P4uIWYOwquOGUjSrxL+s/Lt3WHmKGfGSNfm6Jim1DPi2ffJaBHkn426HQugUsRoJ
TvurFhCC6P9BogUXRkoZTuMf5aU/L0303tndant+a4l1VtXYmXsX9x96fLSluicU0LPPGGLYXYto
+swDRySFMs9D86jN9IF+OM2fO+dPvAbqPFoPB85j0DRZ/D6oIE3ZIrxz0AqabXcR4HGQMG9eS97W
S87BKUD/A906NGGXhM9N0uKI4JmS9SrRi22kvVUH0ovGydm9SU9BLrqfiVoD60A7cJFerU36/BMs
wjM3YlK4dJDgEuVY428jxSBzdRj6zQGvIZA3ZMJxUplHSvyFJtSYvChzGshvFtzOJQ2CMfMlWiGI
BEvfW8zRgINQB3kK1MEevzwKmp9PDqueICcALHfRdpA2ZXs3wdQBRYQdVpFR6qGWbFVPSnKyGnHr
l8FQcWH0pGHlFyL4sE7NQ3NBsZSeBWWfRfXFmmrUvq2TlA6l+7lCPZb/Ca4OGvMzwcnGjaiX/aTp
HZAT1YogeLOFzj/t17Wn9k4CawHTZowZiFNlcqXP6neEooTTxIk1JvN1tBojMSLhGdK9ZfNPMRyQ
ZaARq3Yp0wMLsYTMKDu5X4ZkYDy9yjBmR7Ge2vye2fOG6wi3H8zwI6FaiyNFNY8t2y4RMg3SiSy2
4kY2cMW3tBCibK+mKwxMh9wTvh4Kq6CsVwwIDtRC630lTUUkrJIp2tRqv2yiHtA9Li9z0d3DR9SJ
NmxXOMF3rG4BLxSDgsXFlDGDXDMEPWsocDNTvu5ACdEJEqHr4p/paR6qa0lbSKC4+6f0Fpim7IN1
Gbd9vyKDHpz+fYMboGiW944dudicsR3WYQjjmM7iFy5umRq9HYWKdp02DknGZ0JeQlld3WHCfA8i
59hBY52hoj3MtfBKKf1Zps7KAbCHFG6nCBjR2PwI38U3iQcyWCRuhnbPmfqRWiHXHKwugayfqLvV
AS144XcO2s9YrJJTZDogZLlIVbMB24+mYwqV7C+OBfrSw+Fp4+0GPktfEJyPfEA1o/chse4G+v4F
mGN2do2lMdhzRnHu9vizb4RUFpNybuHbHFCk/gcadUd5ee8kKdCrt+LxKtxIxSk4gXvV2P7WcUkO
qddn8MeX/ox46FddObZRCucUYjGx2Xby4O6ezlngqtIWi5EHyhCx+EBCgVlyYmGNDeyU3fqBl/ZA
Lv1Zg10NEpx0+xHy2yQboQoF6RcVFGbRZQUCdT9bBdvu7PvfEBMQezoI4n74NWhCNkFkPeMMTKKG
4K7MvkRmsy0MvNlh3EiLEKNt3KqVsYymgXNyKjrjc1o19vvt+g/law/+of19GgYYfgg0hLlTh7E+
jJ6AGUcX2pzgu4Dp+813x8Eafganq6jzkLsvafHnYbvR6E4iU6WHkW0boFIUd1wMzzoovEYzuLZF
tmbdUzelcinfjW6i+10o4T40zgYxUicoqrAXAwgtuM5cIfIGpURm9g4wh+x7imc8RTeSOf3A1bSX
Bmd5xrvdsNqBNXPOeNt4Agd3mYo1axCIYR9OIAooNwVGwvtlYb+IMZGL/QZNmZTytZ38WDI40be9
7sI/7Oa0srRYozWMcK5fzEWDzVn/BtPm5988uFiKcckMXjCIXworIxr51TxZHHcuLcPffsqtaooB
x2RNM4EMakeDwI5rQQZA5FU+WUlfjDLAoS0loeVanrrXf3hbLWUBDwIq4WMqj5iM2Y2hv+m0ZHhf
/6kd1Xr+FJQQSp56uQgJo3hpFdnhTS2gKD6PzQxbQpmUIwh5EIsR9BJz4oquvAojCeTGUDCzSDx3
3mpHGHa6V9Y1Wsr0WDZCEgWidzqUm5IthW6VJYKqdqi/oJKoHiMd4kpvzZKcPsnatcoiD5h9uUjR
afRpGjR07nynDKMqDQ/V975LVSJ23gERGMO+deupzTavrPFnlOdvIswVW67vc+qD5usidoX3F1C0
Kv/iKgfzUHQFe3eZ2sU3xpToT12l4/gU4boLMf0GAlkNr36d4nbJvTi0LUx0PADD1rJRGrbaukOs
3aB0C77o5+RlW6A0Z1UC9OBuwTnJSIEeiP8UIN7SGWmndG1cho89FrY0Emz1TI+wobEJrrD9787m
kiifwSLBhd4GRJZ1Wfte6Fpj0mr2elNhWGG7ZC77II2lWqzUB3KrrQjq5ejaK/PLlN8PtaDIukh0
nf17T5vLtyABYU8M+Q1tiDoCr0OSEPCSlKjhrxRGmg2xzGIMlhvzvhn0r6e6AxLyOsmRfcVBG7km
LZ3YSC7FvtmSSvwnZQ8sIcCntIdGD23VPPkOBhH/EPDm6ZZeViupmFh1PtpOwpA6LHGDp90eQbxQ
pvRSRRN9ydHAKFtu5/AxJmRlsgpG/jZJ5E41ze9ImUtpuxnbece7Lqf9rYaPXb1/RyDHLqGfTsEH
p3VPr/x5erdFpQyN437ksEqAdmz0h79kvSxhobKDC5tCMg4MCaSE0bzg6OxGwMbTeZ+E8tsr1X5m
Tk/8Yit+xCsxh4OwIQHJzK5Mfw4cJVLr7lVjB39Hz+mOcTp9+VRnqmzAUxzMLda1gBWr92SVA6Dv
ny3ceTlHAOyBrd9ceOVHY+GGEL6ZymBaRkZ+GzvpsO2dORojEe1TbJTU+UP/ZVgEqZyHEwxfG8ov
9excp35YpunVqztw710nGY73cdJLfzIoYs7JLgIJrmh9v5XMyoWGnDEjqQauin6p3wZ6vsTI9xV4
3/dqgthM5B6jkeQmQ34WKEB5vJh+zsW6jq25SjK1Gt55Imc16YZ6CRP40u6+bhMs8o4kxaGxAakm
YkGNd7mAwd/khH0/ALi4LP2kvUa4iOrQ+fSZFrnwQuma6e9hZ9wlT+qMucxmnB3spUSJKUrpspNa
t0IuQqxJhpEh+4RCabAD+ah6IVlg7jbfDKBZwYAwmGgXzVtG+egwAmqY4FcQe4pe/3F+hi+FGvHS
j1P2zwN7ysPtO36XsywcRCcD1/83vYulxCHj4d3fmMzjdRJ8T1/tYQLYI4afgZKErf0Z+gluEj4y
etxnYGsjvseV2CjM5ePNBXB7HW2IOQhq0ctp4U9Y4Yo2A7iVrVcpkeiAVAiq16Hc9vTFwMBbSUgp
gPXgJQAH4xUVdEnA2zH3ZtvGrdygk0f/jd6CaYeqGarbMM6RUvzEh0uNecUL4bud3qzFdNsyobRE
l0gxLRYmLw66+iXiPUzTQk2XTYX+bcV9Ek6DM7HELZAL0eHg2lpzRdFL8DKgukEy29p+YC1zfQZD
dFm6xL5p6mdKysO4SNyQwAZXpU8gSQE7QxpwaG9VBNxhSy+dQODx7S6YxHMUZnw/5gk2Zz7q2opW
7sZNQrtmHzCZJOZh9hhWlkNfaTPBi+t+kBbVB2+yB4jLpT9nAsvHh9zJQ06j1Cyu/dRR2SqxcPkR
TXkjVJRv8SD/O68Ux5yfBIziZD3lYFiAJQM5KN9VJDQbLgDosIcFRRtkJ8PxvPDoRF6z30CicCEU
l7p+Ql6iPUHeAxmgKYDcOh9HXWrx/CQzatryubRdVbGCfngc0SImMhXQAauAnL2ltP2Jm52n0pwt
k+6rCQbcEY/qXsUlqMrPOLS3+qh1jIFJe58zg6Az7f6S4pTVZUtDVWA1+Ycz/Giud3OUfmE5LtfM
4O9ISrz4fvMY+5bBPrbk0KdIjvJ3sLqBnN+X+nLk/mwF/OSfAKLZL7wey9DwGhSXoDGLlLxu20LV
+bc1f5Gmnz4bcrFFkFvaoPvAbwvY1wx43Yy5DiuVb+P3nWU279qr2K442to+m90Ndi1i+I93g+5K
B6UQAqUxEshF1/OJFCBaU0Ufz7Okay2NiC98Dlbv750KjeKTTiGRGZoRwiv6Q+1bD04ECrmYy12I
o4qMEWHq0fDrKZeKWIgEBgUJ/laW/QwV0rIjQFQESSQl5CsJ4u+3lXPawBTSwp0tB+kIayzZ+QNe
cHovIvI72lZ7NUiekL5hbD6hfGfieq+lfoiKyq+DErr2n0NuG2/6a4zCk9qmFAQdAKkIcMLfFf9H
oUNjNwPYnTmh+CGw9k5CkC1VN2vo+ueiVXNkO0b5GXwXj/siDfc+ZjxCWQf5hPhY9yGr6Ks67yD2
qTfA3r00s0omJo8xujXkxaJrdSTg8GcodYhgcs6jmgRvoVobMokTG7UnUuWq6JVFa/A/IVBzuqwU
cL6U0SQ1DcGOVO93o/ZZrad5RjzlQpByS5CdciToewFz9QO2thNrwX2yuwEEYBDPmr35lehohh92
f2+wS7eMvMNJlFnIfHkb0Huj6qYXI7dMRX3JQ+UC1J9JPTXM5pyAClv8z0p2jAiO/hStz+Rn9RBz
tToCU09NUWRAekziFiIOuNWF2Mf10w7grNIKJMEIDEwju0h24VL/ICUxAwOH7ngVfPe9kVe3eEvW
AlwJnjEhmFuBusigDvdkhKQULt+HKO/YMg6Sxk8XdOG/Ub+TPl31rOXkkuJ5DIBQiGm4OCtEtOZc
rS/JELfY8AxfUMJPchP6d40LKjCsthxqteU6uWpb7Ph0upl/GdM2SFxw389GPA9Hpq+mLKC5J8W8
DulNMUPPxYLeCRVyra4jsUJvOEj/Sg9nBYnLAYh+p8OS8PIh3doJm9sUKnO7Zq/u3jf1o8fqRvTL
s8CYoxJnzLwFBxNOxqFzukVmsCraNk2HB4uYtuCFAxk0yoWXvtFit8i+/sLyhRUt8W+L1yiRKPAh
U1xqziHqhpt0De1rrPebhfwHBZroi5lDnxtpQTWF4ukB/FlOH0RSkkoJ7xo8RGJOpE3v3zs+Uu1R
wgrqJvYWY5qpYxD6KRx1wotNaYu8pMt19mzc5A7LY36rJmzkSnRyK95/sZHZD6ftiUKw1DeD3G9c
BOlipovVqkn6afxNtWpPeX7JZd7LkdaNaES/+5bCLbTBEg9USi2Jroh8VLt+K75N5Wgm9SDgDg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
