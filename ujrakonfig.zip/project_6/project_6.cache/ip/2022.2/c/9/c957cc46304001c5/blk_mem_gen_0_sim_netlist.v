// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Mon Oct 26 12:57:05 2026
// Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_5,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_5,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [2:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [2:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [2:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [2:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "3" *) 
  (* C_ADDRB_WIDTH = "3" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     2.87285 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "1" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "8" *) 
  (* C_READ_DEPTH_B = "8" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "8" *) 
  (* C_WRITE_DEPTH_B = "8" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_5 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[2:0]),
        .regcea(1'b0),
        .regceb(1'b0),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[2:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
VHPlDkoDlWlBfBMvPBmGYmaek3s9hXXhjF28kllYPnaNm3TSnzzpXHWHc8Ye9/2L2yiQfJ1hTWou
Ia/zeQ8h9/dtr6QB5YkyW4wlb/LbMgXb+DGIXPSllNl0IMsRQIcQDbcQm1bO/nlhb+2pjxiuaQrl
DbvxoDwPs7z3LunRxsg=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lmIhoX8hXuc7tNV1sXY1K2/gXL7Y7Hq73qQF7+x03UWWTRd3uhGmVQtOMVbhIW+66UkWUHiD26zL
fzqGor8bgSNGpSFyS11k4TwLQT4OfAMGO8C9Qmmh4+VENBnpS9TW+wHzCv8oUwht7xYtYRZvOvYK
F3fMppz2sBkUd1lciw98ZE/UmNkhqBuMfIYF43j45DEJ55PBhOZNg91Ls4v3qBHyBAaYPFFoMry3
d5Fw1PZyFQSEOSSpwgyds2aN0g6oIwl7zm0LJrM9VDAOxBUE50hk+oHr4jj8J8UhHQJnlEHm1Idm
rvxKygNKRvfSpa90NYxZJFYgqnrMYg+19+9aZA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
VkyCjO2onoeZWEoYQ/4ue7X5mkHyTYVW9xjdoTsGS4GdP/Q64VaCZL/jr6R8DVDXPMnH7tRMrDpo
jpYBnyzSgOkfgqM+96ioC2fDyAaG4gYgGLmrBR6qK3/mxXwAZZX+GJ9R/eWXkc9h8xN+gsSSX6/M
jIQCgeT6q7PB4dWT6KY=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Iub91V+TnhVlZCSLu6iKmFjix71y6/l83OPTs8uewWvkE7WcqYxEKi9fonXEkzAtWzuKwEUqnOlN
VBsNJqPUdKcd22q523mrdt89mpdosWD+hvZdO7ELhJniY5u9h49FFkubpN2JiUTcIcKEYxVNlds4
wyvaYUqbPVH5v2ooJwDdimS4GVn9HerCOgPwfshvQDNlMTxLcYju4v8BHMc5Rub9Q/ihvpQU74v2
ouZ9XIwA+C6pBLwvaqS8jE7HXOokgqJilaX/W/t+KEgiFry/txRTMU9WMD7tCN7lcfjCydmS3Lq+
3u6Hsr0S8BwNjcaDpZDnBTygUJd4JSqREnk33w==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
U46EWFmKmpZGaWfyL+dokyQtJtaOYsa7HCW/+fdtw9/yHKTWFpmqKBZngBj5rPkNhtTDDCJkqsYj
tUXg1j4tgIBaCQn9B0q/aG+B3gPLrudp9hLL25mVbsfiTzdekiV2hJMmhuMoavKKPJHC6zyW7kZi
80er82OQy8h+Df/fe6TRjH9xEt3/b80tRKUMbxkLfnnkAyyf1KfOhB6/uyI4mwXuQR+DsAbzybKR
YtXpOiW72tGrXTFlzcwbHamWZefqsilVpBw6V5dh33vYKGx50xwWpj76maAkpQrOpB7zufeldJe4
W1UOEN84AZdRTLkVSxamWo/wp8nP9fiGS/ItRw==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
qczgIJYpE/SzErzK7eWJBGcDFEzDLm8cKbwJbPXuM6YnJxx44W+E60R3war7K2QGFAkOoCDUtDC7
SghJGF32btaDLzeKm0tQ669sBtQmMIaBrlt7I9QBkNM8zN9GL92qxNC9o3UVWMOYy5BmH8nUPgcE
O6lRubeltlrTuDe7UJQ2nEPHcXjpUJJ8dxktyW+LovBy1OxW8g4GRAsmEJsoOEg0HuDdWcc4IshJ
PvwPJ7LblELAKsdkSt65y9VaklaEm7MlH4ImlgIa74TgRmutLUbWxM1QYhGE5rAzFhGU5i3RJOdx
L3N7GGGvLMW2z9NSHbIFX+/eNII9fNJ9nZbgLA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ti1NUgDv8YPk90APMwfu/mRr38QYwAxZfv0T6zQ89YS55t2EquEGVqrEafYX6rTydLOw8le1Oucv
f2oERpSSSTih/ScZneSZmuPE/Zh2BU1Ajv0j+/+0uEWXU+5lLPbDJjnapTmJXih1MYPf0SHpZZmE
BKj2IEBI9MPZlh6bxpa5BWJnyPdAvHf+UNaMXU9+pmbtrzUVebql4mFJu45Z3+ehmFY4FBW3zXMF
44C4TlHACLwL3vHVMCVfeKhgdVDbpE+/IFhTStz7mZ9h9RKGanQcs6YDVM1R+2RKA1QT1fX4FiQc
1V+FGmrm1ujxmFGXwpfNKByVlfCY0oWhRJCYYQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
HuEXFK0NXt09xU2yxxjng1OLsT+ZEM4EhqBgpr9D2ljw2vDaMBrqEsRQTc2B9soDq3ewDduHJXBd
OGYxkPnoN6LhjULtB2nTgjcH6NxA4puZ1ZNcndDndVBo8rTW5W1OqHq6InAG0CqPpTIkuqz3ECPl
EysI++MCDfH6tIzlekxJFIJ1McJsTq5rFuLzMMcrmkBxgcayDpOcCFuzZzCczxmt/cCCIKmDybwT
OQXmOcLJoYLP4sFu6R9c6xO8i6p++crv2N3eIxZHKbek9xBBZqQM9EYuEtsbkqAs9XZpa16i5njR
BDFxTKcP6r7JgFALJE89AZhBbate5JXWp0v4ECZD18aEL17CipwcWPutNMdG1apzSPP5y59n7rMG
yxBPz1gKHc3Emkl4WcO0hjICxqmO6dMXoY8JvBSf6ry2l0sH9Ihr3Bq5WWmlhPHnoaNr5jl//vNe
KfToWtn97eoVSt1LnmXXnSpdigbHr0UIg8AdkpdkuNRaWdVicDdgSo49

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mokwst2bn6UxD6V9UdIgCIG1QQ/d0FiJqYGOTI2eHPV6YElaLjnJ8DnQmZnGS95o3x93FDOoa58C
RwYsX1fVoVtXkj1LuZq0k7q9vEe4T8xMjpkeYtIHY9k0Xhy1Lq/xRlfzGAf9fvf9e+f4r7aR/Sb/
uCZxxugG5niTwLENY1n3NthYL0jvo8Fmdw4Qg0nTCGWlVCws+09K0g9/lx6I9EcuHHemcHO3fOZG
lMc4NaPNozKwnyDMoWUkwiVxyFEPFaQLNYqzjvR+CqrWfhFLo96JWhL+eaDoNuZoBVYQtNH5ZwBL
BoO27Pw10lgcReGlZBz3BLO7T4ddynCx0+eSnw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
PiP7AjOQqqouyQMoBQqgWIDhUSViq94rIvGiIJ/UKMDspM/yXw1caE8AhWHTjYckC4yLpPAz5P6s
1Z6flzDPrzVwg4e59X2cc4IMCHhedna0rDO804njcc6amRDTeLsMLTkWfvomB4xwszm2AgT+PRnB
WHd09ZUDVFjiBXT+Oa9AicgGJHrX3w823yBPuAa704kje/SzgtiDpcTU1eLmLhLW7LpEd9KIHd9s
ER7Uk9Orws0Kq9PMTqMX4hMn5K5mFakOeOURiEbUjdv5RiIJ2g/PlQXSItM8fHsBTQa6fOaJwQTI
vHwK3a8ZBHpfT1YH+n7wNiNUZwD4SFXm1QVx4g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ul5ZfTHJwMctaNhYRortUZizYMPYRef7uYqPSuMkxsArnxI/cjGh+KRMwzV86hyp/6TXSJIjm5ec
2wX2UONdPN+DOJ84jYC4JbgJQrPnTj7ioD8uLX/WlyPcQzyF5keqFgj5eR5s13FskVWCuAWf5m9w
mhFEKFjVXDAr7gVgAJh/hL8P6Psrnf+LGfiM8JhnDepsHEYykGlpD3fzru2BGgqHWqPqFMcnyVGl
vysaIXiJz/eYKvO8RGcgd3DJAM/wPm9A0m/DWcmSnczOgTjoqkHcBg2H5uJMLvufzmjImi6LYEqq
v04ESDEN31cSUzqUYcayvMFOnI/WNsWbFIa5+Q==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 20208)
`pragma protect data_block
AWwqoQPFK81h+G43x96QDH3wsOcJB0MaJs3/1Mk56UWU1bPLJAhll69hR2G1/BUhshEqe25NmcZz
VvTIUeG//+nXTGy3sjZ2CqILgdve5CtdUCUIUODBARx/pkfIhYiY07C7Shq5eVYd8iV9fugs7bi8
lezCRg03SAIJSOlMwZK9zYtxNgwi4chsGMY4RTpBdISlY5e2xwaxevb/DQk0h7GMBfcPy/PBEuw7
/qyg8wEre8BA9i4RdCAooEovAZzIkPjuq2LCnyYV8G1ARukGmm5xgk7gZAI4ArVmCX6bSzk1KSnq
Nx6VDLwY+CWAAsLtYLmUbMBYpv1sSb5FEOu1r8+8dSBucxKQiTnobttbkqPHbRA1zbaUeaoy8Q4o
5oE4L5OeJFkyeRJ4Fu+xXNJc696h0SfmAXDPJanh67dnIEqCE5LW/D2VQCMEYDwlXGMkZ+LPwUwL
LcRxiyAMzr5H4IAYOJdCqN0Yq8MXF6Y8ptQlZODatfKX//aMOUWcTFCVC2aGfzzy/mHDH0e265yT
nbb2nBA7H8kwTQi3+EUI9NW+fxHZc0hfF3HxQ//h9MGjSKme/1ywbP6mTmpFjKTucAPlTv2s2NnF
pNHxklcjlm1uINTMpIE7cSy4FcfMdKWd8yKyzujeo5oVadRVJlT3ioB6+H1qrOAbuJ4TopsCAJmP
GclS1hN3Y4Qpdcs/8uV+BbcOSJFYAC/kSr+5EHGCIIk4r1ARNeyqVf+gcOJZyXom2x5RrJPUPJl8
Gfbi8rLPTLWqDZYV4YWHb2se0ZU3VA/ZhmJ8XV/J/s7iCjIjmNO8+j6/s5w6jFP50JtsUX5YbU84
h/B515Yyv73wsfG0Gl9gcD0ThwouhwFoyoWkMdyhdseE+x7qpNIbt0qIm4NT2eV44yufJ8fxup67
03sLwxYpjLIlAlCCD6Kmxa2eT4/n7xlnaLK7ZiNSJApcf6qb1qKN8WOmUtcenNVkyCA2J04nu6IH
ewkUh96Qw5O2/QjTBrFft/wsQG69SCLEHZUq6sp6R4ILILjYptfyE/t8Z6NOxh0w2aVxvhZZA2Rh
Ev2ef5Hz3HFNmTvzlVoah0buipNZo46MMVZAHKgpGBdVwmMx60X/TS1kz2YkolrnMj4HiJZyarRv
3J/TfW4Z4TNpOz2ssNJBomEPQehRzzf8Za8HFXtODqDF9xM6cKz1vvKVf/rTXRfLPCyVpbECXBRq
lTBQmCII87m5+u3j6AvQA7xBmpixHe4KDybfhFQinre6ARO/TwDGrguhuGQoZ+7VpyLcg4U4LhLm
F/04mRopf8wPoP1rjF1MiFYlaakYmzy9hGgfKXlJuEmu+kcAfkI2yyunL6N5x50dnujqEkck36TY
Atz0ZTlgh4XFM7G0W95+YY15h8Z9ZuCNEn2SYi0MVkCxOPTpp01ziDqHo7ASPu20ElrJbHGre3Rm
WjPhZrbLTY6SmEZVZfvqMB3iXMde1IE/F8mEu21Eixg2NyymDblnC4SkEi0lEQx5aEtaw9UyOXEw
HlEl/4l2Ysr3CNO77P2LYpdIQ544dEjSq/HavUfWTAgWsVw5ZQ1jqsG5Icvb2rVlecJFug3S3A5y
rMLkGGApoMc65FLLyHAb/8qF1Y5D+N7CGo0NEWmPVp423KBdtGjZzRLAEeEi7uaJfxdWlZKTANe2
1t+teXD6Q7IopVI9yC4lHbTXiUfeGCx1J0W8tYkdBUHG8SHJo0YyQb5s7ZsZUOcbvoLC/zvhCcw8
Vd5Yskb3XW+rv4vR48Aqi8NtE5nV3ccnI204UpHf5oXndyGIDMKVrEIhNi+l7Z8c4bctMUwZwQDl
B/qTMdTgeA2ni3p/4euBEA4wKZ5h4ULxbh0ENT6mARjmcey0gwkceq7MMyw0kIW/osQey+NKFuU8
tufr9Ts3ABZPsPZPB6IvfLND55sUfD7nXHL+q0MOISvD2SzNZlyjfBG6ECHQwz7QE/I1+14hCpzx
NvuBk95tN8U3EYia0PFpXUfiJ+/wi4jFCNJ0heMSB9cj9eRCUfgGqbHazb4wNj7uCT8L1yaViB06
HseswTLpyhnpdrOM2L1QnjAzcoKJG8gqXMM99FLJdajmuFFtNwlEWuXFJoilWk8svjvEOS0YRv0t
dhihqZH8XmdfVW1/aa1wsidD05lW1GJ3I2NWLKsfqtFIvKP9V8Uss2h/C1lE4TzqQ4AO8weC+WdT
iaXU28iE/ZWMQDsmiFB20jDGmXspztGpmwCEtXtvftxbS9YKWQTHS0Y6uZ+panxnA28e9Wu4gdnO
A3obZQ1JOoKeHSQOSk47C+oHoBz+VOEXpqI9KwlEBx2/ip0DoCh1gcfdM/k8rd3qCxPvN5vlGkBt
QRzXms6QC9Sr/TmjwN66Md9wHJj7tm42U8cowMRxmy6Yq992MgBuzHVLy9Z6QVa49dBvSvpGR3Ol
7NaT/TUfqP7Rg83eggrwIb0N1qnMAo7fqAvU/hvUeKrzXg6XPt7thrATxkW1t4pFz/k3JViUdiQE
FCIOJOGYjsO3LRS9ewNCbtEWy6Plv4ihUW862a4ynoK/uNR8XkLD+J14vuKQzGjb9hWfybTgGGsv
2Tk0ZvrzCsfegnb+lH7a3ImXpUlwb9VmvhO86Ny4LG5SXVQVaSp2j56lHlBWK5/J7/d4UM1HvWsv
ae8cxY1VpNe26AFinJcQcT4WdJ9J78j+pAElLtifHLf05h+Z9uHEUiAbSSXSY+CuRjgTatlOGER9
ogkYVgu3CNQmj1kYYattsVTsqylfwKsqhJHGGDZ2+LE2EjSypOtkx4CE8n7xP8rGlRMHrtusj1qt
a00IDjlf8oMTwXsMKwqj2v09otQ341MElfpD4CAJvq6AxaEWoa4ZkxQWnxpUqBfKwjp+SHeLBx2U
WRkglWm3lJ30xaCGXfySLGQ743S/PENcbcIKTUn4FjQZBSgbAHDMY1XXoiTRR0T2HattA0ToiOfE
hDxn/5flfKqf7zFOVNdYkH9slzqLjoP9azT2liagxOqphB9Ch9s2h1wwRzQhUVjeIAFbnlVlAgYT
W06ePrUQQCUxW79YTTHw1TTQAvHp/0tMyRCLQNvYR2+sTv4w4H9FzcTFZRe4ThGg8R0tVUc8NIvj
/TCIiCfIJFdbqw4aETZ4TeteSSWFM0gBEmWQpsmvfZn/Abh5cCeLw+q9Dlb6PGEKJxALr1UNL6gY
f4hZPbhorDf8ZDPgcuQzXAsVzPS9JnvbyqvblR0ArhQfVemBRCarZgyv1L3OH2yBXRplD17PGga2
0XUQfecjQIXujgSnKtkV3ZXXJKAKIv4+1EeWzd077nQV99SXAPuo0ryPgjlCftEz3VvE46zQQ9jX
j/WcSN/M2erGzsampWE0C2bqGb/J/iVZAYgL1x8J64YzVBwsmucOkLC5poaMYVtpUGKTS2zvSZB7
6a9NrTqRTiTdrjSxg/kWneCGjXm1dDe/nOAoSkRIGSYdTfhV9K5uzTgJCycIfuV+p7wOyp4VpvNe
3+sEfanWHMqEDRqSzsZKESUIzAT3gFyI9l32a+3khRiRdTgBe2Efmn+REhMZYp64qq2Qe0kBfGIt
Qw+UTv1WQiAJ/QoGBwhhf8AB+DYZ4lDFFQEMQU19CPs96Xkj91pApTxTaOJhueqOSAuZz0yS3A6B
DGfTRQe0HmWwAGQikDcrRSQXOIPe7PtstAq0Uk0VacYJ9nfbdmfeK6m5wdQtcmFf8BQobijtLue2
8PF6aKclhpOUDTx/9ctqPiUDouc9i2UJsNp1mFs3FsQArPP1SiSWGTbriJtxyc+LVPB/gWyi0Ww+
UkZUuSSZQeCXtc44Zj6rOF0wtRYtMLnmecO69NYbeexXC5WHydIp6mWkwDE3lTZ+pytBWYquxgPo
Qcmj2L/DDNFNB4LmPPOWdmqtXXlEUOg+ETCNePV9U/CLhcDjmOWwxqGJdN495AM0V+zImHlBK+Ow
OwbEpjAoX4rPFx3gGmqpA7p8i8LjwCO8iHW53rfH4IbZK8z26JIYsnSpGf7PHGWuPwOGL1+6+DFH
gUdMUtCc7I3oqzzfSVIMjPcIW5JNWqb9I3jijlyUzOW30kImeAbgvsxKwLPIVRi9kUCW+2EEKXMO
rEQPSbo6Pv3UKFvbkXOSYCLieLZuq0PL6HwmSJpMy9HU/96sPBuG7PDlPVwe3IxaPVvy94PSnhdw
rptKeeiKReiNXy5MkqgPG+9m13Qndz9+xJ5RiSpTmIvwt/zC5+dlBIs6kvoQVeVA57SCMuptxkiN
uGPEFnzgC9d/D2lO7ZmMUMJTf9Inkrzw89MvlSFb2ou5YmiJWwKzcJ8jsK84K8kXHUgnY3fRIR6o
KFmg+ABNu1MaYDOBMbPiMk4jhD5rCTFTMMzoTfGvZpcxMLpCK+yAPdbj+TCrQ1ERI4Rr4hwLPBhJ
cGsjD8TYwvz61dnGtTc+2JVsl01OWVN64dPUA/hFmplwooFtW0cnwcenlWx2pvpMlZzH/ky9O7Ve
OfcNnJBxVLAnGtCqBiYO3ncjfdxt60kJyjQfB7avZDXXgSCTTTfwxy4V1ZJwHj6LTHZzgM36F4zt
t4h8jl/Wt1BNLt5yFKJjwB2Le2ys8UOX/6yOGZREwq4f4qXuhbyDZ7Qb2eVg4Uc/r79z7XKw1WsU
RIFiT9ullgxDYtvIqwtCESBS+W+nuAA1fv+EtWire9EmoH/u7AkC2dFrw19s8NI2a2DEiFqdiA34
7caR0O65CJUoG/SBzMqDDdZjBrvZQppUSfs1ZSW2NrydCfb4C0ee050LP+haa3xMobhoJJ2AfcOd
SC5D6/0KajICwtyaTd2BCLi8zQhWSGLLiEx9ytg0RdPPt9EYybJuy/8h6bBko+YRTgX1+oSQmvWN
HietpyqmI5Ii1v2VIoX7ICyIzANy+xDdKmRm4PZpQdFvbA3lfigKlbvfFxOPiGjTOIJT8eamya5u
Kzq3MBdRiTLD9ACmnlwsOvkzOCygXu8JFFgj0GmOqmkE2ppxaX3fB1fn9iZNUCoZMzO3gtroR4V2
/8aOFQx2FlB9is8pVn4/eVmKdjWuExkjRGVeXec8O8GI2vqrLP0B89rqRQmjVf0rpuv2qPZW7F0M
H+f6xZqcel6UijVZWpAgNzsRP/FF/8k6HBrh4cO/k0bVEhCx5U2RK6m/GBIv7rUykoGwKEFInts0
Gpdky7znAiHkQNanneruJaB5icePXlDYVs5Mx+kfjJgetpcL5FsFaWvHnsejBtqWZQS0eB53TVMI
8No36SimrcqRt7L6NgATmIkCJMsefDXLDFu/XaJDCB2j0vMaMIXPvE32Wedt/lgoHpqYiW/9D4Wf
z/T97ixWr9C+vK7px5//DVVoN8PjcS2mmzs/Q/i8ABV+tLLpKS/E7LFBAxdnp5WU6y7K1CYcCZnV
IHRnMbY1iugH2tLEORsLkr8plKmd8rs4Lm4v3G46lNJ+PW4MFrVLZxuVgfUz8PBEMEInkx112Rw9
ak1dbtXNoXZBzYnrH/3KmIAu1bagZHqVuw3PtHKenyK4E3EmtYypSHd1NKbPvVGYH/qzT7+16QPe
xiIhbrpko91tTXfo9KFMNL6TlVk2UuZWuGzM6AnpLbo0qUN3WXAP5JAH96MFQgcP70GCwLy4jOtX
55ZP32BfuJwEf4irfAxmmeYiLACpXLorFw3PSIZuOH11g6+j2bw2mu1FV/i5qf4BMIVGTnBzrlYC
FkXV4V+dtMTO/L15f8O/Ss1qOcE0x9Cw8R/T1cSCUC0RT55pucG6cwgEE6jcCVkBidGiTCQ9oqdY
vaf2o5+cS/QXY3fZ0PTGdUFejEgdLsiS98LbRKEI6ca7uZXgn9SipUTNqNYvQtIbBn23D/pCw/n5
95Qbq2jERMe26CRZ74LU4XS3SSB3TIkHQ1z05Siab2dO+FSItPcK1xUsxu2WxfYF8D3XqVi/Qcql
+EDw9I8SkYguPey4Ly7X0M3ETYQ+9UAGLn1/K0XgHWIlL+3XCSuCKVHcIGj1mVR8m5Zn/rm8Tp/Z
mczcEe2nDSwa/ISpqwVVVqS5JxGPfyn4DGHDsoTWpnfuKIw63Y+rqUKcd7IhsHd4Z0jfgdHuFqkS
Ou2qust9OnPvt3Zt5BFR1fq28bDpfN1XGILGBVSRIriRZ4UgJ89tTKzqQm7yVmBfHSRAAc9W6mm2
iNeyh02wBKfgwU/cXUHaDVjhOSDThTIC8c2A5j+Cno8WkkxcsD0SRPEgYC0Ot/Kz4/2yyxCu6nvI
YppsoFkALKD4oTXNeBV6Zbne/QYHQGjrhmfzLtG2BXrtZHq2pl4n3HGOrGPujeWjVFcG5lny3j2v
waXuaRQY5/NrAgjjI+fJVjNx876ZB3bUcaqMWcW+SntAjf0sdJ6YlwxW2qxeiIR6AvL2AMneQPhV
GJcr5o1NsBM4VfSdvkUW0XMad9Fmrj/NwkGrQPfeXqvak/rm46MpEhGILddlzxJ7PWDljEcHIwR8
jOAydSrzr5s9nSDcIZsncY7BIOzQQdiG2GakEUQ0BgDn9ROz/2jIIK7vnMAgHpYiv3C5VAqCq7VW
8Vxk8ZNPa34Oo8dluSN6iAtdwDUyfrsueHHZLrVmvrFCopej+GExobbTBLileKaHYXq7LGSuayVM
VKJaExbeKWBeRAuwXSV9+nR94RdbhwvnpJzWjfIluUxPkmIjffOtfOdwiJ0Iz96HmLgR9TsHxcQY
nOPFfdd5GsBs3trJgvZMikOouhThycw8iWxwYsFWrUcaAD93EdWeMlJpUGiDbw9pe8kchRpformp
2TuLdWoiIT3IpiVJBwdy/Af/u63RlDtnyu+qCAbn8MoYCyjfUCLkH8JCHSPheciDkdbVzES0gFmO
viyiojU3VEeWestLcvj1Vn2vMlYD/XXE6eh1uByWAViyeZis1KQvA+5ELEKqnCHjkQj2o0EcXdij
GC9FO7tCmB6GW9qIq9JnqGG74FyJjEfGZ759zKU7kJIyRNdj3onso2QXjhi2gnXOx0aVEELuEI/6
sCIM3xqonoJMm9kiwwOCHVkr26n3BrUIUNVCyC6F0+pozlzHERk+LR6l+fxXK02UAhk0Vif0Jtqy
386B29WW8aCDoEf3v9JZthEMIpHvTt2ojVM7Jfc/MfVM+6xo8m7lPtQXY0UQhp2AL6khnOMNZ+J6
1z66S0ObPDCSvVH0tu7+PoClBrfr7BLKdzzZ2tAxkx1UXBeyDwBUm3Qg3rrcYAi59meKSYP4eyTy
dmS4IeXZgY34Rh1Huc9XDQz6SiaRxAJehyK/vR2z59hpvaEzC1nfMTwYGVF9QBxXhrqWWtSlGJo+
lPJdk4+wEg/XIZ5eunYQjkbOIu8Ea29QKYxuNiB8NnCnxA16lBHya++wCsEHPHweLq+0arbNA7bt
hcLLo+uz8YaYBYQUWI8Evf1FmDe32/35Grk3X0YLMaGlJmaFgAQkrvPY4vcsygFlooVnERHGOiIs
jJ0KFMyvfzR9dJL8MacCXygA+kXXmtpx6vVzKObyV7wnxbKtiQk6mtZwlcHP9+6SXAqKs1HomXXI
eo3tAsWf9Vyc5OS5wjGR1tv8Hnk6qvPt8HJlAILb7kPff5ZakGBzPQn4C7V7xbDQZJxU4dr9lDF2
AKfS/y/sEQyshUvT78rLK936pkCltya7TwiLCXNknM+p7+DwMLgjv5YhDVF0ycXbWorgXFCFigri
MarWTj047AavggeOzaWAEhdrO8++Nvvx5vOqmpRwfSel4B/k4cA+fkttr+p+C5lOlcPUbxn6q1zM
6AOv65KR1iNXRNPtGNS2pubu8dhDjhwg1Y774iwmdCCjGJ3EeHeRe1hcuXCgh2OLpSjMS2pE9C/2
rujeKuVztsYnDkmZ7rwwFF0yqCgt/caiJsF+msdI2W94vkS4EzR9Kvqej4D0ZO1Xq4hc7o6zH3hB
oMjHSUWGxXUAzMvzHUUrizYHaqfNJeHZ7II7kKe252Plk8zFDpqoALCFq86LXwR1rbgc2ZU4CXDp
nO9dEE+RG8z1msTYBUP1uu+RlG7x8d0EtHqn8tqY62hLHmjbgpyAH7MGzs4uBganoVTgk3TNCKUO
uVQWTKirDq9I3r69BzgGnK/gTqrioN/NnpPxp240BE2rF2xR/e+uauOtarebOtjxXpfUtIbzNh/O
czSQHNnX7oO0thQRiPfokgfPWl9l4knmJZx1iwrr0DnSJ4oEfLhLnC0/0qvhYy9ok8YxT59/ifad
HGOx4JOIAC7EL4mZWbSl98LXcnVej3D3eip0KIavvWTKdtKNTA56jRHw+vLYt2RN2s+Vbm/PQa7m
P/ex1nMO/9lwukec7o9JulFChzx06dMpYaCrn9krmOcb7mbAQB5hgnGarc298S30Fg74d4jEcfMl
huR08kMfC+buPRpvB3xAwNKw4OMoN4Y7kq3MS862ZPy8p9L9Odeh+ultRdoE3MJqnQOHnNv43U8Y
m1j5oC//4zJwImeiENCjM+DHWWfjVNflphWiR/AIyim3xwR2AquGDPqoMrEoQdS9KJuy4HoddkH6
/IC+m2IJqlkpa3oJkbuj/vp0iLikDbHbnoiNpWSLQfR9lcdZR9Z6UY9NLE/mO6wJLCFLnbVlN90z
mhWuA9UqjXIuGvG2jSZ3LGMYISyOOFH5rRUKcjGnGU+znZEBm+r5kC9/uQmSrjoR6OgUMGm1hBP8
pqQSB3qvmR9Fa9+s7vh4zraXddQnoDi+LncdhHzTPEtZLxx2wDk9Q23P8eYY0FxWSK0oMoJ4Z74y
yfPJPU+eaeH2ClQ8e8IQAugv3y7O2+yFuJbgF2p/QF/Mo1002m8gbyAa2wQXu4Lp4S17GBPVAcNw
2kCh9aPp+niWu+/eSLYcUruKHw547nZSI4dyYB1/f1emQ/JFLblKgdW6+gAXwGO2jQqWjCAPRsCK
XMDNqIYRGz4s1JBBU520nIThVGTyEmCSY1xb3ULtBfRm1Zil9TeFezhSXem2GdINnQkIeB9fentT
l5sZnsMvGM7Q3EpojAwMW62gD4Ix9ljb+986T8d5YoevRBV6LTbTybDvf1Ho3uluBAu4vQ9ypgqV
BG0oj04O87/b2rP4bnIp7bGsx7rg0OkIiWjsOkorpCNyAk2YCL3TmWzvJCLGX0wX+N4RAgtMZ6D3
sujb2hWP5WFVwxnb1eF6zrb5nEf+ECkkYF7xBBdxGDROt6FtasIEipn6KwTfg9vyTSAjEkGBMQJv
uotxphJb7J20r39bdDZM147NIc11m/hsEcsclaca62wUzc/i4ZGGrK4C5Jx4iwmZx4IjgW7jxUZ3
g0g/CVsaocw2/os+yhglEwtG8c09r+gEGOeJJADxm2w/gAkiDLyP60ngCynOuy1SGi2GnBVuuoik
GQbjvBoYFvPJ/V4qkmy0mGZbY1YErQiNE8JugiPXvcmKN1wSzExpDPbkpZmgCy6lY9KXuyDms4CG
2MsitOOez3hMaPZDT4QSC41Oh5QC55i/OSnqgsUmDGJXM8FRStCIJoeQDag9GmdQEhwuCI7X4pn/
U2S4Eef60jWETHaTD3SLwzts6ZDcur82arQMf64z4wMZP7Pyv/2niAP8637Du2KFMVPe8Sfdi0bZ
S4/LlbCoD8UbW4fesqZ+HRpeCWvBLvrEu9e0xr6dxQStisORTwTsCBS5APPoide97UK9jyH4tvYu
hBlCp6A7hXGoBYb3gKKnfJ+0e5M2V57UKjHBUU3G8II7fnUM/xxCEF6HJ3jEnWobwU6GlOP6/VhZ
y/gJn5fp1PLaemUtLrcGaJO1NKRhsHSfP8nx48UZx9n/l1ohWQKIyq3KW+Kdohh6TiGwEij+Yx2+
no+GarPKLmUyWxfWWX+pmaYoh7nDtrisUEeFDW/6zWcLH+sj/bj51J3k4L0AbeajWqNBgb6K8vtY
s4nXDNqPfwyzDChZBg8HNR7fUwOhTGsXnEd8R6qkQdLl39bLgnu6G/g6WEGOBuDpgDMRzMQPminA
m06TlILW8l9v8+EKFxsLpUMbMA7FSp29Uipz1tV0iJly+5+m3JeObDb4SFPr4/yHXSvHN/27/RDb
Dw/jWTySLHA3r9ZU+ZxzoPaY3fH+W84fPOu0adqr+cMSyV77iFvGoJq1HmOSfNqJKoYV8dcxyhRP
LDKzd2EhEyUdcR77CT+kkwclQ3MrrSzqLtddJcpVJ7kUFqzTp57ZPi1XLjIzFOn1XsEyuP7iGSOi
ukzozITY6Zy+leVa9SJJc2Niy5t/kjUu/w5FP8NtTLwL5qSzTfuNFIB3i0wk+SrU02aiRm8ztNM8
moICmIGSJ2j1MJ+WUt5jM8jV723fFjsP2NM+yHc0TmSjYkcl4vIv+hCSV4o+N6e5IhvyOGqWxhDr
PDxHgllq97UzeoVVtjWSCdgWuQGJQxSWwO1cmrfQt3diJFkSbOJFbctoQpKSWJ4u16LuNXyIPkwZ
K8V/qGV+eQC/vmMAPWsuoVn80w3Fk4qr96ojdRP5nmmGsQe2ke0atSR1/4GvRmfVJOB0TAEiphKv
d2gmU83YYCsRdvC3+BPNLMnaCajyuOMKw7E+5GofcEGHOUivxuqSJPKqn+VJG9HTEpHsnP4BA709
9Zylg+pSBZhL80S2FSkiTWSeXmfLonzKNSN+84gKH430K//MXAeOY3kAdHxmDhUcj/RjkCljFAIJ
U9Gz/ubggBW7L8Xulg0McZ2d2a/em/i7OtVnBKznf5MjVUTkQRyGKKMYKN8DJNs1dJEQH1yuil+B
/STMGhJZK4TrbA2WYcfcyW/wq6tNQCZBOAkWkzdMJflLCGkjKtlALSf87fKIvS9OjC0GmloirAlA
g1rU5josb7rolGhN3EaUm/uf/gr35xsjTiKupkcZbtZOllFpiHe5SfsRHBqCB1u59/0+f0KfUfgs
CyZ4qAGJyD+EqE9XFMj+0lK2Wfbu05GzoJb/mqZiGOFYNikuiuGxpOmJWQOmzShCyu+PPq42pQsL
8bsaIpDP44qMcCflgXuDvmeZJkXXJAmUl40COqujCIYKhF2a46MOPQd3l0NAtgHhyCIuqQKzfVSq
dj1e0VfLA4pHsSQN8X/xbNWDfz4KVrqTx+t7H8p0JhBKTv6Wh1iQw24GX+dydfR38mloSoSUP6fb
rJMVuO0KHdN435PaQ5AfZmoy6vk5w0iv1+1kaJfmWArH0EVlEFZXXIl8tJK/X5dKXcIDzelKuoTQ
x58ln5/JoUb1VhiVf6NRhT8Zrw6Ogl4uyQczk7D8tJ8xOekJS9yKkQYF0wc9jgMayW/QJW4M86xh
2yfxNW8yIFTNaeZpgnDDmO1XXfIO6U/Mjre7nPlnup2UdSIyiIkTj6TFDZZSeosf/nLkCo/lm1KR
eVvFYIoapKv51A9nQlY7mALamQ2Rfh/fQ/KDsQpACS/lY2Nr5N4VjPRz5lbRtlj9ytFAS8CiZOM1
HuM1Dgu//l4zQsxAiItT41FemoIx5QRuoe6wk6OII/k85f8PziOi2y0cFee/JIiFnIgVj8ZMmTQM
5yE93fzUqIO8tkgHxvQh80iCVHb40sLNOElAnj2ahwJnxxFWEEBghnysQU5orDj7zA2gX7NtaIEY
TniqJJhAXJWTRC9+RV6cJz6ErPHTOcMey5WbXByM0r10hdo+C7AO1pFFE3/Tu28jVOhhHQGF1w3t
0p68vpMnIxENXmQa7VRG/dpt40drNbLtfQ9q4VlHuHDok8t/qpo179RH0wb01A9kFNQTnmH7m47u
yvvmRcFUr31htjiuh6XyOuTgqJphuOX30+2P50ClWRgouIuKzjWuWCgmSoA9ClmirxBOOB8Lf6uq
VERsF5BiGCpqKbNLk941XyVBj2l0Bgw1gABHsE9FSavhp4c/QTkaGmHXr9Fwv8ZbA9ppNvEcmMeB
KFKWisO91DXDZyesPrJjZdYT7ySHnkLofw1eavr+jTxgXPlpTcWORqsd7brziyWdAK2NiCKtBOYT
Vv0jjhzB8RHedxUYyueAsoglnlM5OwHa2qoFjkDFL+Th2DGny8JxPyKlpWY9+Kvgo2fegrkB76lp
UU3mCeB2JJoggiTV6VUwbbkQL0ZzUfbvalo7tHOC2fuJrO1J5pJm/RTZLcbGhGxJQTYgIbVHyryd
dV3uKRPhLwh2pa99XCc2A8fMbI+urvVFDeTVUFyedZYrSojlXAtsuhRLyIEOySmWFpiqm3rFWKyp
U2pg8cNq7+2AMwZb2VcnTWGCfqgYjkPQ5gymBLB5sAy7aUqI9w0VLEwg9whcywhj1b3E81U3i+9a
v6Yd7CfkKQJzLe5umjIyd/QcnDX0ZeX3Ad+KweCdh3Y84zNugKv+jcrhebSdvbNeWSLWQCX2uVqf
7JkmDOw4HJwSgSD1MF2VlptxDICF1cAqx+Fwfnw6WQ42zOqjgoYojNETfpOTtDjmfhiVo6Z2kxNG
H2VxGs/vaW9wFPCduJlCkZUMNDcmEsraciQ5e8A0U+GiB+AVq5sGdVeeO6EZMhFjs60DvuPaV/Ec
/DDrAL/CvWTg5R+n9UY9ceVpPH4OMvjAG/nXfDPJzu07rs5yCAcHAKwxl9nJpApvN/3TvMw6h52i
PszOnlXEETheMih5rhd8+bHQLQNKLkvkepJ8dV0tpz+8kRmj8Yp9Mz4Fo0bTom1S02WuMcCs68Mj
LwRhoUEKY1lU/81ho1m+i1kkSm1Vj/f6B6UYFElqfP64m78nIWWByzRR/SPKaImG92DPSXbEA/z3
0tmlregrRsx6wRrPx1yuIfXkm6nQLC247R+UyrqtF+uh5cyuQ7z1V7Hty+n9PHHorPljh6NQedSS
cRgmu+jJq4vShwG4NDEAH/Bzjk/CDwogTKv/ebswLgvF5YnYCRfRWK5Jj8bjorQN8IgTRULRvFPf
ilTRsFFbbR2JACOnyjP7ULTqDIBdBtMInp6aFKxnliJ6DPqQK3Buv7Kx1ZzrslmfVm3EUIraHxU4
kQK/5hLCW0XZl7RNlMaaaSFQuB6+BmS9A1UOIq0vCyLqv+doMRPw7MAbNNOwiB+vAshDoKZmjXOR
j1AH0ZaqKpvcOtqp5EtebTk+lDXqWvAQf9p+pqD/ov9RKvpzKC0gh7Hth466AgA6s4UPz0p9pZbt
W8M2WRu3iJaPrgdAtuZE7re4IYN4ONXwM99aZGYriQJG6eKVilrMg0jnrsxkPcdzw1ZEqLicQM9Q
AJLSRBPpR7kwdZuyJ/zmIu/fMp3o20LhyE/wNwuXnS2Bii2wquDZJt+SH0AWkmWMcOPetfp+iNTh
FwmGtIN981mJ1UFzbPu/YK5fCD8HxmvVdiBFhxfAQAHv6r8PDmgZysrJSBSks1MOG9o7sdYjB9p+
6fmrZasg53zqWcxNO0C309guv7ZulonGt+cWejY/1RHxeXKibbYUL3rOw1R8hWKsdOXijwdL7BG0
PfykFhSyU0bfxQrtNikTY0RNyMaPk4L13AepD+f6tuPaCaldUhbjuVrpkI846rKN3ztiZxMS1pt1
UsPC7qw0YPMFI+IVX5GdzVk+2NHTZw4UgCuqaYUrdiyc9iWaIZmuB8Z/o/2zaaIedwi3n3FcPgy8
3QtiIluhCkFsaJpQJbfRKhl5ZfKcGPrPbm40BONFeHWAxGzhY1U+9wfrxI/DuFn4IN0ZWDsNZNf2
TlMHDT1IsBTrRtSO9N8fATtcb7CBJtUI7MAWDU9smHthhIMncB1p1v19hJhMJAGjkfIhxXZHU95b
dgp1F3TSborEXDGnAWy5ESZherudJaPfvZ07s0eTbhok3DsY7VQp+d019Ol8GkrG1Z/cZnxuEjjR
HFiPAHd9ZwUWnM/MwXIYGht+R7UMx9PFpN7GDoMsnY28rIwi+Dv1eg5MnAV+V3TqtxvUfM9Enndk
fvbGnqilnB25BurKgCdP7ZgihBQUXOmoQ0MSn6hWAnPZKXduiZ1nRJ+F5to5bUh3lUbUeZaAupZb
0lLO9ZeFkXXXUjORqX+O3JwZ9pexU0L67NfidnmrmN1B0/U1H5yYi9yT5ph69EXkXgA+OIy20xxO
rSbkOuFuwRRt0Ba1FSXoTbhmE1EZkXUyq5NATn66wm6FTtb+K3GuBPAHqdmgcUVl9tz8RTU/zqhx
BVGMu91MTxpR3RJyDE1afpkq9sn2SwLud3W4YVWUtafFmiTmclBi0145fz2WHA8WzoZC/UyayfIM
ClHrecUQTIKBRQ2il1vqQC0hqVPvHxzd0ANFjiGWdZL6jTCAPlmHsMlGC2aY2jagFSEYaoQ97lAI
G39sEf4Uh9ABhg9UdML9gzlrL/5MZjYVjwuLl/mldOp94jesYzYgOrNGc0fG6hURb4bdbgMV+wbp
PX0mq1CB3Ejvx0laFm+nPDrMHCV9KT3XN3IAExyUTsYlPPdlr7M69wpUXRdywxS+TF6M3GBxvqt3
TFzvD5lVqy4JlcV9fIaTstWr58pnyUAf3lZyZp3JUuIUPBcRrP5RyTKm3f4VV72MVtpxoGYQp6eN
xvOd1HejrHY5YyyfOMCWnHJtan9Idl69j4yJXLTObdSBvM36A5McZk/jn9ohCvwhJhE3ZlfPRgb+
VVm/mtYmdHk9DEpohpNRGxKBWd638syVzowUfvC6m9WLXPL59yyIbCQATajBFEO8f+CBoOUsq5bB
ntOp0jfhfmIS2YZPzamyd7w5MkJznGIctlUxVpOSFNaJ8RZAl6umjYOo+UxLsGZ5rVnEoccu9isi
RIG5l/Aj1LctQvVeDod2xHMe6WmwEzc4W7p0ez0b7BIssmmUWK3odo/Wd450UmhviUIuNIe+h/YD
JjBWF2z9GYgWSlZxyi/q8TyBHRi21Gnvs51zbBo/6WemcxxMFN3/2NnchmRBdsKFlMl39l7R319R
JeQcSuKup09m7GdUopI5puBQZx0wmAMMBW3ajBAjerCxM3pgVEFJrZ6dnvfWMtL8JBnr56G9A3wt
e5hrroNAwKKyc9nBI0rc9EdJGBuBDbAfbj0Q91oAWbNLWPs4X7NVCTZ3+jaSMgjzGqNYDjhcwqIV
IlOGlxIKturWNbh8IT6AhffvOAhAl9xZvkgIEJ8x68ExDoGTnpmQdx7cY47xP8sVzRfph5Vmlzyd
IWV/5NR3FF1GPTfkgX8YCf81w2Mrx7BUvFmOYuwcO4xx7H/ZDWQ6Rdu9kWlpqca9svAHHIDc/50M
i13LhmZCfe0wre6aeEPak4qq2Ia54dZ96IsTABNQwd7dazjOTtemW3iQgXMGEL6o3IFqch5OPY7I
Ab2u/Z+vlqNDVDUJ+RpEXZu95EIGMyAMMDVdQurtYtYL88QVjZBaoc4+umyTugk6smFBoloLttwe
/+HRz0oQS8ODYNikyT0QBV3xL+8IKuTdmQPT57VZjaup83LqO2JH9Hinb1vwzCaaLacK20oXXMSe
rVlnmBomQuRFj1+uBfzMQzxqj9OrVkN9mzIbVEsd4qWLtGeueKOqEtMW9NSgao9NOZSIPL8IjQw2
dypmsJTlnEQr04/hqeArLbtfPQrUUp0PAU36dFQsmBTidIUKxtueLlKus+gllK8adqjHIjslqpPL
P0PX06cwDsx1A0oGPgH12tmwowyxc9N8/32txyDywW2+yVN0TwCPZ960K3wdwlU2KtY8H0fCtbA5
oYFUR/zZEfQSq02bWz4NibnRxR3MAEMzj5ZeZ68mal7vu/knTSbTf6tRTXlWvQ9nXr7Up4Q86aHi
p6DLekoalkaEhkDrooSN9H9isPC31CbyUCmUjBp5J/JK1nGXJH9KhHwppeWHMRShE9HGDbz8Byqq
KEUxbjsFgjBMR4r8K+BcjLjwPttlkNs3s4kEV4Z/27lP3MWt4yhwjWXo/3Mv720kUGqT5Vyqhy9z
ZQkrNIGynoH99OKrzZftT2w78CgtJOH9ZOS657F7eCgLOf7vfAZ0uF0HenGR19PEYYXwHlPRAB8U
8keXXAyuErMEn0/K2USRoarp4lBh/sQ94TUDn9keeRV4ZwnMblQjTTYjmg3YBERmbc67gbZtbcxI
/eonRvCoyImxLs88WaNTXxdcbnxDOgiYdR5o+QZIkL1xwBc567CIXoSIsCH5c0s7vJO/DZ9mqciB
XEPKximuIulZz0xD0uYdyWJEElNBwd9FChebJGfBmhUfOLJ+zy6u6mgHzW3XKhK0sW7Y+s2Efu6d
MuCRNeLtFhSwNel/mWosM75hi4LjMoZnHs2QWmB+E+kgIcdIc2VPu85spjAJfX3hB0TXPNH5F06R
uwoujI2k6FnbcjHrWqq6TdDj2cNdGwLSk3fFO69r0d2xrPyRuYHZUxIKykfAsaHny/adveSQHJ5D
aq0Etee6gFB7g2fUN4UENASGcXl5pk79jutuUSvJVkOuc5A9S3ww4v9HmtAX0nLQuv33DDxPg5fo
wnj6UfuSNkv5e05l1oKiCxJ4UJTD9ufVA58J0WBu0S1iWeB5AXXDq2dWQEB5rEDKLtsHm788uNIa
SQ3luO3QAsvmb8sPvXGT2yd5WuOV+br8GnwEmElTTNY1Vu2dW59s1dPesQ8weQkuKDEglUqR+iD4
K+qsYDnuaGK+5hVp440imlzuGjXj5flS/bAzxLzoSb1Zm3yQoP0yvR+n2KGc3b6isyxTpFJHe6x8
VHT0oSvPyFn3hdzn8V6IgmpKfUWSIphhOJuBqPI4xwo04zB5gVKG0DZxLB4HNm87Z7On5tWZrAB+
Y36lE+zOi/w7JZbteA+hmOexPMWQ4Qtnv8VTT/sFY+5TYQzWYfg2sQnDB4SG0tNzec4a32KAppiF
kOd/usuE6WNhuV0dhfPCHwOVlx2b+8mnrIy8YGbe9d/MXDD5CvV5Myh+IauGRKyz2PNMtJolQ9lH
lDCd/QOPm1U4ksFF588PdFN1bSgZ7Z2RWXSzwJy4g8KakFQX2BfF9ZnFM6tJ6y75fnEmyMo2RfMj
oQR0HqGpfLuLxJuh0dZ0gOEnAqgEHNLHtJXwzggbV9YOq/Cc/EDUmwzyTej3JvHxEVYg8Z7VPRyo
YMCYE1DZ67ywA6Zujk7Nk+twMygTU6wjYUO+oztOZLlnXJCqQEcfASIYdBKl3z10Pqx5GGXF8xCE
pHLxERDdBzWoHvN6H5CriMMys3Af6sP4IKIDe6NPKSICe72+ara2sMwxhvLrrQhW48d325nV8kK8
3m52sBZCSc5EdfcbnE2JvsIJfDElSaEjBtX2D3aB/gC7nT5NL+oLPmaQAvmZFBWOrewVylIwIvVl
Dk8+OeozvrpvBAmKEAajM9cV67hgIJekAMyHJhopK4UYEsTCYkFheM8XhjpQ+8FJHz6UJHen9KVx
1JHpKqKFqQ34NNc97o4fLtvOsoFbtC2RTZvmVlqH+G0Vfzsxb+PYW2SmroZkR0gLIHkbyYSyWYKr
VFBevvay4nH8U35FeMGHbn9vxLF9A1ISkWQf/JuT271XVggxoBh6E7801f7KSr9ZCdrfzbHB5Lxl
ZuKcPdUEXfLhGuua34huSrmmOQ6oDsM4jctxMwJ4JiiHSUpIEikTv2bTXh6JaYgkg2oIgzJqOJLe
7nY8MlsSZ6WHMWTC3L6bTSgyRvDeAyHz7kYv+2LAgKAfEZ4gSh0o7H9USy51Y7GVJfxYx7bAq+/c
fHX2+Nq4sGhSFMTaC3JQvLbJna4Vpka9F0UqrwuAw1S74YXRyHgaLjr5ghc3omPkDDmQ+CFl2Rlx
OdNBPmC8ZY/VS4cIa7c038bfQxfEnVqEFob0KTuv7xj1N6BAGhcK93ySGkJ4ODudvcQxRV1VBPZo
sG+dTHRij31KJ0Mb62lZO1pks/DfWj1TkCCixTE1c4Sy6BeS4WcrqRFMnVLmlOMjyTkzqP2E4Rr8
WhV4P896vEiedfUr5OmqNmTd3X86EtysrbDXNzMe9wwomEFFbT4+b6SQMtlOAZQCmxfrIuKCP4bl
AExDTR8a3DBBaYl+7AC7HHnO59RXvLrGbZuQQ8qA2p9n3Agx525I67+354RfW9+VS1Z2/SGGEdIs
KpR+W41FF0MtQLv1e+FeyrB3CCynQ/8AJaCpVgwGYTGXHDByTOuoyzRmIbKq4uYT3qUoNWNK6u7Z
gN3u79CZOY52xiOwng7HWQnntHzAw+vS1iGc1FUARp+jLl8jEbP8zCMuQfixXO2+YPPp/4t75FpU
XAs7xxSi+U/m7WTzcKwgSdjVNY/NanOsSC+tYrnTfjcNrJKuyRrQE3KyziLtkA0uEeUn8wgJdGiC
KMb4j2rdXCejiF3i77zoIqJvQmN+Cxtl+jAlC6L6nVOP4HNOF61Z2NqJi0S9q7BHCfvcM7zDBbGm
sB8mX6dznbsGsTemduTVDz1QW4V0UYT7nfJkGUVaU/ECGRsv3Cp/G0dIf0Sz0OB+ZOQn/5XKf4iH
0q3EYGY/dd9vaikv6/0jLQJA0q1gR2tytjkPubBnmFlXlUbsLPB6fLr5zhNICg0Hpn9StJykTsFp
uCpk/32WgQw2S+8Z/g/++yTgf6ZWvVNCNJrfW6CIjIG4vtK4ln9XOCMZeke9ffvkRwVm25EMpx/O
aW6t/zR9IiESUfC9EJdNdKezAwJD6fFKiq5KLAI2Nff5VA7Wb7fe/sCbcboX1yrwk28fdqgYjw2L
OIPWx+FDHhcy9QNiIjZY1o4MmAxjY5+vN+bNBqG1ld4gL2wCkRqj3XXhOfmxA1QnQwlYkONTYs1L
87VshYptuMk18c1EU4x85hJpV4/KQ80l1rnp/RDdOF5ntiV/AyJtsDaj/JmJ0jIRYsz5+o5ToSS3
0QWIcsUjgZMYKlRxdJwUPPcGeua0EbrLOa2fC5OSUZ/17YhAvAtkHAMwq3Qh1NpQQhcFvqsIhCS4
HQJ9pofvK/TlpVqNkW/Y828QZAqH8PKPNntrNGlQ5qCo5ZIgn4QCL+4lcYFE0TSnNGeuuIhLsHZ/
CN2gtoYCKm5sWJ7IAltzHN73vhN/dRIM5ePYNzZm4VqedhbkEL4qHxi98jdzGM1D6lfgYTrSFr+F
Y6K7yirzQY4a2uH8ZcYRo5ssTv+AV35fVUntFkwIvMczReRMPCHiKRKotJNFEQr5csq338c7Sojq
7l1hosml66Pr9JNNOY9G6VP22e1+HkFjzr9tt1GEnU0dnNdoOG1SdZnBm0k+9BZub6NZ+BhfjpTA
yPyszSExrq9aNP0cXKxw7sQDBLK8cXYk0vc9/bsw4qqE84AOyKiY+zGVU/C/L/xijvu7PaqafQf6
x86ovWZh+uOeZewUHV7c5EvbPG3Ou5sBYLoTXrd4xcR4OomPZi3vqfI73SVl28fqrGDgX8KsbsOr
kLCgiY/y8J0q2d2FtLHNeV/KOGMR7TQnsmTnxQAGQBw78XdJdkP0l5r/TNTW6Y6Md/DiIpzl/oMz
eJ592FpeR8oRa8FMMfEqBpyxxDuPVd8ccxpiwSjkXXWKstyt2Gtrh+1IS76YJLNTd6dBhGF0mUrX
Y8M2tHh/ZL2kfte3uZmvpEuYMPt/ipg6hjlctFmhK2VWRO5Kv2xwSfsndDnicbVhMyPrG0ngTVAv
64cah0Vh95Q98gLfmbtFtNznV6rFJoC8yopp48KOlSkAkeJkFlXGW8bcFFpv3NfgkkdnmfD0YF44
v674ldTvkxEfI6e1Po+9xeK6LspAqYOT/1gHUmmUgSRA7lwNZFqAfCjERA39hQtJglfjahDg0F1i
2tE3/l8OU5HuFlqvHzhw90okXYy9VnZmD16f4IK8BVmvImU0mzLCGrHfG9+uCf9rH/XiIIkJx6/0
7SyXMNmBjbmCwyoWxhN7sMvG56OvO1PijDUAeR/qlItaCu9r+996tczF1lAHDZH4rQfn1Hb+g+ol
hSABvX7OFAIjtDjMrI1+tHrSGLyJbczAEQmUS827RvuHAadpbiggKVYlOu7Q7GR/XEch5dW9m/Qh
bUdkAC1WkqtCdF08rLPMA0eZzb3yjSTnVPggjito/visTrPZ7SrFYUPhoOoiu4qzOzFQqmSbRGvv
4XtInOa95bXR4TlYWNi6FJoswRM58kPFCtptbkkbivKmTmTb4tmqJCBl36Hmkgt1CulzBN+qRGh9
XRWNp3k5vRdMCLzYsesYAvXntyn74PyE62We1quM5DDjaYTYmRjPPK04ZodA/S+n6mewd2UqAy74
UdqI+PGbABdAR6Sju94IzJX4v6SdWXj+moyxaQqbF9htprZInx4rtEbd6BGueBcWG5+AzPdAip9B
2IjTnXrhKmS0YBDYEGyz5+7k3sJG2EVWSV8iEvH086l20CB30HteB/fD858QdD4CpxGqwKdL2JtX
8GOhT4LXcNgG3rPHzDWS3vQgRBvvYIbDuBDTSC3hnr9n6yljxWs1/5iW1QZGlJjK5f4M+V/zsRbf
fU8QzL4kt6U3iF2yVxmsyI9fqdIMm5mmu7cePTRWk+J3Yk7wZ5NNahqG6dnv7bwmhg9WEeokKSeB
KqWfe+4iWWCVExgcxL9pQD8ciso62dHBIoLorVlc5YVs5tJqTQleKEC1ZaKtEtZ9s3fXBZJv92fp
onHT1BHGAOJKAcWRr16hQnFSNRB7HVPcES88RVxmAU+IILhTltWx318oPCtO5ORldtHD71lvG6zl
nxOo3++ToG7+tm2er3BZX74XgEto2Jl3XJaISUrKtC1VgH+BuZgjbKlYpQ/uXDmgRlFsUDB9coWh
sq09jrPjVCUDv2B34y6IBfgSOQTAr4cdvjc1c9hqj8oYW8Nqt7fI9SsZjd9o4dWCp3dB5RYsRknM
racMFDlh5wJjeqtTVcpuaSfB6gc15KW+Jg5McF3QXchLsSnbd+NXrcOcZp1FM1nnWTJD4inapWD1
9Klwu75uylkZqKuxhbreFAwLpSPe3WcX2umN1OMy+sVIyzUnle1T5wMaGmGAReHZp4OC8LiU3e9R
Rk8o22yRvgqmArtAhdnfXxuuUPVuYplG2BzlH7iJpR0ypep3wF0LiXZRTrVubod4dAKgbqZUmJme
5zGpvNyoQ0XrXyH1x5+bVGbz3D+IAT/w1q+W29SY7qsVb1JptqSzjxp+eG9V6qRXE+c3LYASQK3m
UrpkY2GOQ9WIpFFWCMoslt5lw652xUVWnfTs28soQnwubEkeN5EKWjFS86O/c+04Z1w7D++Kcnec
bab6IWzui7+4MmvMHwWoGA2qqEB1/CEvAjxmFqwI7zuEDAhrFF5tHyCH/wS4gb+VOf7enEupQrjK
qTTAoZXsM9Gwa+bUBoguwezyFtiZy5paUHd7l8GWXGXYK7uCE4LX2bl4zlvM9jSwDHjtg9xyEHVT
lPjucVHddAcEZ/b1B6cavbrOCywV5K37AZQRyPiCxnibXjzOttZADCqFfT1dtjD4o20DaYGn0ZLM
0OuaWYe3vVGn65oyAj0yAPAgG7yk2Lpa7Ui2MJu1JnHBZZHHj4duoOchnGdMTIkafjY1j37hkvxP
88g5qy1AfFoFIn37xf4DNh/3TqtVzByWmL3R3y2S537gZ+ApzUL/miu/RD66/aLJTrThOdpyV6yP
ziKXiuw69LQF6sWmkZ+awHORB7/1nh2KBbG9aEzTMU1dQPoVAy9Ogi9plgE6vPA5jrj67c9TbFMj
cdu7AQkTICQyZTe0Ux80NhpYk/PFPPMrcNIOp4zqWIXDzyBGdhcKHGrMrOS6ketupOPR3flPkwu0
ga+V5010OV1Erkow3FCwj/07DH/eDqhxGYNGvoE0hmnKJz90n4tGomPV5RUH9BGUq04RhnYTfLHi
n6OGUvEJB/SsvAN8v219BI7S9B6GFUBQgvhBWWCdF+T28KQjka7P3KqGWcEMPaZd1uje1J3+s+VT
euh4ajmoRr5RkdtYYr1F0wWnrVV86Zwpf7S04Dgqpr9d+aG89WIV4xzzMLH8VKWpey6qmeUs467l
r/Yn4hogMasGySXCLHpipNAsVKWheHH80P8ihPG+0Q/CJp3W8N03PxGRfqlB6Rr1vDs0pYnSR//r
PYAmw+7/2jRYl14zwyyTFAOuk3M1pltXLwg2nCYugRTrhxGLwcytIXLGLh3UDvzSkvXrNm4AwByb
Wj9ec7xbVWGK1JqOP/pFAUFo60+o12VF7oo/D8SIwXFME4tpLJnMOY4AhB0fjFbIWc4se8TMLfC9
xF12ao/+4lDGt6Xm/MRq2iXo7mg3YdcX1bqjsYNdHFyPhNhQ656MgjkIIR5su3DsYJa9xJ192Plq
XTrou6GdIpOfOB6NczmWjGWuUy3P/P5ldG+TqAh3Iln7/sZj51ze9kQ+ZqDg715M4R2tO+ZenYEB
yHVuEvhjNtl86ntNI/Ud8JwJN6cNxEcJ8BwS7tAr5zX+KCzi0GvCAYxT4zobJym4yBrIzJ9U8ykS
7QhfYiBGWjLleXcQ/aNjH5NeNoocmwCBWCTIelTeyGONissqY0CyRStn4vP6J+j2hM/a/96z93gR
bLy1vEPTJY24JUdV7QL7igf2lF7Yx9bjDLKSZ6QMe2C7ktCrGid+n8+si0NHtMV+4xYYg4hdqP4/
oW4nV+P+axGgxNO0x8Byl/2PO2AlHeXpg2QOvZv+fKqOoc+ElNocSAxqKGFQ72Z+SxYSdqj3OJ0l
v2yZoFi9YPgiwiGc/00TBi9icnftloA3j49QIY1BIHTGWZY5xii9PNK0aOn4EfijqdGUKjFulkFl
n4Rw2FGh4mwOwrkn3bA1ktODWRpVLCheKndg616PRFv/eXuUwT1wi/DCJOa52xGfywaCzWRw8hl0
rOzHxv1+2aPOW+QXD7R43qHzWFZblW/I9czrxZ+cFzD7lWBisbre0U9jJWZJCH2f1+Pf6oYiPwKP
8Gf8LciTwSAiBJZvxUWsgLyIdGyxYukMMuN6DbNvQnTVKUqoRnY3BKJzErRhzUozeJuRaLs+vuuE
UmLEerNTONZbc/BWYfIYOpmDfIX/N5ui3Hqi0P0hp/Nkv8vYEgt17yvwHjpjzl4A3v16TnkWKEca
U/wwPDJpzlWus55z54/Y5OB4TQ4V4aRE4asjfPrwgfIWIk6D4GlFqBdWbEujtrjdxIcWS3Z21Hm4
7ZRiDjrDGA2CV2C9EHgr6VAIjxghHJlbgVzQJGNV+TpVbBd3oSAD8juossLEELZyexYtgBU5nX2v
BpCboUYvYvMVnpQ2JfOlkS0k8bymfjkBdWua32T0Bvc2q6UoQh/hV1GBZhAh6gwKkaQJnpWEXufu
q6opziqdOJ+it4tMktuSuZqwOVkHF57ci0CHguhZiApxQfsDUmNx7byJQScNJ+x3twMkoViFgs+6
fI9Msx9soIsac+5ANOy9qtLFhwsUd3/MLjRYLpwz+O89zBBziM4Mjat8IMb1NJoKP/oqpON48JtF
nwnLyNF+NWHcbna6yBfoN9ee0ubPUxe2KM5M5h6725cJSQwOgttopLOIfSARjawtZAZGcfFcMYuR
Hh+htokxkR3MHGAlLxOrBFwYmYRzUlxyvpE2CaFolLkQTECVxO5XHezBtUbAjiOQp8lR3nnwGBI/
zFxxt0SGOLLsj83IAXqHAnzzLdMmLFjGTwd9WWk/Q/cs11k/y3xp6NtLecKEk+f8FXApEFRlqoY1
M4020gmbu23H29juNJmSbPnQpFQQEXP9AE1YTZJm1HIDJafPpKpIW+S/TnFW7x6kk8q37AXfOT1s
wPYZS9mH/4adgR0F2l8oFEasOPPRf0ot2HXg6tVsHd58zcgk+wat0MVkvlVJZxiOcfwKLWsB3tUE
Gfa1NM5Q+dIchi4k628Tru69rWeGdku/9Ks1Uu7fnZoSetPkHhfDj8kGWlFGsC6+q49xkfTQLYDY
Pmpy8Hx+D2E5g6Bcc24TuzqTeE2eF7J2tS5MonCxpHN6Jp/MV5LRE6SvkR8KaRLNpKy/MvyyPitu
QmakrVPAVk2ufOE7mWVT4IGNPg9pm0zsCK5w9jg05p69Yium3awMqeVSo/PqM40oUwD+Om6Y/8YW
KrLSTO4YTjLWhGygf7v72LHAeQQTvRoL3LCu+t0Ecrmt1FSJhwsz9aszAR2WvlAG+EllhqwLDmJz
M8IWqizRwyKvVmYC6XK497PVEnBw3NNGppewHY7kOr7rIvu6hMaC7WrSe20Rxdh1oImXyvzWwUyx
3GR/o2E/g2D5JlL8boXyocQ3L5juvDjn8VRjATHXGK/VtROw1kv8AL9fBKhFhQ5j20MIMBNqR0sQ
2O2h6PqAmpyG9a5HSQ79RROA8nHYO1p9STiMOm7Sd+gHa9V/eQcXb93qNVdjEE1+yegH51zaJmdd
hy4W2xdLT3/7QRfPqXlKQCNH2pXJ+bzeOJ010Wh/JYT9fxNx0THipV3FzsxjiKtLAi0SWD+yBqCZ
0j/UvhQUxDaRgpQnx0gsfy/YmZ/Ebh2ve+8RgdS8T5jTJ3NdMdefZ2A9VLzxeX6p2lacth8kCt3x
RDNPwNenEYIy6Ib4P4AoSEWla/CJb0tW3qOQkjVIXE/cr4YNNf4GEvcC/PsVK32ZBFtm7Z9+7KmG
Z5u/Mm9tyIBs9PKMUH12mP0lyw0uJzHcy3aO+mNsugHp/7NcUeZS/xnPpDe7UN47AyHPnUPLdR6b
dV1bsr9cNL6WZyivbbRdRwpEigebHAzEjyYXMQQ4E/mJlxFkCUlj9pxpkeHgAQdFzd/eZBq43HIB
6AXOA084FLTfql+M5zn7IkboeGnvwmTMBB5w8eNFdIvga5Tpe5s0LQTetU+NegpsuOIKAyfKSCcB
brMrOIxJMOhY7zl/p88i9NvyAx4jSz61P65OSNeLCG+rZSZV63YvJyuh1solP2FIQAMRWi+FQAgO
7RgB9/iHJRn4dREtWXzcFqKROXzMkJGHxJADwzYLbuVPg6fO1AiDpxEKdBivrgo3Iif2fitcsy/k
5pINODaR9ClOx//BC7bUD5BmHC47qcAtxKpwoQNQQOd73dIiXiH5TCaiTp4loK4zXBbSMJxOX5x0
9Rz8c8b5Z9Pkusas8IsqNNZPGbTTXlwiSiw6g2syD1LsmqCuWy5Vh20DfjZpNRJE37g/jTjHKSGN
85sI/Sjik5nUx2vcA9bYo3Z7Y+C/inr+JyBlaDY9zaj5w+sTBINOB0J59IcZT5NOYaqDyUNXZmbH
Rl2latdKgnMqOSxvscK8gmoQ+Y2eyxhWYahI8sw4/Q56e8u3h9WMj7b++CTEhcVgZXNLUxo+tDsB
/btEWtziBGG6+wU6rFq7iOTVxordHJguwPQuFsrzEQ65f/8FXm1phBs5eh0E4p45FX5PlbeTSdPM
ONaawNzB4XwkFEYys3NkYZCVdxiopwCLArOPG+MNanvwzikXSLNAtJfQTQcLHx2Z4Lth9GcSnBdO
cLjsHazi3lEQRskTggrby9sikKUimM50PtKe7pYx2Tah9G6HMZkGSVoydiXzGv1wn9SePo7LENls
g/gL6i7v8eleTAvDKdzYYCCpv/qN7cy+AsJVoRxi54d/C/oImSh6sCIhFAcLcpwQIPfJPJFvlW0L
WZzrFqMMAKGBGa/vZW8Anov6TINJIGqmn/nLJZKx489BUks0Lp0/tXw383i2VbhJ8urNZaQEV4R5
Vc808BW5u3nDnm/Ywz3k2PFdr3mRzKhQ5PbtjNHR7BEZuhIyv7s30CUcTWVUfb54cYbutTpr8XiF
1PXdLtidpclFbjBSV8RSKLwyBZEnErPM/Vm+SoQ7vy6H9X2nMQaEVCe5qNntm74lLwRjDP5+LE5G
BGZ1QqCTmffgiEQcu+VY1nNiI9jmCS2WBOaQArHjOvYhC/ulSy03m1YMPQa4UioZiv0gv8PsPG7T
7NFV+3y8DvogrcRuiCHy3dXQ+2RskhIv019G1NlJZHrgNao7g//OH3xkALit0qCrlKWpfXGSiQDi
yDLXxD29VMuzDaDRWHmWCJa0qx31Eqnb4eZ5l2AJRYw2hGMQ7EsbRGjCARWshUF5u/Pq7U8sk3Z1
zLoD2aUQA+YY2ebrGzc2n1QQjunyzBn+XvIwLckgNZIv/AvNBtau+hPdnAYF0/2Rd0jJUz3/z86n
gm1B9ZPgJ31bQfdaGiARhL6b5Zmnu3Qc0s77PlTkgK3zWIdv4Caltx15/Hw01uamOwAYwyzHX8rX
oMgk3+JGy5WIoga6ziJ7yw2+o5MJ1i6yTCBCK3ycZqN1JaQRT38weBlSPGHpFBt8w32sCI8awhct
SuLbc//yg/mVB/cI687bsqgQvKRcseW1wLACfkINP+K/VJZziUI5Tjr7SMkum1PT481iMc6lcKHq
/QQjRsYJ09omH/bP0oRhm1BovticoZixbOZ94Y9sPhVb2kCYHCS0u+UiBVuGDGnBRhQJvplWYuQ4
jvpW9g7EWM7/36YbokSvcyNPqGkFkOaCe08/pX3N+cvV0cHTe7WolmDRisWHsavcrdnWxefsbSCn
ZQOyHWitGMf3eeLlJ94FCd3YtNwx5RpLXdwYh0ZQkoHnOkPw2dJMPQMPZTR08FBHi3Izov0BCulk
neZQxYSPCLzgShXXN8hc1TLs27xhf/rEsk6/9zMecJXTNhGOk+9IzPtHMAwlksPbqZ62mLZI1NVQ
Fh9N5tukBOSHGFgPWt3y4FE9y1lyStAdgqVgrhqDdtNGWHbJjYRmjs9YWDNq6pbdNeJGOl10L9ai
l3Uje5R6VzHMCsrrjNjViFClMbRaYtIicrgeuVxEE8mmrGvWfhTOELDpS5MbmiDwTav6TVvLt5Yu
daJ3vhicFnPoLAKQYJKIDLzsO+OnyvyBg9hlv2Ju4bUgYNXjQo24tf2Ldsfhtpsdx01vV1G4O103
kSo48G3GTpFUt7WmJylG5ClvjJnsgrFS2+jnsxzTiqsFcRUEjqddsREgdb13gvJed/1bjyUlZtLS
cGclzBSONJW/v9EygKAHkZ1ITb4YmEzZ6XZI2MSGYn2N9bz91zCKum4yl5yHhJIjPudZeOM3NHGi
a1R+EXyrHWkWnCF1aCLI+Axyy7eTd2XrKyN9S2qPEm6Ydd5AiDXqWZlQssZf9SNOuTF86a8dc3Ig
7aW2xfzbVrlSyvyzUPK6AQffncRIVP6aXJdW7wU8
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
