// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Mon Oct 26 11:10:26 2026
// Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub -rename_top dist_rom16 -prefix
//               dist_rom16_ dist_rom16_stub.v
// Design      : dist_rom16
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2022.2" *)
module dist_rom16(a, spo)
/* synthesis syn_black_box black_box_pad_pin="a[3:0],spo[5:0]" */;
  input [3:0]a;
  output [5:0]spo;
endmodule
