-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
-- Date        : Mon Oct 26 11:10:26 2026
-- Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top dist_rom16 -prefix
--               dist_rom16_ dist_rom16_sim_netlist.vhdl
-- Design      : dist_rom16
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a100tcsg324-3
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6784)
`protect data_block
p9l8ObWVinaKZhl7HdUmChGy6XM7zTaOgt7uTJLHQ8lvhahmI/Vt5cdJWMxjaXshH3A8YKv9bCcb
n/aKXSDPf1LB8ykyvIH7ougWU1wmjcCnWOTJAep8bAcsX4IosEtRpF9VtxeZl1UF78g/+URd3yNG
du+uk2NffhjNLVIoLZEHtvHiY2B1t6Th7A+Ud8h4b9kMwlT9/8RaWi/tgq+V3jFV7HBFMw2TAiev
e9rqloN69YwHa6UKrRxcexg3A9Z1q117n3rUoGQPqmEq7vn/aOeXpAcMkxIHdehDLLrnmpbZO8Ic
syLTXpl5vanaSxg5UL0PbWmACloR98X3UWVajeTvAz0R6IxWPWFy+DXLg1PTChFbZ4T9AFzrkdhh
0FwLvyLo68l+gLHNeuGhp1jxasTiWpb5ISYRKkAPEA1n+rj2JyNc1wX0hMFBN9nFIiHetP2m6Ydi
vNKAIppshWvi7FC/jpdSkXYAOAL4xvy8QFlzLxy36/iT2k2CZFSsN73a9+9v/urPghhHZ5b4ndUh
qbZw1iUVPxVISzxUdvEp0XWbWURBabZt8V30aiYXn4K3SuwEajNrD1/CJSlQWwAZmCW1uAyOiQsT
1Y0fLKGbMdq0w/tV7q1wdaIIdjJjldS2kDAy91NSKIFlhX592o7YqYHK13FhvAugZcTdSWboPOma
kiUa4JS3X9kXMipYEOygv2RLBD2/BGfoKsU4jG5VJsHWt/HQ4ZEl3hMd+Jyi0JGKiu4c1tEdEgPV
hne1fphcpgVGfcbBbJTJd8NZT1evLucFvWI6q3+hkpJ8AB9xiB/tG4fYEeCFzNlov1aW3XlCnXyk
ZaL0Vb3ERlImLBeHnISMWRMdM026By33JaCLxOncwb3zLdX+8DGfm+8ASSQQ5MZSx/8ValdY23Zf
2k8iYefZUo9jmp3vnL+heaSXgNyF0w4FRG7U6FIwpwK1ogQPhrj0SMb3rpwUzHETOXmCHFycJrjP
pKQXOx+UOboY2dsa8PVadN5/HQoYVQAmembAjxh+A4BVVpc49MYRosqvbloBKsqEJMc6GCi248Xs
hradO7n595zJoM9w5jqVD5x2fdla/HQjhOOAvFCIyPg0Bq6kV34/M5/53h/6SqazT+IdTN9ZX4dg
mHa2S1lN7tX/TLh49pxYwFw6wSgipPVHxHImUhgUu3YrWJJWIkrfBD+oJaFGQ0GHmc5U/4q+jhnn
wLGP19A3pbla7qw08pCx/w7m8Y5jo7mgNaq6cnqozQHjBuezerVV3dRtho3UCXXtLgjv5UJ61r+u
hgTpldpEyDPzhM5GwY7H5c3oY9SRj4JocN3AMkD8yXevLB/aoUeHyQ/ZFoAFEE9Upn+z57rbtJ2p
HoopgM3j2hyNxJ4akaMmgE3YI31t8FQ4kifFhYY6yXGR9OHsy2l63L2dgIt6dPGAr+hKdgcnpeX2
Z/1rGuZAwsAFfHNQuthvUbIkozH5bBX1jOP2aoXLc0YwjPUGVoKSsgeT+VNOjsmrx5rkUmT5a9YS
ZO3saBaloN/ABcqPoXeB3EdeFt99Jvjxx1LY1jJGnlJUBWcyOFXGmEbpwknbu7SFWqPXI2vYYqxO
8sIueJWa/2960+aq2rRcxn8/u3FbLFwCQymgf9Otaaf1JsXIjYcPStSoVkFF/ac+dO+nFVsyxwyV
R6xnVuamcphZf4h6YXlZyrgoe70bG6jwQj4/+zRAREzHoI+AJTMeSXNVomGKs85qq8yHREq1OfGv
ePXGmeXszsvjgeQ8zwTjBc+bT2oJk/2uyJNlqKpazyI9BoXJ8UApK3/PV3dwOx/vb3EHNOiaNsu6
7urrwyKmnN6p1akwrEALuBRAHP1zio+qrKZBilD7PeHTe14RYbsOkkOGZ8HV4svFLBjUZordJ2WR
0blombXQf6N74LYmcwG20RjEQy/YdGTS+ylAZgxwwnO3Fsrkk4WyQwWOlkOGggxI8CM7K24wlgCb
2Pxdxv7kjdO2NVvuMbwE/lYRcP1N+AIqV8vhjsGMCVCR058dChDWmk/bFdQi02aQjeXeb9btNUC6
1R0NFIfkOlpzGctwEUpNaSIhbSi+OT/FQCa980zJl5eC1R7vHahIefjvWOwwt5bIkqmSbhwgwNSl
YwEdv8WFDcD/C9QCCHoDdaqFzbOmQHUzQ/lDz3esFNDsmehqXdEutHU4aja2IxFqXM46wVTsecBc
T5gDrQWVgA+VDvrLuV7O6ON6KwZipXjbBft8iqObL3vfPRrTerCP8T+ecmfkaiuizjqW9cIpP6Cc
H3pqXzcETfemInUTyqcH9r5s2h7LwuDW/+R+gHrtmgByD25BE7eDcl1Zkq3H9rv3k2zMWmUstrOl
VhueDvyKteuuu3yKHtWAFQs5DiElHXhXW3bu57re9lblAM+iGd9tqS5SBJSrwlKD3wLPVEj9/pd0
4gIDSlx7wccL4a6KxHlkrww8jIGVwLB6c2tkT07ePzX/Kxlug0H7LO7wiOZqHW0Y/Hv3/rJ+YdDM
6UDnFiaShtQ97tFITav0zxEZU4fMGIb6wqLiXzF1lhOHcBf+mjjBYCidwwmdDzZqkgNRpUASLLYu
5owAxiy5wk5xcvNG95Y08ctBC/gdH+mq1x1fBlZBQEhNkQmCvq9jnnQ81gI7tpR9Zrdj5X0LjhEg
SLkmqjCGmxxb0c7zVzCPSbpIzUk3pxjL+4t/CtDFJGfPPnbjHU7FupvcDyQjL0Q6VGQwtfOSv4+X
+Wfs1Cnqsgs1ysXbI1XYwEbFUIrAwZftJdaJz+HMsV+DVZ9VoMIzNRltP6mutk/FSAoF4gEoMseG
lR1rZ8ypnqJro//GkTyw1+Fu2nhWuZuG1hBH6jwpxNODg/hXBZnHkDc5tXj4oRfEeirOMb59nYEL
MPYvfU7Ga/oLWBDhQnK498Yi59CpeGV588MDaw+4jRyixnVoI3/eEwHPA1lCJMGyeQjVboETfK2v
+Z9SNaxUkqBPfOLuYTAYb7mlbIXIaoC2EbwPk3ukb2UWHp9M88MoWoUFaBn18XBkBlxVv3A0+5mo
cAKwsiTpEd3BanPnAr7spQMV2FdToqyYQAoFDJdToe93duKrqAFv5TruZX4xZR4kwInF5hcKrPqT
gkvxwIptq/04zMU9PZWD2BLPRe0dFIkx/r0Za3pzOvT6bJoh/6CyOAE8alaRpQRihL0ttqxV2RwM
ugnYxyl730Yy0FqU/0IC1yZ5a5elNlOsEvKAU9fVd3wUqJNs5OcyPLLh86NqgEVwDWxqm9BadYzC
FcM6Dd59ZeWoMuZfBhAt5FwNSYvzXxxNfeAsWawpWSC0ZwWFPC24N0V32qRKo+3BlQB982cJagpc
n02GTp8i31I331JGG87l7dHQOZq5nswlToReoZx/rT4OpoMvC3MrPK68AmMJn3bJGProi8Hesxky
nnELV1egjw9UUByEdxrXD+k4QebbDAscZDFgwq+l9FC1RzqVAixDVNR+Ja6yAMD3W6cdwTfKWtS9
W5M2IScq1lAWRZMahf6+rV2MFtY5jNJMxp4JVO8PyG8epdlZyN6qULPcV6gp7wUFTQ8afNwBKUOP
B+4H52bzV22Voda7GwEEgxtmcgOThxD0SqkdE7qgHQfNJo3eqnAkkiboOnbPwg/ISX4CxsbP6uHc
ODpxrWOnp2Hn/R1UxuFC6xNcXLXyM0SPMt9g9mhrbvOodn5IGzbDGBCu4q5mtjn5akZg4lcSJ2Mw
/5OWRdEp8F3om90PXSo16vZJ13rx8zRXELrsUKTdFxZlSUjZLWxY6aHSe4dVUv0ZOtzFJfXVqDze
qXVJ8j5MiQ/q3RR72kZLecf3IJmM86jCmnokxxVDp2HP42vxDMRutUsr1DvYWlpEOIalPbh86NOJ
VtitIXzBegqFCes0o66nsUiXKmnJWVgkNJXCxoeQIYTMsCt+T5bkdbn0dgn3x9nAXQPYqNt2qGhV
JUvJrgntep8G0kv2VXHWRiljKWu7IbKQ59U7nwSECCIUVnaAWxmaWx5ZF/XrhOymNnDl7MBQGka9
U16dQ4w1EMg2PiZ5LUThrjT8M8ay3VR29MN4zOOoZdUpDX9mdtFKEyilnF1lFpqBPT06lylFAxNb
KaoR9ieShvvQ80smojva8rSh+6F/C2C4bHX4AYgI0baULnGN70tPrSG2/9QZoDvN33RiFqckrjjx
VPKyqyA4kOwfWdqywVAS3bqWpfjRIpxMb232Yga8zj5lvDjPd1uD273EGDJrtYjCXouWQF8zadGS
JN4QVVpiBWMdgh4+VslcEbiuV1fVRX3OLdPnWYhmosf2NdbcwZx3rUi2rkupDl7ZMb2T7b2fVQjR
1O/QaTpdgxW15zWMdXr4mld6Rm7kQvLHNYSWhNvKQt4ichJ18j1HVUj/Jk95R+FRadMTsET+yAHo
NwHsW/TlEP8RtTnZ9dyg4V5MboPkTPZFEqyvHVOL6YBo1M41ieL+FKbix0CyS/SgDbPas4IPTtlI
zJloDghkvajEDYJnJxDPmXbK6msEDniEP7u6b67T2xS685btjn80nVYEVPiohGvaYadI4a2xWDrE
iRriXQ3hpKDkLEjjFar6PIURbKzp2dNX/HB9SzNd1evzO3qXMNNkFghMxnlF9mX8OOIuyarVz4Ok
UPPcwpjrpTEyZBmoO1Ah0i8pGHKNKJCrdR1EV+uBJT/FFN11FvDp5lc79j4CEZwBkLgXqoRp4vWI
5fp3UY4yBzxXQQlfCYM7KgVYHkshIwY2X7xFtEvTMVAkOo/8RumOY9hEnDmKNBwcffylI1+Z0+cp
pTnkzLMcSN+byTEHckRBYULK7/3KisQe20cg9xZ7mOhsL55ceVO86iykwejcnf/UluwxcY3hal5Y
CJm9Y/TBL6oE1TVBHPogITY9+jaWSk0HncQDKjNm7lZyJRKbigqO7i9ll7ux/rZzZVV4G+7HwAJi
PRJtFD5YXfI9yT3AZRvm6v4u6GH16eoQ2i+Bcg0v7qRouCHyt4cL1aEQd06j+I6gO5HN4GBs6xOW
WFeyobs5ImrzF5DAJdfWOhjH6NuxhaLGhTTiepKkvszF1onstuLp7N8fUMnnOZTVGQjbrc4kzpkz
zogZMFQmaVwcyMtgj1Z4hgJxIYzlEsOjnrYsWZyzYFbF0HL3nDNO26m3qsAPuseP8oPsmSlDwx0J
KalQdU9DAWkJV/I5ruIpldmee8OlYZPWgOdQmSg+G18d6r/qqeNiG3+bUvBHegRIcpBK96fD44qU
HUx5DmW1klPHUrZjrGGyGe6Bq986Q7g3xSX+yX9PW8voj1ONaXMEAEamx6CbigqPrEUfOaxHWCaX
JE+MAogs64qkluOvCompnU1eKqcvUCCY6/0XSXGbbJEechPhNqueWJY6PXxRp5BXlg1Fd60zCxSL
EGG9cgIVRDVWUk/Xy16vhIVZF3HJlyyHu2sDdvtLzTbG/J/6Q1OXdUBSxEpRq8n9nJ68dtJZPSaX
pJiR9pTzMeM9SSgMNipUJwia8j4No8uQZYZO/2WfcftpI3B+A4QVTlPG7GBadzeRBCtM8KZ02xBi
Z9GKXX5e/VcxjGZkiJ2oM2BsGsVFJ2nK1Pq5qqp/aEjOfAMJaXC6S5KCZVSZlmdxtR0RaKfHZ45M
M46laWPhsKQ8SZ/rFIwkt3HfIg1y2qcF2tgz7SJ6DNTPjC2R+ANItYAPEspPfH+/LpK2LVk/5kBg
py53Sb+lX4iZ4Vop6oX4/uMG6jRslWL4bgWnd/ZlOhrtkCaaO4DF+tp5LNIsRAsTqYha7pI3Mdak
ldbf6O6f4TpNwnnQssRW43b/0xpjYgfBvhF/qpki9UhqOn1RnUI4EV8rI+NrzACferqWKPasohBn
aTdkqvy4KuVlY/F/CjmOWR85eOS3FPHgl4m51BiMuDw8HzMlPwimMcsn8rYa1trjsaXcni3nHFKz
m/JVa5Ny4TIBEcyqSJlOoRqUImwOFm/A7KX4YjT6Su7vBWPVSJN6TMEbaU5EJVkgNmPzJPIhver8
S5pOpZMVKw8yJVOugaMGQ+RBOuRT9HqOzz+Dw4WvDC8U9yj78JC839LNt/oO8czHsu6pYP78M0bw
qT2IQ/5F8MzFhERnUILdFHF8XtxSAmWBI/8JQoA4tfD+BYqqRx/i4yYv5t1GShS8UTEpyfIqDx25
zTy5pheP8HvhUIqcPYypPyp/HU2g7cZqqpzLMuHs5J5dVXkdGMQYGgz+U1CYI+Y8WeHel42mdWAY
ZQMeo2AzJ0s56ahrRvN8c/QVo+lEYf9ZPc0Zroqaok/zOkBFoyMJ1Z0cKWzmPJ1SGAtDk8H+PzNW
RwBcaX+9UYOrL45ojuMgRtMS59IvnMx39N211uCLABVvdQKouNPa3ImaUCBA+2HVfuTxbk/qqh6R
+EQUd4ljLK3tIACz0orZBuNEM/Qz+NYe0Z8OaqPIMm4XHfHEq9rqVbv3zbU175yo+Pzq17bYUblO
FOcLyh0RlzBeRsQFkIsCKn5mMkscsry5pVDhe1/o5UFFDhAex8TX52YNM7m7TfmTkr2Cn+wBlwSi
Pp0/pqqS764Mmz+h+8RctCbshCvzRMwwU3AUdO2uZZYNmVD1wrski25f1CKmXJPqNbc7OVnyzrsX
wBWMG+/aPK9k0aBxt8hykbNfC+WJyn+SkPn76V6o0q7Wap8NnSB62BODb6uKa846ISJq3Ot5rcT0
As3SSSaAKCLebLkrCrnBUFuRPOmYJT73WlqSCh5SAKcwJ7F2upaghs+mK7aXBYM9S6vOh5wrfh/Q
89sMqxBCjM7MrZV/uBPvPem+Dr2hrx0xIFNEoLLE/esnXI4HNKyHXsQ4v2/ujQYKOiWji7flsm4W
r/SZMbKBZyndOA7STG5/EXgib2kaqgP7nUHgbfmeB4f41eKOa9Rlb8aGqdU1DcKKu9JuxNGxBOZ1
n63/Y1AG+dnLzIm55PcGubc4pAB5lHToBPj08jmrkDJUjxNjKSHrgG5bjBTmGVasoJ13OzE3VUYE
3W+VF41ngDIx3roWETOxpuF80hHKw2hAA3qIZnGd/S7OBdMaRqkhufV4zioiYYidDE1EJUSiJxnj
OVYoxnbD4GIFdBygqo/CnhfX9KwUlcGyAxtJ62jcn+VypVkZKkmBuhnfP/1fcnpt4PT5NnStRyki
nBkW1Phek39IpafXs37Zu+Yi0mXHejiBFMmobOo9JlDo2XC3sx1EhKhaCzvJKUi//2/1f8ArMuTF
EU5yDIdOerEVDHOW5zYzuDCO3oW1+qUt+86IlWuAusWKY6IXSwTnrAPuCJugV6hf/mK727eN1pUm
PN1pBzicIArD6t1nJvRc4UwzC5FDva4NYiByqtYYjSzjKaYugJfzl99hHbAa7wZd2LB10uh00ePK
D8YmSraTC5OOathQQK8R/3OQ/AL0pd2xVVPCSHT6YOb+DCI5QuFsYakkMC327LFrj/bGvLsjULJz
dbr2MkRzizOpOpcxlJ1OjUtNfzeEE2VtVBvt9yQdSFHRfWQgHhf+1/acn3ysqDqn8DVu5MdfTsC/
2JrX537kGP+o01gm4McgzpOfWMXP2RV9jyOIznrIpM1W1c/8t3J54B7JSGrUrh7h23K7cVFXni3m
1lT2rjCTgV5S4ym8fCyOac7zxNWVET0smEhCe/wbl+0EVEbwI2xOkIFKPBrAo1UZdUMaXV5bdrNu
f42Pj9TsJoY5STqPOkvLdt8VdXSwqBg7RsPaRCQjO4XfH/uQtTYbZaZU6ENgq5W48xNr6yWNBoIU
7mXf8GdqimYmJ9Kbvh2CEVqIeZW0TnPbWs1MMOqzWaLmbCYKj4DwWY8xNQ6DSlodzoyteRYOKVmy
2QyCdn/9m473/idtX4cexA/tKPm75d9cGnFhMMGStj33R/PbxUZrIWuIoo6+P7b8b3Man5MeRbIv
GZ83Yb0l5CFjdDD6KTG85wr1q3rfYE3O0gbazAQtWSwYfb2okeIWoqLU78GYDfkelFwQaCYrAOzM
CK8s2320DE7vXUZLnf219WgrpmRyk14EsnpKrqsg7T83gP98i43Zn4wpKjj/lD30gKo/RRxxzGgb
4yCtCWWizW2bmCOBO/fGokG3BR+MEqaQDATGA2od3nH3d/kOxdKgy/SQGFS31u+AjVOnamjNEX7/
vETtSABOdVaPmj37vWLl9+jHSppf0kyLBIZ10pOOZadlwTi5d5gMJjLlbnmUkxTARV1REZxUXpbU
LHlZQEOW1qIzmrnwJqz2P/tTUGcVC2BF/LXAlxzKNKPqcD/2zlV0VWqchZEbsUYxWz6fcY1ITNV9
aVhjA35L88JNI1rD+/BGSoI6b12L29ewPOot9mjc4YfxogoKrNSmO+Wk38+hPUOdQYNeKV3sVZvL
qy8dsgVEp8Djdga0kIChjifSt3OozbVVPD/hmxotZ27rOb37JFeODdFlliAH7vo2KuXKVr1ogehW
iFaVGzo/pRcq9mHxBbR79e9IiS/SXRUrQqNAQO5NAEHm78vKTy5RuOyeLMw01L3y3q6OwRY7pm7u
tSm6dQUCisAypaGpy+iJeZelPkE7xMMsugy869UvBR2F6E+291nyLIo4kp6efuq8BpBIh2xVoy9h
592Jm4XmF376TxwOxpC9Eol49AUDHkWzZgYSjwWvBk4PkP8r5AiQEZUE3Ls2wM1ETQUaGd69biVz
+A3Sa19hduwAemhkJFoTn+MZTDofeuMX5OZg6Ro3blf6KCqFqZyA1gtXwp4UpWXq6anlZnpve0JY
QLWXZ3rRWzNXAFX4Y4lhVAftXifZp24H14dk83kd6A0cgIzajAQzRl6Uot2fmxaT7wySRjpsp1O9
UEjJQMUCKTrxt4SpIzy6/wyvYm7iIJ89zSxNLAWJx+bgISCUDVIsdXMOO5BQgYOlhZ6U7KS5UkUX
Lr5RKIihykSzd8V3USIvu/ZGcdFHJtFuBygzKmTq4o34BeScGvvdFPpg6pHGPM3aPMSHp1nWbaut
tE36UrWRCcNo+sTR6ChFojaKjAS34UdzKBh7C2BXnI9/IXz8Rfs71VNuPIPOA9OmvqVzHLBSB2RC
MQ==
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity dist_rom16 is
  port (
    a : in STD_LOGIC_VECTOR ( 3 downto 0 );
    spo : out STD_LOGIC_VECTOR ( 5 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of dist_rom16 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of dist_rom16 : entity is "dist_rom16,dist_mem_gen_v8_0_13,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of dist_rom16 : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of dist_rom16 : entity is "dist_mem_gen_v8_0_13,Vivado 2022.2";
end dist_rom16;

architecture STRUCTURE of dist_rom16 is
  signal NLW_U0_dpo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal NLW_U0_qdpo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal NLW_U0_qspo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  attribute C_FAMILY : string;
  attribute C_FAMILY of U0 : label is "artix7";
  attribute C_HAS_D : integer;
  attribute C_HAS_D of U0 : label is 0;
  attribute C_HAS_DPO : integer;
  attribute C_HAS_DPO of U0 : label is 0;
  attribute C_HAS_DPRA : integer;
  attribute C_HAS_DPRA of U0 : label is 0;
  attribute C_HAS_I_CE : integer;
  attribute C_HAS_I_CE of U0 : label is 0;
  attribute C_HAS_QDPO : integer;
  attribute C_HAS_QDPO of U0 : label is 0;
  attribute C_HAS_QDPO_CE : integer;
  attribute C_HAS_QDPO_CE of U0 : label is 0;
  attribute C_HAS_QDPO_CLK : integer;
  attribute C_HAS_QDPO_CLK of U0 : label is 0;
  attribute C_HAS_QDPO_RST : integer;
  attribute C_HAS_QDPO_RST of U0 : label is 0;
  attribute C_HAS_QDPO_SRST : integer;
  attribute C_HAS_QDPO_SRST of U0 : label is 0;
  attribute C_HAS_WE : integer;
  attribute C_HAS_WE of U0 : label is 0;
  attribute C_MEM_TYPE : integer;
  attribute C_MEM_TYPE of U0 : label is 0;
  attribute C_PIPELINE_STAGES : integer;
  attribute C_PIPELINE_STAGES of U0 : label is 0;
  attribute C_QCE_JOINED : integer;
  attribute C_QCE_JOINED of U0 : label is 0;
  attribute C_QUALIFY_WE : integer;
  attribute C_QUALIFY_WE of U0 : label is 0;
  attribute C_REG_DPRA_INPUT : integer;
  attribute C_REG_DPRA_INPUT of U0 : label is 0;
  attribute c_addr_width : integer;
  attribute c_addr_width of U0 : label is 4;
  attribute c_default_data : string;
  attribute c_default_data of U0 : label is "0";
  attribute c_depth : integer;
  attribute c_depth of U0 : label is 16;
  attribute c_elaboration_dir : string;
  attribute c_elaboration_dir of U0 : label is "./";
  attribute c_has_clk : integer;
  attribute c_has_clk of U0 : label is 0;
  attribute c_has_qspo : integer;
  attribute c_has_qspo of U0 : label is 0;
  attribute c_has_qspo_ce : integer;
  attribute c_has_qspo_ce of U0 : label is 0;
  attribute c_has_qspo_rst : integer;
  attribute c_has_qspo_rst of U0 : label is 0;
  attribute c_has_qspo_srst : integer;
  attribute c_has_qspo_srst of U0 : label is 0;
  attribute c_has_spo : integer;
  attribute c_has_spo of U0 : label is 1;
  attribute c_mem_init_file : string;
  attribute c_mem_init_file of U0 : label is "dist_rom16.mif";
  attribute c_parser_type : integer;
  attribute c_parser_type of U0 : label is 1;
  attribute c_read_mif : integer;
  attribute c_read_mif of U0 : label is 1;
  attribute c_reg_a_d_inputs : integer;
  attribute c_reg_a_d_inputs of U0 : label is 0;
  attribute c_sync_enable : integer;
  attribute c_sync_enable of U0 : label is 1;
  attribute c_width : integer;
  attribute c_width of U0 : label is 6;
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
begin
U0: entity work.dist_rom16_dist_mem_gen_v8_0_13
     port map (
      a(3 downto 0) => a(3 downto 0),
      clk => '0',
      d(5 downto 0) => B"000000",
      dpo(5 downto 0) => NLW_U0_dpo_UNCONNECTED(5 downto 0),
      dpra(3 downto 0) => B"0000",
      i_ce => '1',
      qdpo(5 downto 0) => NLW_U0_qdpo_UNCONNECTED(5 downto 0),
      qdpo_ce => '1',
      qdpo_clk => '0',
      qdpo_rst => '0',
      qdpo_srst => '0',
      qspo(5 downto 0) => NLW_U0_qspo_UNCONNECTED(5 downto 0),
      qspo_ce => '1',
      qspo_rst => '0',
      qspo_srst => '0',
      spo(5 downto 0) => spo(5 downto 0),
      we => '0'
    );
end STRUCTURE;
