// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Mon Oct 26 11:10:26 2026
// Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top dist_rom16 -prefix
//               dist_rom16_ dist_rom16_sim_netlist.v
// Design      : dist_rom16
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "dist_rom16,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module dist_rom16
   (a,
    spo);
  input [3:0]a;
  output [5:0]spo;

  wire [3:0]a;
  wire [5:0]spo;
  wire [5:0]NLW_U0_dpo_UNCONNECTED;
  wire [5:0]NLW_U0_qdpo_UNCONNECTED;
  wire [5:0]NLW_U0_qspo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "4" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "16" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "dist_rom16.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "6" *) 
  (* is_du_within_envelope = "true" *) 
  dist_rom16_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[5:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[5:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[5:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(spo),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 3136)
`pragma protect data_block
6IyNL3QGNykiG8BIS9gdcVB37dj1VfBBpIwmW2sAdPdcP41puvEnMUZLN/6iHZ0b+qDP2Typi2oH
ASjsrgki42nptJXqcFRyvq2yz1Ojoe+citRzCtj+b4QB4H8JIsc8TNcoAAGmr7R3er1//AuCSMka
w92ayRhJ31oQ+OYUhe3HAfbjn0gqxugVMZTWEGsFx+dAey8zHR3HIrmqkNbANzeX46u+7/tcslIm
cnzFWSPngF3bdPFj/L9BW4LjbxpUT7xtZCCu+aQ2Zs6gGGQvPt4XxsKHKzD/XPwLg6yy0Gjm8LZD
ZM9RCd8dmD1dEy25IfCy4LkrDkpVuz8a6yQpxJed4ykQJTt3ugvCyuEfNOjoqcNrjxLv0UOVymgU
8PVevo9Qn1m1nyRi98i1PDXoDPT3fFsnrTqSEaKclDK84JPqh+9p/nTLDJ0Pk/dRi7mLVAdZ8hi1
A9siDp3S0wIsg5TtayYkDMjRWm3RvWqUvEW/kBr9MCH//dBWedQAbvfBJ63fV3/Un/6BtKQfUV9R
ViQ/v7Ot/YT+HmoeejVfawC+FIvomtrH4gfqOYr4IRRYTX4KWUZZE6zyhCJ/hhjPTcG9QT9J4fcp
a2TjbinKnqReSnS1yo7z87BKKruErCBgN3vv1SPVmun3dr7PkgV2RyeJco1MDBR74ykmad5IXww8
gxb9w6tVUNrm5V6LbPnaKI+i77u3ngf9QTP/C+zVoVRaeiL5FQ7wetf+vvasWU2gDLFKNtqhdY4k
t9yd+402SmwOnQQ/GUMtYKuARVbY/E07X4rQuPyqQ2FTFfE5wnZJWZAIFe6zTa0S6cXuP+n4MXij
AifuvKKqt0hVuLlxGU1eUJVSYZphZWPAULjxRh/3jdhnLPTwNRpk0UgHmLWV9xm5Bi+EGSJ7dqn/
aef47nSKDaZSBd31tFlvvTUvke88tujhRHmpaP0ctl4OENgxCChrqTXwioqbOOLWrtI0OjljxT5G
Xwtr8wPnvFI1Bka85dH3AXCFD5bhjiIceKSQ3fhOn+ru6ei0XyjAMfjtRvXi4VdYTDx3kuVoFCEg
7rw61ye5IU2KfkTVJRJkawkDSecYZEg2ZeQVmO4V+A+ukhdW524cNXUuLhczBJ1RwrxhkVgpS+ZH
1YGaHvP+odTNl9NdGZhRXWGj86vMPUgSw2czJxlyiSu40OsUF1K37ZgnjKNHshNT6YGi7662LjxV
n4HdptNyw6jDQEaG1UtVaLK9laN6PMCDoaVbT1NwBWCJqQCVpLdYNqMISHJ/PKj/GINHQeTp5Kk4
ATw+Q5/h/gtrMzGVT6EIwgGP2AZBCAlkC4S60RKgGLU1sD0RpIJP9nLgI+M8bGkpsJOir3qicJzp
Cy58qmr+wk1Cb7yF+00T/kiI8/gu7fRbgOGxEUNGbrG7DFHvLySFLK2qk3HO3eL6p4CBNN8BfrTL
GtbLhtGi2kqxpgRTxcK64+UJdFEg+BWxLpwJsOdCbSwX/7gRqsoswB5xuHlNFIA6I6oUoh+lWHfP
dJ0UkznTQPYdKFuqxEW5n+vaC0ai/o52Y9VKMV7jga+yM5G+zGFzcEcqcRGf2U4F+ETDvNG4ij9y
7lhfUoeCfwsKTSaRAPw9HteNYGBK+BjrlTyQzVqXuSnUqmxWPQISVQtVMcvjEhJQhh01E2M6OjXK
YB7yCP1Yf3OVrpvkqtpL31puDfMNyxc2HOqZxEp1C9g3QT8q9lBwOVrXtAsIHEzIwQ5ZH5JppFSl
xA8Kjdwoq9B6ql7epnld+LloVfIsA7tJ6ug8au3GlP/ZKtxYvvpNEXRPbTNNlgSt9E6X8uFJ1zs3
enKmLdEAUnsx4R0yPphwsyiwaOWU4qp+WEe6/mHhCwVxQfCNKSReGQQKrA4gWPXQedOYg1aAjig2
a/3S5JoBkLZazxpWfYvc0FUBTpZv+tDrSfXo24WVuw9eOg+2mR+WDWYzJMDEj/B5pAzKp4eiRHA4
nfqIB6cuKBWn3ILpPQwYaAf0skiU6rGYNATwfj8VaD1D9m6LegQbDrqYdPOpauEkBeUaf9eslKkC
pXtsICcKYIhoYwHDZifYqansE4IVEwkxjob0KYSIlAEtq1hMkw1YI6TM89gcb1bLBs/7iSDkD7gO
KU3bx16ZPUn1V/ZN28sJH2l0mvr3np5Xk40RKbyq85dEcGydLVzXIupWOiLWxnxoiTBUwFSaI+WE
n1haPuo10pd9/fenm+o9X/iCdnMNBOD0cCKt9B0jcctNzcc/QvpFIjHq4Fx2HwSd4GTanQ0tK6UT
Wc5BAijheXqBX3sqiL/EsWRdf303wczJ7IetqKmJxuOOdFSTDu6cHHh6J0fv5TYLlzMSKIyey0Mr
QEtObzMeQ1Fulqn9v3p5/yAqW21NVUE3h/69fx0uN0ue/cZ0kPRHByGukwj3sNIBASc3Vu6e6LaC
psjdf/rDm8cSVckXGHycWaet8Nu0SDHtR0B3qOOQtfQYMTfdypP5Yu3qbpeYIWMdnRrVcx0ou1xG
wqukamvsMCWzojoAOx4mNP4/x6bpHS+vayrhzC3oO+844c2eZQ6KzoCsjiOVisi8SnlSfb0PQcGK
R/KR2R5TpqMYfcAi4kLA7SIhEpxGXb4P8b9e9i+xpbyc/MwAndG+165ted5ZGZwWObB1obhp8bln
1mrciflc16WHUgP6k4ukChZAHlbyDRy200b448jGTpXB91UN/dA7cob0+3swSAux03xLWcft1PCN
XwCK+UK4iNZpk0TqXZCr1BbpeD4HD+gWOR13MJ3m1HVCP3g9tU/T1sul5Ql7k0a/smcPCeQj3Fqk
gSbOLGCnu0dWUB4GnvA8IOkgWxbUv99VGuO9oT6aa3oBq/XK0gvQhvw70fCfhRswObx88g+4V0VP
859Ck6uRePgslEeGLSoEdKjmetVp9YmoT7ExdUieDSu3e0P0qDjlKd1zLIZm3fVS18FmL8umvG1Y
YggxViwws6dCU0641ny7OI8tEqYTy1GUt7sYWmdPXmFjrh/T+t4prK4W8kJzGjG2ZlU4N6wOz/XJ
SAa+zh5CE38c2d/tRLJ0B8HZJa5sxYaNYYCWfcI43BA3FePn52gUknsKgH4kFR7jzJ/RKn1dr6xY
GYzEVzib6zxZzod7txonevvN1yA4cakp3lzfLr8qtosU+b2Ak7l5sQDUHmHOWEAUqY/5bDpdkH9g
BhprPIbN66a4q6QK8MrtOxhCAGjMUIulqmS3+fCpotajWm4lkkpEDC5d4QjBDwK3ej1ERGIr08j5
l/aTdALlGV+90D6aCVEVmAMWKnFo00zC4mv1tr9SPXtFXylNRy2cBtvI3GGNjlHOpQoz4Gq/6ns1
V+62pEVNuIJ8EAdDTr2wJWePOZSThXlvYMxOeSv4yPgEq5WivEpNIdjIR4g7NowFUKBxVQZwzdfz
eg7L/J/TsEdyhomli5UbtIvHiXuTpezwjxUHAZmoYVNdVxkyb1AqNKRzdFJorgd58mkDNKZSsRuf
hse3jmS260BXAKqFQfwsFeJlrG7DuqhP5P7+A2ssyg+Lm4m5oJy3cPxWITi+Cy3AeHK2r1jqOjIX
bYehnZa2QkjajGLUi+1IjPQ8ybxsYPLENJWMjmOn/fkwU00QO7SQMWoPlXu5YN3triIQHnKJnhME
xEczsZIg+NC0na7Ol3jI9Ygdppg9JkMnoS96fY2OOGw5phuOk/37NWgw4QwkffDsE7We3GyNtrCM
V8AAPZaLMZBrfYUnniow5Mf+a9cHhSDnQVfvlDT+qO18PbBKD8uiXEgArqAL7a573PMx4lXMr8Ig
PWFlLH7beDztgV+gg7NjcJqcGQEe74FVilnsEo18WRCNa+b61UiPEjfMJWh1H/Naniv18cTWW5fd
hMYfn/QB29BMGnFuXleD9IUAPtFYlXmPPInF9/VNjBcsUfUQX1Wn7RJt3Yw1kzDMwjkG4bAno/d/
kq1HBmakNIXppMzGjSMgvjGQNXUfPSrvLwqYo+/uwavrdQ3G6CnW+/fD72Ya74xhsUb9OhtXMS4Z
3s8kgLFnVRRjRcAh697obatoLnWOofcVLRmcSXXKc23a+21X5SEbFQKsD1SeCKYOCajoiNtJL/gG
emAyfLl2aB+/6/s4V+4kTkZXGE1oq0D6KEocHHwj+/rFNDVaaa3gkAhIo8orAa0ardfequobDoT8
AA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
