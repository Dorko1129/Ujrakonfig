`timescale 1ns / 1ps

module test;
    reg [3:0] addr;
    reg clk;
    wire [7:0] spo; 

    EX28_top EX28 (
        .clk(clk),
        .addr(addr),
        .spo(spo)
    );

    initial begin
        clk = 0;
        addr = 0;
    end

    always #50 clk = ~clk;

    always @(posedge clk) begin
        addr <= addr + 1;
    end

endmodule