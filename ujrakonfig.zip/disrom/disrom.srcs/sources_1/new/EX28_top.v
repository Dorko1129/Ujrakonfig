`timescale 1ns / 1ps

module EX28_top(
    input clk,
    input [3:0] addr,
    output [7:0] spo
);
    
    dist_rom16 MEM (
        .a(addr),
        .spo(spo)
    );
    
endmodule