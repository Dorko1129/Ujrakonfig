-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
-- Date        : Mon Oct 26 11:10:26 2026
-- Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ dist_rom16_sim_netlist.vhdl
-- Design      : dist_rom16
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a100tcsg324-3
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7936)
`protect data_block
4dzF3dfsRIXZWy9YetcX50Lt8NvK9xiM2YODxF29taEJOPXR//cLEk/50RsIftE2/WH5ynKPXXAu
YyN9T++k5m7O+h3+KqxZfgRaHltigsmqUHi0BMtm5Rb4jFHfhnhokBPuj7XCFOLBQ6M1HDIxPbu8
qV3T/FhaF4OIUKyYtOQPV6phyrEfveVG1IsnFOodrpx/pEgoFiuGgLCWkm4ZHZ6j2CEKdzy7Ycel
QPC+4R21beMBKWD4shMkKKZB5Kv4x4fm01qbyP9j1+mGYkocwScOFErBEyAG5BD/DDJs5xQnVl9w
XBmMVEjHKoDhVIESS8CoLwVVYjXyRufmWocsNyk5o8Egw7SQmgN33sx2D0A4DN6vyYUuCzFe/Db8
naT5xaQzSC73RN/QeltxntKmGiH8D6wNnGqGmrUm/6bd3L0WWmYgJjrI8Tnayf96Ap41rvOB2Eqq
ek+s73+1/IaJ+XT3egBy5PSpw7PnE+JTN0M3oWdkUhtjZkwFHNrUUVkEXHDLi1swNqUuB71YXJav
MR26vxtcCBy5M6ymHuO2MCftGpYTUsYe9Rb36/PBBRhjoxl/BbWdWQm8nVxWPcOMfuVqldSfCFRl
GDjcS4uAE6dNR2NX1BDMOfXhCCglG5cmZDUenh0SfFl83skSCxn71dSyqjwO0xfI++kzeVkrXJZa
sRWZpuJeIvRSIP3bE6emkA6ipYycoEuYUGYqdaRJD8pzoG6N4k6lMpMDn1EFKYB+6efgjVfV543P
2hw733GqoSiQsta1jF+yFIIoI1xCtkPU2Ds3N42PeW7IeigaWj2lQ9dTSY8Phv5tnD2a9FAU4Y9B
gJC/U+r2aH6ygXi7nhtG7iKm8lqxQydbSAvE3V5Im/TEJfzhf6hKnJiIdjcQF4q2xDLE+IntyG3i
UNADv7IrEqLVwooJAuHLFDfM8knqb4JD4JwetA5y3wH+4KBZJfsebaHrPXWDDeBvjCgbCccsf1pd
+WyFL8kCFOmRUjLnxXULR/I6P21Om3LfSc4cpdI/xTVz8oaCxYos/Vo+7s3YNYJpfWt6ooPBFFFP
ntXdHxnsYrz2dSXZVHbMaZBS6MjercKaDFaRd4vVeNnW3r9+57mJ7HPFMwMw/BY56MHRYWi+CFdb
Dvy82eRQIpDDtmdgtmwU80iwRXvKK0VuAju5GJjtUOMjmCKx7e4EdGbl/0fxp8+7sxYZRieKXFck
QcdSrFk+hJ/awC/clt/q1C4sFF2A8P/kKiP/AakxCN3bdqaIIDo/g3ykvC229g5dElCT1pbx5v12
ThvAzhfMQPvI+rmdRUMLbC/22i3W3X1MKFOFKG+FzZkXDNLzhSUBhNUIOPNd8FYgksxKRWtSeAq3
Q2meVU5orSnGP+bbLSoQ+0lNTpux0r+Gz4169vVQDU1psekfddIMNzW1+rN9ljBhRVfrfGX37J+u
RY2wBnacTlbGp8bHfEv5NwTK6YGW6XZTb85IuxzP7iFOuvVEtnY/3QR3iug3djDXvNQsFcg78qeh
3WRbDHVR2M568wJSRbjN3xO/91Ok/NhNuTYoQwSWvAM7QNtk0R4U3ES8aQNvA6uxfoFJliJyUzUz
SAFIYb82SUEuIQcYM85ZjB8bMFd6Z4bzE0BwGfFTsLst6T5iX4hnNt8bDb0C/AWu32EfvLbQ+8TV
V/5h44cmEj3FytihSK03KH2Dddsqxw2OeX3cthEx6UR3MJGMEwG1vXoeXYunp6ehOVrZ0thBgYBx
6zG1jKEQPWD8LJDhL5au9uAQgfdtzgXrLhhbcv6kXNom1tkxcMMTBukxWJLXrbgqthdpLsQIKOPR
hF74j2JYXj/nF/lfMTiYda910JSujwjGCKmxmQabqpeA8pKXmbzDJR69bZEOQ7sUqeKwU4e6UgIY
j6aVYtjtawz5BkpFWfF0SU5IKbg3T2epD39XItmYhFL8WDnorbvJLcrVbYOmYP4XfKbmYiTl4zyh
WtgcWl0W7+vlbYGhvWJS8OrbqY3Z7HuLek23S5biIRDL/yOoXHugnKbriT2Vpvn84r+9/bzwUrYC
a0s/cn1yb72vmjAIv/71f9w7hrXFM+7aGXxk7FK9KmrYL8wAi07u+omYmt3D7818c3H6S153wz/+
KTMs+8iTR7AKEvVZ7D0WhfX2zQy3KIO8IidiMu9bZd2mr00v8qZ0kuwvZ/aEIjtp6EWUzC1XTAxE
f8i73PQvpGP4O7UmvCd11384Oj5hSsC41vfLSxF+OvpTiRK/DfpfaPxGv9p+ZDS4C+6/FBPzJbVi
3RmBTv0oP7MIpR6cH4RcoCETRcdAtm0WL1jqn98acDvZ62ewwLKMcErBYvURDIncTnU6DNh8GJ7J
ZkqjW4IV6JXKQoFFW7gCuYHQXRff60NuYVcXzdXg9NIEeoarBrS8h+gHNJckmi8ljbaplXp+Aa7Z
XHBiES0BlncbI7WjXNRiIjbZLdjA2EqCfFn1RfNVDWNj0mFdlxC9Dn451uLuMJE7PGUnov676mbj
LoUMn6f/afnTPGavaRbPTN1Lk/ybJySoMG0HsB7eNXBWe7iKvq5IGbqT1G9WcghFRCjo2Wkl0LR2
tXtejwvXiuoO/xP6U9JAGQ+30ZVN6ewxsAD4r6d/gszh7qqMaJfv+H+7taktdpewNJq3jQQlHP56
bJFXSTNPKBCQem97h0ErCO2Na78W8XgvQOu8xjZEokCxKZ92VIT3yZZxu7e8neQtqPh/3QXu3jJH
0KiN2leMGhVtrHhTC+URlos3k+BEYSVa9xWeodgvPOj2CwCDKUZqj2rPNVZpPI7AcyTkNNNX+YNr
mgaYtvD7J6quL2oZMboNHlWngnS/3uEIJerbMweOsXsLl068TA9kNDkOC6nLnUGmZja/31SPa+jq
LWP9x1IQv/WF8m3cN/nPImwLtA3rW4u1AWY6N2crgl/+uxQpuEny87syQU2srQVaMc/ZKDjBiNUP
EhvnutWFQZfVSbZSEOcQwowlldn6nxhmS20jAWrZH9DOrbjnI4/qkw+07/mcKP+VCb4okJnKBxk/
CrtSMCUCyMU99d814zPtTM7HVMiyKNYjaiP76R1zCeWwBsuvXQ28A0E7eRySPonE0fEhoPDEqq7u
bhiKMwcapb0fhi6dzFR/woitFZSPf5xweUjx7Ws0F3Da4pq6OYwhKqYpJxcODdnzupKB5UsILIAC
CD/ExSUyeFd1QEaPyT3ygk/gop/TS0knjGMHp3Cw2F2uOBKnBEbBBouAYhck5BCTiAlpWvs8WcnO
JP0cpPjNdbppKyFbhb81w813PgSMijCDIvMOEhSS+CcRYBoR3Aw0z05TWZn9bN8ExhuL8LZE0brP
Asv7UVy9MWjCFfHYDp2BjZdmQ4Fls/3+vOvf1fl/FqSaR3wdtKP8J6+TsKdVxhoJ//yBqj/uTwa/
C+3NK4YoAaLsGidxarN//aUmgEf/hCIcrnGZNE1PolKtDksxQe7w/TsEu+H2EIKu73W0eVYjhpky
DAmgrcAaIBihgPDWyzlPMU5+8wQgA/xA1JNx5nKAPtgJBI1rvHQWv/zFxhxHjveleHV09GlvPEbh
MMN7ByfixZrX3r9omLsqifxd3+WRfU3OF8RcaHdkSyP9Li6oSYAadqBylmjDLiyVF/+xbpuX5vVP
HOcOVIlJIm/bu+dBbdYNIe5syBnVL1i8NnIKT+ArSYkbzW3B1cIUCnst5CXbQ7cPDIKto4bYPSOU
CISBMXIW/F8hxqpkZWTcjk1SmLsQtdNVzuO7+8gevEaG9cz7/Uajin71UakGBfdNgX9ILPesImsK
FC1jyz24pfd98NSOw7bMXjj+g/yIO3YtQfR9rut96PYG3airx7Cat2//VcY0HhmplNYplBwItw3Z
CKsbi/jOi20JvaiVd7uQ1vgRuVL4cvA168E8LH/dvMbeDtaAmlOQcNYsXe6SJ0OwWOAaCr+BbsLP
l3dcv0f7cCQPg+SNGWgto3pdUCjA2S6URkWVRytHI1PkbBWpHQll+4wM4QbpOG071Kt4wy+ugS8U
WzkaE3jVXaDLMlbptAnpRciwVkvnFNbZJg3WSab/hs0iQVR0jJtXeM6F25713R2tAFljII04Eze2
rnzV/LJnqHh8BPTZ/iBqvOrcfznzRgPwBeYHtOjbMlgTCmJdpAbMVcxBHrjEBOXlJmOiHX/IGU+2
bYWJMtJukn4pgLjreRN9jeug50SMrhrUw0X8iu8hN5Bx+Oj71j3RyJodQpok8R6KTPsBTiW2UBS7
67Ts3UBLjkij4sxCGrqQxysQgCSOlPbY8RPkWJrBByohzblZ5Vn9rveRePvs058YUFZ/OOo9as2A
bX7qm9NYkJlxenS7x/bMZYKb3VNgAqqFIUsQaoUBXSrj8gdqiBCrDyXd3bD9sDeXcOqjP46KJq4u
Uzce9ih2SyBGXEbkpknuaE1gJDz0oxaGZcVSCcqENd15AsVIaLkETf9jE4nnU01eNT1mVVAXyGnE
6v1QkwcxfdAu1aHa/nDBmpFIgeboSkKX2NP/+k2zTZqHktcZhW0ohJ/DE1pWL0djAQBrVzr0hyys
DmBRZamy/ITeZELkMRn2OUDJgaxO97HzAMfKb2q+PxcJlHe3LgrtUtqRjXcHw45k/Qn2f/Mafbku
mLVyH2AaZtlD6xhl0l/u0OiZz3yEuVQWlD0KIaBmqsvySUTd8Sa7wpmUCF2mn6BXeaiiuiURpnRF
VDSynzaAzUYvsr5sY9bftOjFwejdPhU01mxHxM2RfLp2yIvM4HHLpCkzitF3rA8hFEPqny9YSEz1
3psjzd4Vhtw1cUG1YampdsxFVAXeOgUWe9k/4KkkneDynUoT1SG6Lhyl0HJXAO5P+WP7JWuoYVqE
lWgI37gFvj51myMVJ3ZYECRpwobRsz4rTShTDVxeUfyDz19F7xtrTLk0f5ZZj9YHfr0woSNmU7ko
ZmucT/pjG+1VZjG/8RsEJQt7jvLPDR1RpID7/y8hSDzrtC9ghb4Xnr8Qzz0uYgeASgUgjsftVq8M
1Poo2vqF5sKHuPNwp+iV86wpYOlfZbVBlnIB4yfgpBbJQYZZSXqUuEfsM5Bw2zmUUPmm9PBG5Xup
4ldAnjrfUf3B8wsT4P0uy84h9bNWKXmT43Xzy48HrMsvZzBzZU6vBQRUHHhRm9iYaSfF4Oe+CD59
X7NQNkzuXzAz3u+cpDBmWHzsLs2VPFJ271y/nMJxENHyZNsSPD/kmURkp6t1fUCIOup2+ZgmwEM1
Q7suv1RN/UuTOTqWnd3XKkN5FeERXmNMBvA2XsgNtV+/HuuT2TBvpOG978EJmQyHB/nxg8o7AQXo
iljDjSKw6Qh+S196Dv0aW4RVl80QVw7JT/umIN26E0S5PEW/kE5w5Y8sAFYVqnLMwdH13yhAqhG4
n2CbA11jYJVNPzZf9nsLbiz4DiHMHanqvNKzLPGxX6Y/tojZzuxICgIE+H/wJm3k5DvBWDqcSAZo
d+7F9W+bIL0/v9tKiVOctPaUo3y1lAy0hRRaGaGkwjoZr/YnbOM60dgCSd45IPKWKjcVAQrJzSlk
F2rDvS6pXC7bcXnFClktpeUa/mI0ABK4OmvJyq38UlC8B+KDq2BWsTrERHYYCQq5AhTlByopE5Yd
7lYwc8MU6lKlJL9OXwcW/SjCXfgGZ+z/FLdsmsNmfEEnyhgBfUqqQ1kMQAczHBQx5v5lx1/0Dl0t
vEVa/R0ai54HutGdhcOBGV1oUhcfUXfSPXFF1j3/lVZgGILwfk5JBlFSEfN8PhMRFcAPa9VZW0Xx
oKrmzFCadFM08/kT78DDrC/j7RUrtWfbbEa6HwVhmRY0twtbpidF2teikwFxZdCWmRxmC4VMZfs4
uo4ZVZcGmLrkIxR1wZIphfksorvcGYmY0GEBpkLT1vgCo0g0xk1jeLdqea8fjrL9Tyyq0+Dfu7Ho
j4iZQ04ylGFiSxSM26AyE+MmQ7Qds8YdhvEAECvPd3/RFPXZsvnsgj7jL+TM+NdyxLrYC8db2d57
i+l/qdc7dRuXLO/gV1rtNVJE0O+bcV2z/7OcVxlUHRocV5WNcubGX4O4l8Rge88lVzI10qI9ZofT
Izu6cvzURsYFaWTb2hZO/irW6RWS3pqQyw4+XYhk4yz00JDLgRek2qdzxfQ8//Q5ze7gOZy4Gc2v
YboKOv72AP/Y30zp5bI1CFSO8swim2AQrguFEMgAT7WLjRBxSPklYt+guIVg4aiA4/EKhEFjW16Z
eaebTtS4f8IFHPzjUvgqHCqX6dJ4tTGvyI6eqdVFcNsif/YUX0VcZEsTqVdoGAn42I7ix9ysgBWp
YMoEZHY9ZQL9J7qi29cWVBrQ3ceKM/TlNrcJygy9VzVIJL8vnnuC0MR1uBQElpVLK9KSBiL1a0TR
6E7DQLD3gzmkym9x9HhCEgmklwB8PO8gJHBwq4nmAXFB5c3jpmHNXTp92nTWVyC9Jt/1OG74WQ9K
2UZfH9z3VrbatK4/pXWrW0IimFj+X0XF3PuJwUFNAvFZzqhmlNJpe73AE8viGFFWPyWLDg5KDdiK
W0FBePehfNuFOR8xiFBHDwYEYlPett9+lBwU5ogJy6phf3w9Ca7U1RPRY9uGxd93Lkh3swMd46G+
EQE1WtAMCPUHAIMhQuzxvEB5TbFnVbPnsPiEpdPvbeAmj1AmjXyNJEzEaya5+YfUAjmVDMStye11
HZ9vNQpdFYvm55dlUFbH4zxMLt46LrpBoedxd212rF3Z2r/H4Fy53Q7XE5PSVdLKV6iapZNMYK4I
MFjDcr75dn2noU3a7J+uY1YjX7afmp9V5isGaos3QKaJwIRs5d+fdEm4c5sabnJVaw8cgcOgr4NT
FK7uJIcb+/o7FMp4wkBNx6oXEfMAJ5aBIxE3i8F9LZB0WcFEqVxRFRMq+DHkqkrmKaAZkHg1jgWh
LKeANjXJpnmrRaFSY1bwyK/hG24zNLVLEh9GAjx2nC9W+GQ7k4Blb8GjdGE+AjJFITao5JK8WBjX
OUZM2QmXNlpPE1RsPKdHAlzqgVn28fKlmwEovHwzm4VcA8XSdqTlivfwwX1RwP/IUVlQhjTPygy0
DY9ePFnfHrz0f5/j9OKWzqvHPk3O80Pp6c3dtpKokZxefeO7Xfpa/pPWqh/w9tdfyxwoomjH1SPj
j4eSQS+4Asih0HgP5tLVmx/eojmERuIjiqXSrNQYmKGWN+rb2KriLh+BqsQagaB07iDWgzlcuFV2
bqf4hSzGYCjBIRBnRO7cwGY+hKHIBAwh1jmcFVMDfuok8B7xBE8GJHiZvBuDLN+FLzzWjw0FZvbN
3EOsZmn6SGi7TF12RIi58JTIcvlaIhIEXnV7DGW+q2pKnHEAzXMPdFOUtTpQFbWG0eoeN7bQYAto
Z1gnkj9WIydwV1wDBNHL6yZ5HAWdM9uS7mTQK2Oq/JvcsfLBcgIp9JDcKcKdy4CSVXdKDXCTM1NZ
okis6x6MCFQhh/2arnwrchVRhbhoWlI8mN/fAIq8fopODJ1WEX9Z5UQRXoifHYmHkCJfV/LzDU9P
x2q1fhOrW8uH6ul4RNn8v07L1hpmZy8Jr1OFb33WdcWeumhNvRZVB/z2oyB+sXAExHi3Nj0/6zj2
p7pGLKD1fG310ZFGuffT1T5aSvv8DQi/AzegjUDpIcatx9zqgdCXAwtc0mv4BLLq35ebs0B5Vafr
O/c2xJLfsZ5+V/0gJ1apyL+COT8rvFpD+7gU2//gBZ1l+WUddEsPJBTozdxWyccmeRBL9Muw1V++
9ugJXH2jakdSZOPgPOVjjvtCDwCL1Jv4HQaGhewmhYe/vw4t9Lrcsc4wzNHabFG3U2CBimllUVWj
k6QddWEWFaE1BnNmnraw2Q2btnJvsD44KDKWHGt2RXBiyTc1zQHlC3PRbWRHFgafyaDLqkj3eltf
TyH57zh2gMZ3A07oHX9+y0JhsoEmWviipJUHns5nf4NYQYRe/vAxVEVwIthTYmw+gUpKR6ADWI1b
8QoT6OcUeIxRVxJfLawHKfTcUmJP87nLE7JtIE5hLGEyY2GulagmPBeGQjh07UyR87iHLmngW7rv
Kx3Xq1MbMZfxqIJ80oLcCAZoQO7UCfZDEz3bXYQ6aIsvkTgyz9dVW5SxH6uXAYPM1VUUd3jkMFlY
stlMuAcRthrvx4fGPh0D48f1kEUQgASU6zwlCc4XLfxX0qq8aRr7HyIWR18KZdYrF1Rgfp4n82C6
/kicucGPcBvcEGH3pvfrjrEK8Bn/9m8gr9o+/Gu7XgfjPKuTJCMDaq59dgkJ+bhHf/ZBbzXstC+j
f/fGRZEkIwdRbATj9S83HOstvRLgFmEdLSWGgrlQiKkRsU9izbK1oZn1NnPS9MCyaSRJgTPFvkFi
Rq+GO9bTIqHJBMKqtR7+azgj76sHcD7BTXsXgBIGupKSpn2TRs4GckQXIC/Te4guPPNpSNZFLrps
yXG0ZMjypwz5JXf02wfuRoYPtdSQukkDyoE3gSVTUA/YMmsVX6u1pJKbUZzljxoS+lYzMirzlfOA
UiXMu0BIQx+RDVhpF/B+joTTEhtRcJX2bQm1XCRVoX38/IXn7wnmkqXz0pBuhbI4tweu39Xd1i9O
6ew3fTg29WZrrt0MG7sZlau6R9qGgJjBeAYc4yHPrlJRoiaSyupwlewP0iJZqi9CNZQnEpKpTbYl
Sh0mYSNap6Hk15NQRCzD5yl1GMhq/8rqVnxmZZiSG+5epfi9OwSXHFgYQ6rwjAWyFn8emgVnMYqt
pMKVdEgFlbWAEAwSGslCBXbZDpTcitzi275Qlh0LGR2TLwI5qZOZDEJjSxC9vLCxZl7/UXZuunN4
um8mGS7Ss2zT43IROu3ISE7UmpHmOUX5tAgmdJcXSN37DjR+xuSGKU3zJl9h8B1X2WiMgPBGjM02
EydAUD1PsWGuMoPIat6obxT7xpyGLjE3eiAQU5/v5S+qU/Srv4J7j9hqJ213F8yK8dgARy+HYUbb
IT25vLjyS2XJVZtfpZmQgW85ShUVWdYtTJCqMil+kDDkM1brcCtWXQEdSxPDhOJCw07pFSihNcR3
/yUphhgvH4K9icxWxbf7/fj9cBo1fJA5yM7NmcKxDHhzuZd6MPeY6VlYogk904RsEq5nkS8AhjiV
jP25NRIhYekbQHDlQoehWzbTFXN6qx1LQF9Q2B1gISOi8r83hm7bop0zCRi9WHvEUfcCet5MMi0f
dG802P6FedUZQfS8LQUU8suU0Y8cjyaKy8QrrdmAMnH8xSVe1gr83zo8w48ENbOJR40vKipVSxjt
0h2Yfgax5Bk6Eak0rESM/bpJY1HJ+kyZm+AhskoHceuGABWd58HwA9X6x3A0+gHtHaqEbyDJDLxa
3aeqlMAOSsNtJuuhNC80ueIGpsjFLxMMsdirx9syB1FTMrjsf9oxom03qolr/latacgQ9rIz4Vru
17xf5CU4JgJO+seOyV+IBI/2IkFZzfkobDn57fdypJoKWNxVGBDoGMN0J3sZxVwzaZWmDqlTQIaP
zb5sFskkujbOvK/kropnXmjy04R2eerA/tDeVxd3uDqhSXJ83xcGIBf7/e4zfCm47XhxcuOsUJXH
UPfkJGbF/QzqgJ0/NiWdDLGrODdwat47tBcdQoXMlqpZAPnZ2HYo2BQii+hs577oSm+BRKFS845w
cWnEnCDzhQta/fONpd68VtFEJ3IzfOZI06It8L/ZQKa7Lgs6ylLnAVULkR1InYeN/i7nA3qLTlRI
1VHQwFC46xz8vaxirdAkiGe920KBY49pvk60tqfjSJI4Pg9nLqdB9epL9PHuzo+tSNbevTL78l9t
LejhycOAzM888hdcHzqHIg4tIa7uhZ2KjF9JrbAu9bThfwGjDpLmcyRX4WzJQm6P7w05CmXC00P5
1rqc/fXOQy4reu4/lPH0Wgu2Q2lmeu/sSjBvHwiwgbvyTG4fsEt5otoFP8N5elveGJo3M6/Qf5mq
C8BEo7dpbXpy6A3v+vcERuPhBbSWIexYtPonzEcPqKffY6QDHKKUcVDuaiFunTSUL+dmk5ANY734
RvtV+CbtN/9yIcc+Aw1/+IQwF0oIlnJlYwXBHklIBEn7igW6tn2yRchFEHP8ryh8JgkuIL5N8bhQ
A9CeisxEg48seh6E+cGK0iK30HP4qmXhA9NDqQiek5q6jfGXCtgf3+ZB8VLVeWbSZ822o3/Xw0Zg
iySiETgTo5NFVtdC5fTwd0M7+I+gmVpl4HqHvsQklil3do/oSFUw4Z9Ao4yq0edAkElrcAsYIaxa
/in90vRcb1UUtJxEmy4mA8DbZctwibzohIZiwoWrloA3CbsxIY+L82bpck+y2w3fEjKoSA14t6fX
r2Ltko5+t2EfGGk2QEBpKLC4fHAWmv6NhuAvJhY04dzqx8yEd07mHrQ+WR7f9vgTgoCRlTZj9rqR
Wmua+kW0PtQzZpFXHlCRxW1D6FFuNKMT+TNGdObRdMSwlEF5/YHorno3kXzOLAw7esuP2IKlySM4
FqKzw1ic8ykFNw/SjZ5Ebu1F1uAZkONU7ODiZ1+xTc55/0SppYnelB55YhNn6cLy+A4/krWwx+WD
WLiQdnchm75n38R5RA==
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    a : in STD_LOGIC_VECTOR ( 3 downto 0 );
    spo : out STD_LOGIC_VECTOR ( 5 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "dist_rom16,dist_mem_gen_v8_0_13,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "dist_mem_gen_v8_0_13,Vivado 2022.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal NLW_U0_dpo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal NLW_U0_qdpo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal NLW_U0_qspo_UNCONNECTED : STD_LOGIC_VECTOR ( 5 downto 0 );
  attribute C_FAMILY : string;
  attribute C_FAMILY of U0 : label is "artix7";
  attribute C_HAS_D : integer;
  attribute C_HAS_D of U0 : label is 0;
  attribute C_HAS_DPO : integer;
  attribute C_HAS_DPO of U0 : label is 0;
  attribute C_HAS_DPRA : integer;
  attribute C_HAS_DPRA of U0 : label is 0;
  attribute C_HAS_I_CE : integer;
  attribute C_HAS_I_CE of U0 : label is 0;
  attribute C_HAS_QDPO : integer;
  attribute C_HAS_QDPO of U0 : label is 0;
  attribute C_HAS_QDPO_CE : integer;
  attribute C_HAS_QDPO_CE of U0 : label is 0;
  attribute C_HAS_QDPO_CLK : integer;
  attribute C_HAS_QDPO_CLK of U0 : label is 0;
  attribute C_HAS_QDPO_RST : integer;
  attribute C_HAS_QDPO_RST of U0 : label is 0;
  attribute C_HAS_QDPO_SRST : integer;
  attribute C_HAS_QDPO_SRST of U0 : label is 0;
  attribute C_HAS_WE : integer;
  attribute C_HAS_WE of U0 : label is 0;
  attribute C_MEM_TYPE : integer;
  attribute C_MEM_TYPE of U0 : label is 0;
  attribute C_PIPELINE_STAGES : integer;
  attribute C_PIPELINE_STAGES of U0 : label is 0;
  attribute C_QCE_JOINED : integer;
  attribute C_QCE_JOINED of U0 : label is 0;
  attribute C_QUALIFY_WE : integer;
  attribute C_QUALIFY_WE of U0 : label is 0;
  attribute C_REG_DPRA_INPUT : integer;
  attribute C_REG_DPRA_INPUT of U0 : label is 0;
  attribute c_addr_width : integer;
  attribute c_addr_width of U0 : label is 4;
  attribute c_default_data : string;
  attribute c_default_data of U0 : label is "0";
  attribute c_depth : integer;
  attribute c_depth of U0 : label is 16;
  attribute c_elaboration_dir : string;
  attribute c_elaboration_dir of U0 : label is "./";
  attribute c_has_clk : integer;
  attribute c_has_clk of U0 : label is 0;
  attribute c_has_qspo : integer;
  attribute c_has_qspo of U0 : label is 0;
  attribute c_has_qspo_ce : integer;
  attribute c_has_qspo_ce of U0 : label is 0;
  attribute c_has_qspo_rst : integer;
  attribute c_has_qspo_rst of U0 : label is 0;
  attribute c_has_qspo_srst : integer;
  attribute c_has_qspo_srst of U0 : label is 0;
  attribute c_has_spo : integer;
  attribute c_has_spo of U0 : label is 1;
  attribute c_mem_init_file : string;
  attribute c_mem_init_file of U0 : label is "dist_rom16.mif";
  attribute c_parser_type : integer;
  attribute c_parser_type of U0 : label is 1;
  attribute c_read_mif : integer;
  attribute c_read_mif of U0 : label is 1;
  attribute c_reg_a_d_inputs : integer;
  attribute c_reg_a_d_inputs of U0 : label is 0;
  attribute c_sync_enable : integer;
  attribute c_sync_enable of U0 : label is 1;
  attribute c_width : integer;
  attribute c_width of U0 : label is 6;
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_13
     port map (
      a(3 downto 0) => a(3 downto 0),
      clk => '0',
      d(5 downto 0) => B"000000",
      dpo(5 downto 0) => NLW_U0_dpo_UNCONNECTED(5 downto 0),
      dpra(3 downto 0) => B"0000",
      i_ce => '1',
      qdpo(5 downto 0) => NLW_U0_qdpo_UNCONNECTED(5 downto 0),
      qdpo_ce => '1',
      qdpo_clk => '0',
      qdpo_rst => '0',
      qdpo_srst => '0',
      qspo(5 downto 0) => NLW_U0_qspo_UNCONNECTED(5 downto 0),
      qspo_ce => '1',
      qspo_rst => '0',
      qspo_srst => '0',
      spo(5 downto 0) => spo(5 downto 0),
      we => '0'
    );
end STRUCTURE;
