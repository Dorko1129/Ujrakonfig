// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
// Date        : Mon Oct 26 11:10:26 2026
// Host        : TEOKJ-2-107-23 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ dist_rom16_sim_netlist.v
// Design      : dist_rom16
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-3
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "dist_rom16,dist_mem_gen_v8_0_13,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_13,Vivado 2022.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (a,
    spo);
  input [3:0]a;
  output [5:0]spo;

  wire [3:0]a;
  wire [5:0]spo;
  wire [5:0]NLW_U0_dpo_UNCONNECTED;
  wire [5:0]NLW_U0_qdpo_UNCONNECTED;
  wire [5:0]NLW_U0_qspo_UNCONNECTED;

  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "4" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "16" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "dist_rom16.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "6" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_13 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[5:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[5:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[5:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo(spo),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2022.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
M9ERyrMNmk2Jjyg6ZCGYQpTqx5C+74+ICn/vAQ5KoRuxJNbql8tHJjFcOe3FAJX14Nokq4wtfvZP
2sPXAs/eYYzjjbnt4nx8oZRRPy0XyDpvba/qxyqBSxjChIoPMDwpXnxi+chZJU5N1zCNt9FZPAep
nLCjMCkQTlKbP3cUJIY=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FBAg02qOh8M8uZkNvwWHoY3ELncwvHjjgL2y2qLN7xuxxaPQj3LdyD/IETTPdSjNCB/rhpJxbT1y
U5fbF28Hkp+bzDuxeTWPX251wMhiEmdm4jhyMl2z+GRf2Z6VJ4bVM5bieaJvsbjuyQ9Az6TDmueI
14citDEbyRCyJD9EiVckdS2mZcTl37oVFebKnIeJGmNjOc2XrcM84JVJIG5iv3ryS2hAG9/84hEr
u3DYC+xS2w5swJXVSf0zV+w8xZulS3PTPLELIM8O+SEFdHetZKnrgG1aJ7V5xu0RniGAsyVwVbgu
M1jPqNLyU+9kyETKfG9jcGEIM2I2gUfmOvRs+g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
TYvdYOtu2OcY/hp0LCFlgwGgJeLJ5MSBDPjuyI3760LiXtklDVs7CUFlvRRXMgAzbHlMXbiHp/Xl
cvmN035ayt8D8gPWRXxnbQf3kRlW6EIFwFMZ1inL9b5f47gsuvCP6MaKiTg0W7+/ZeHbM4jHXvRe
b8HXvQvK5kVwtayEwt0=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GkcGg32vdV7ZS9x4Uw9v3hZEcxD5hMmQXUqa6shDPbzqUGIxrKpTOb9W4Sgi8rq+qw7QpAZp2JW/
MkYAH1WikFlf+XWG57y55EFV7oRoKQDh2Yz0sZEwVhwTGwSAqfnjrmPITofdG5eiey1ySGprEKsT
mqWAV+ZN7TkQkKup0Ukf1O+8giYKT/7UibTRqG/CT9dgU/4atPgYh2QjNMVrsAH/uzDxh7stQMYe
nkjZBkpLWOq7mxEXTKVtYAD/8G5qCJELRcvCuUKYz4Une1wDj+L/vwRK3IAdWKQ+/5mvj0q5XEm7
IKu5HYvalbySwRWzaB00uobXZorNhfwSv45jHg==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JnT3Bfv/DUBx2mIm4+jpmHjzhKoX4mNpcc/lgscv3iYrJw8Uble396hMwPsVZ+kkAsmYtegNCiTG
Z7kqnoNeWHv+Grdizsq0QM9S2KJ5EoZhjelE+3Cii/ztNHf7Y3c0nBPnioUQ5YmWk7vgoQl3SJ3d
vwD3G0c+fGJBRpi14hTJOB2wtu4EeWcJ1f+01LjKINeucLlwacjnN0tElyRgCNKfsRDAQiMqwKqg
XCleeNY0cyLXGI30pXMpnbLizYlNKgVD6DSeNaby0dhW4phR0a+9xteo8l8eRVzTO+VSOcYSy8rU
6Uj2y0Up19vcq91C+/YeHlh24VwNI2TJeUEDwQ==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2021_07", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
AWr8D+IaT/X0jMJSrwmWnhWOjt0+8oyULINYaH7QGBLgqKCVtf8rqo68R3/TZ8gTkN73fZOx0QCU
3WEp7Ga1gUsqEgy+2zGlncYhOzx62FJm4Pm7S6LbE1qdg3/9Pp55JLaf1ouYlZccQJ+yawj0HgL4
zR0T347Zg2aIFxQZ28icCuJbxAZsZgAT30scXsTMMvXlQQ9NI21OjirKgHRn3dldIjpkL+BrVBkQ
Q7MMiTBhpCn/c+WXk4H9BPc3vMrVoh6r5oo+e1858Hk7osyxNI9zuACaGwdAatsW756kQBMsQoUj
TmJksSfucjrHVSuLFffpztOARH3LXrhZcCZdoQ==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
fPVwMHnHe1L8weZTnbBxjlAabwZZnO4DZSHaO7tHGHAw6U+w+7Rc3BwfQXtiTyGXP15rvoLhvVpo
i1Tzs4zrV1X8vlWrxhS6XA2VO4RFkpCjmnHpvdgnW9mpk7w90QOEZIWZQST/o15t0wDT/kv4J36r
Ho59mVFCGQQSSYx0209u6sG2rNpJ5HtWMM+tDEDHUArucrBmPOoZSq0VSQsTHtjJQxr3U5fv9l6q
aEBWkjnLJ6zqLkt12B3q7V3iFORPpz6XNMqA6wzArzWirzgTCw3CduiSAgbNgoGmV4eNrVb2DfOT
5V4ni19GigMG1fHCD9dNPWGiRCWpY6iiN6iE1w==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NkQB16Pku9sdGFuAkY+DjFhWzKYvb26AsK/VO1//MS5ztnK+V9d/0K8nVee9kGDNC4zorSd1NjRc
Jkj/JJm1k/9QiQQwOSB/94zKWUyVH2Rvw3UOuaTu9pWRQsIdmPNwXBKCOF5L17HHGaNqYzvHF7YY
REIp6VR4HcyLq2beYXn09Mq0f84obUr7+CMgh8i1SaLa/ydMPS9xsm1i0NFB3qcEC0dDq6xklwsX
s198UBI5mBJTEUKi38eytWXzQPFTmqdlD3Qn4CgstxSdoLrFHchISqt+L62U4xU6aVyYXmVaeebF
I1F3MAXQZwZwGETW7RW9t/+3pJtkjPfPtdnqu/Sg+zP+vLjSV/NcONctKnTj86/z+TTehoSH8ccr
BsjV0PhAtR3+RTr3VGkKJoUNeE8yFQIHlES8UamuSNMh5XrbmcbFx22MZ9gLOa350ytm1N124jNF
V860l5gGbt/8NcGf8I3EVPrYblJ5ZLGsZkVg1cKBMUys1yMm6Ci2Mruc

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
JDELzo7luYHcwIl8sAAMR3hvm1tr+ZaD3VKTvYj1uwYFwuIPCkUfjVi8OMAgp3Hh/R1wDZSeoY7T
xpO0sKF9MsovKwwArnByLL8zZflfJIe5AmC+jE5a8qUxydp4liMdOypRTLu6U6EUYUwSj6VOR0Uj
deCoQCr/gVZ2GdNKF5sKZsGXZSvx1Wag70BiGs69qhgUvVVlpbqpNRSB0DR/2IuSKCHhkucLXiTk
zVS7zC7GiyNYE6l/Yu5Ov25Cl+lY5cMZkqKvIFm90UiTBNYk4No5ofXnH/E0rNcbydv0BvWDmgKt
NXVratbi0ztKLb27z2lw5ZZzXCihB41kx4VjqA==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 3168)
`pragma protect data_block
60juYrVqjYnHDpHEoAg4ccrY8SUX9SFN8AY5PZM9Ma7FSrC/ClvsKB+kJgS9yi45fJC5PQ7BU/u6
AbNmmrOMqHCPlOiAv6oRd6uZmLPCfXpMG15J47ztlTLTQYSOx893iWkw2Q+PRl2iAPhd5xhFed/d
2+cYW8H1PHagiYA2zlP/JV/FC8zNXdQS9wyqAbJd6S6N1gC37C8khXyjUGYgYmHc0VsvToHIhiZD
EEUwg6sDuqehYGDMY36Ij9KHdY7riu1PYzvMqGUOSlFrneY8WWjtwaZpscO61GTRgJ3VrjOvc+Fu
P06fM68qVKqPI1uvPbnj8FUR2em1dufqBYJ7zxS6df4jitcjHXCZiGWBrbw3Ydk+K90vh/Mi3TEU
i6veh6ns5IbghJvFQ5D0myjjDfUoCy1mkneQlUR2jnWce++yhIYN/tCL7D00Ncgz78Rvw8AR3VGm
XrrmkR9cMOez3ehw/Kw22FmlQKCm7RMROpR5WFVbK237Ch2w0V5W2ucZRxdj1w3H225Qmr7BnZ7D
Zr05p/2vXsvKpGjIt8TKa5bCOOgP82QrZToP3C9sowZY/g6162GbnykCtUzNg4kooU9uVCgVk1s1
YLAidA6IAAUrchNL+/+xiq1ATpqSZWLgeOidm3xcZvc/7Pk8FGuh66QsrhnfjAnmN2XmsgAEpkcA
g9l8r3p9ADSfhANl9IUtGkvVm4PkwxrUGIhNpb+k844/M1N5Q2hbnFfiNVEmnE5ucyJY43+sy9y+
3CjmGV7+i9ed3b41LAlBiMkXi7XyyN5KKLIxl08mIRhbPEhmSRFhn9Ug1OuyvOl1Zh5VT91mcYA0
ecmnCXigofKM66W353dwR90LghN8bWAHNTc+/lRT1uBRwB5Qgv6fdFeaKNTW2DNI5OqbqDe5sl/L
62YO7fSxw2oeQQzwQcx1joly3tB3Csvg+8xjYuFhWySeIHHaJ6ou9JQaI118jw3naBE+3P2qmhEm
24IcN7EKSFQm8siCVAUE6lBMHC8S1dKkOMBTWpGCakbba2cn46Kxo9jTC38fSGfytjlbu5hioF+z
6KKVSDK3irF1Sx95dcJhDHzYrxFVREJr9y50Yxfg0hfZ1Ynt4Z69WUW8iXCHFwZJ+IVavTprOq4t
K2nwDuyZaPBxlsEew0B7VkwSUUF6zpUM7C4eKckudUCoK+b9XVYzzJ7TBHvrr8rxaVzEYFSSHqMg
5aIGyciqNX7FOgZfc+4j+nhqqJ3rj8i3PFOyS2jCybI0gxSCXK8xtPB+8Njic4O267PSKnQGY6Vv
dTHWSNk/qd6i7hR1oRTRGy+G3oxlz5zsJaNWdEFh9F+aw/lqk4Qn2LFIHFHxGNCFHYZd1Nf6KToj
j7FxWa+Kd60TOCsT2+P++pPI+b0Pdr03XRacIg8X1dVtiYMPXhFOo1DJ/mOHKKsGpzTxlFIP7HiC
Z+y9oDnzfKgYWOl36NfNkbCLGl4LxIpu0z6tDoqdaf5GSY2JTCj7VOIfxkQsIKcZoYsKc7xJrbDW
z8qdhc/8DVNOBpYbiZrTA6ahFUrp/G6XeUESGJiTDfJyAzySU3vPOUX9G71GFx6PqXF3ezqaxI4v
9gsfx3GSpJDYTNsJkN46oAZKCN4OjGtK5eBuusFNRIqc0rubWJsmPIPyF1DJnzny/E+dFe77JHHj
ieVtSo8GrypUHtadViIa4f/ei3TEOMawcjE5vPKmco377Y8y1ZtjOiR88eq6Sy3SlgtRoj0lhw/r
0KFwjfrRW+plUsOyd5pbHFW3cGqMdJhiMA0jXSKkx1rz5/0q9Tkb1P5dQx3VGzVrQPj/l2+l6WNa
4xv0piGii6BRT+KISpjL1lWYW8cAjHOUDX1iw8MNazKTgQnT4YjSZ92+jgqk6HemSTEpqs57DpUR
6bQVWF1KK8cDYOgfnoBBKgJFZo0JV/LzXsLR0cpqJVBz9jXb2ytp67JaDjtuMbELq8fhzHTWSllT
hgiponYA6j3cVVkdZ4H2yOK6MMyk9esJ+9hfwTDLEXPYoLtY5G4bs3BNzCmY5AvRZY6xkZdaMXy+
ugpeSbEPR9K23UlpmC1DDlCTUJ/8mqa0sJPc1xP5Y3RtpL6Hgs+DGu3Sd+TWbIF03i4yM8w86ZEi
rFWVair/feTlh81gQj5xl2RRYPNJS2rr7+A6mqnSMpSezzaqP6UtoB8Xu8lCmXy9KlAJeS/OE5Il
QO8cJF4sEBzlrF2LjbeKqAyR/jjTGYJzoLY7FLK8gKy5durE78Xvo+8r58RByy00TiCLACA9t+QH
mvZ/p6i0usp1XZglzOQ3LbNR/QAjMn0mKXkGKw7X54WUCqBhzl73uGmtzvayoetq0kyv5Hs3a1ZD
Z3YVHeNh+ZUKdnbGzfz/EsGS9xJCbsssyLnNhvkIhjTBvPCt0MEI2u2+/Jk9wZSiPeFSBUNIMH7U
lCwSKkY3MYTu8fzij/uUFxqaEssV95l++p/qDVRssBnpJ5h6Lc1PJ7vOiGzm1wO2PslNkkQCquHN
jz8Kvn9hZun8lQgQ5mqaX7U+TcUONB1/x1xnCwvujppg0vHNW36/Lp0JUNuxWcvORaDEvp8fDIXX
7YzFMmpvGjO3/gZxAoOvywm5xyV9jphjAg5GcNepJKPFyNPIoavwhU+FBJ4MT5WGNotaFmOn8xHh
PD1Y7Kw+gtC2Rx7ssFbLXplqYQz5yMw3Dz2drfk/U+0ls7XG8EQbYo5c4sR4AD+UN8hRklY2fDYa
7JvN63I5+WM3zQKngd5wYzy4RaMmccruV79YyVLXvMIALW/R2H/pPRYfaepbG/iINbxv0QZAAYOe
j1s4hdJMBt41ZFg/R/37VKPNZVI6WGczdURQiQi0mDr29Abv16ZBbBGwR1bPqKklFQFfRrPIzsy1
HwoMfxJGUITqFidmxOio+C2BJhYgU8vIYM4CMVcYCLHBf2nlzReeTGj4npqG5+xGomm4Fwmg3hQZ
Im+pmPpmg3I1qT8sNz35vsUTz59qR7zbeq2ZXn7UgejmxNa/2NEZUIZzNQNpR4UYAiiskhZwHrd4
uG+3d+WVsFtaHiyA8tpQ1R2wT4cU3G9p7gPST+uWM0LDrAlsy+hq74DKRetc0zAKRIaBKJcBL67K
nC6pYfQAnzgmsianjIzmm/jc2X0xafyeVzwU8TA9jHfYL0sx4GeMTRQb7he5ige4KNvf665VoAJP
/GQzMlSnwzzk5itDEAfOMwlqPbSJyLgPbH/KO6kO7qqXFquLjFqTOtnR8+fgO2nMonqEot51K6/V
/IcJo1nShVCD1X8r106PLGkZXM2DlANqVPGIa1QJLgi7/scLJEQsfSax442bpzMgAcINd17+Q1Lw
UGXPCGtuYeSk/Yu1vt/lj+1gohI3m57Vv2tQjiSGSeHhsVoLKPU3x3W847li7h3X7i8M4BzH9EKq
M+oVk67eXK2p1to3jxJ+Et8QmXyyuWMRX1qsQ9B13+4G6/mgLk3lPUGx+RCFOxqyvEnakBPXQPz7
ZNgBJQ341CojnA+z1gFtk/d5pyZXu40LKuOGr2qQ0/yCmi65q9UIWOikp7Kv5L0qDHGtbwDcCEsx
uYCMwyLvRj3Lfl+6zqBwPZyQdtumVSZTXpYOwRwrl2XWhaHmsq/AIWP+Es8QjB+km70Q+4Qqm1Vx
7hyvN2EHNWeiQ/v1he3NoLLIOPrGWVE/JSwkfTxsvMIf8piQlcgG+NXgQirWmZ8z38T5I/o0ZBVp
b8LHHiXN5fNpyXZUxF69U35fpeIgh2HPke8hLo1eJRiE0L7RMzL5iQNOpDGKgNtCOikb1KadpEjr
FM2P2wSCWaSTNiZKOCteeryYAk0OnaU9zGeQWtaV9ff0hDirYfuVzqtr9DE6DVq5uSLmUkgeOKxF
68TwprHaH9mZZXwT19JXcsMhokyKx/xPgSmr0huoeF04tVvunlMCAN2BFBb/oGfu/M39BvOQP1pF
UGcVWuavnqfj6Z2U7spFRzxwHuznVZdd8KYciSNjjbu79as4xOdnCnBFtolso08vi7U+6775TpK8
MARuKAs54fKSJYjRYZC7+4rNLVUqO/itUkM7B3sCAcfhA5ByHUKDtRKzSFjngJGMMlSQQbdC4t1W
NuTYq3HiktXkNEBh09Dq+xc1TntSusq9PmvqNocXtZKq5/xvgU6TU1zgUp/2SdR8M9LfQ73qVNtl
BB2cYO6BcwXp1Wdf9XhOsJL8BsHpRz4yqmeMpqcSLLTu
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
