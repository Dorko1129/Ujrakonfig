
module topmodule (input [2:0] SW, output [7:0] LED);
    rom_module memory(.address (SW), .data (LED));
endmodule