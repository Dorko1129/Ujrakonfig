module x7segb (
    input  wire [15:0] x,
    input  wire        cclk,
    input  wire        clr,
    output reg   [6:0] a_to_g,
    output reg   [3:0] an,
    output wire        dp
);

    reg  [1:0] s;  // �tnevezve 'a'-r�l 's'-re a k�pek alapj�n
    reg  [3:0] digit;
    wire [3:0] aen;

    assign dp     = 1;
    assign aen[3] = x[15] | x[14] | x[13] | x[12];
    assign aen[2] = x[15] | x[14] | x[11] | x[10] | x[13] | x[12] | x[9] | x[8];
    assign aen[1] = x[15] | x[14] | x[13] | x[12] | x[11] | x[10] | x[9] | x[8] | x[7] | x[6] | x[5] | x[4];
    assign aen[0] = 1;

    // 1. Digit v�laszt� multiplexer
    always @(*) begin
        case (s)
            2'b00:   digit = x[3:0];
            2'b01:   digit = x[7:4];
            2'b10:   digit = x[11:8];
            2'b11:   digit = x[15:12];
            default: digit = x[3:0];
        endcase
    end

    // 2. 7-szegmenses karakter dek�der
    always @(*) begin
        case (digit)
            4'h0:    a_to_g = 7'b0000001;
            4'h1:    a_to_g = 7'b1001111;
            4'h2:    a_to_g = 7'b0010010;
            4'h3:    a_to_g = 7'b0000110;
            4'h4:    a_to_g = 7'b1001100;
            4'h5:    a_to_g = 7'b0100100;
            4'h6:    a_to_g = 7'b0100000;
            4'h7:    a_to_g = 7'b0001111;
            4'h8:    a_to_g = 7'b0000000;
            4'h9:    a_to_g = 7'b0000100;
            4'hA:    a_to_g = 7'b0001000;
            4'hB:    a_to_g = 7'b1100000;
            4'hC:    a_to_g = 7'b0110001;
            4'hD:    a_to_g = 7'b1000010;
            4'hE:    a_to_g = 7'b0110000;
            4'hF:    a_to_g = 7'b0111000;
            default: a_to_g = 7'b0000001;
        endcase
    end

    always @(*) begin
        an = 4'b1111;
        if (aen[s] == 1) begin
            an[s] = 0;
        end
    end

    // 4. L�ptet? sz�ml�l� �rajelre �s t�rl�sre
    always @(posedge cclk or posedge clr) begin
        if (clr == 1)
            s <= 0;
        else
            s <= s + 1;
    end

endmodule
