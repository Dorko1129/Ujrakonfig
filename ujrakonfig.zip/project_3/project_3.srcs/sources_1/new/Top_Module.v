`timescale 1ns / 1ps

module Top_Module (
    input  wire        clk,        
    input  wire        BTNC,       
    input  wire [3:0]  btn,       
    input  wire [15:0] SW,         
    output wire [15:0] LED,      
    output wire [6:0]  a_to_g,     
    output wire [3:0]  AN,        
    output wire        DP        
);

    reg [15:0] clk_div = 16'd0;
    always @(posedge clk) begin
        clk_div <= clk_div + 1'b1;
    end
    wire cclk = clk_div[15];


    reg [24:0] cnt_3hz   = 0;
    reg [17:0] cnt_190hz = 0;
    reg        cnt_25mhz = 0;

    reg led_3hz   = 0;
    reg led_190hz = 0;
    reg led_25mhz = 0;

    always @(posedge clk or posedge BTNC) begin
        if (BTNC) begin
            cnt_3hz <= 0;
            led_3hz <= 0;
        end else if (cnt_3hz == 25'd16_666_666) begin
            cnt_3hz <= 0;
            led_3hz <= ~led_3hz;
        end else begin
            cnt_3hz <= cnt_3hz + 1'b1;
        end
    end

    always @(posedge clk or posedge BTNC) begin
        if (BTNC) begin
            cnt_190hz <= 0;
            led_190hz <= 0;
        end else if (cnt_190hz == 18'd263_157) begin
            cnt_190hz <= 0;
            led_190hz <= ~led_190hz;
        end else begin
            cnt_190hz <= cnt_190hz + 1'b1;
        end
    end

    always @(posedge clk or posedge BTNC) begin
        if (BTNC) begin
            cnt_25mhz <= 0;
            led_25mhz <= 0;
        end else if (cnt_25mhz == 1'b1) begin
            cnt_25mhz <= 0;
            led_25mhz <= ~led_25mhz;
        end else begin
            cnt_25mhz <= cnt_25mhz + 1'b1;
        end
    end


    assign LED[0] = led_3hz;
    assign LED[1] = led_190hz;
    assign LED[2] = led_25mhz;
    assign LED[15:3] = SW[15:3];


    wire [3:0] db_buttons;

    nyomogomb u_debouncer (
        .imp  (btn),
        .cclk (cclk),
        .clr  (BTNC),
        .outp (db_buttons)
    );


    wire [15:0] display_data = {8'h00, SW[7:0]};

    x7segb u_display (
        .x      (display_data),
        .cclk   (cclk),
        .clr    (BTNC),
        .a_to_g (a_to_g),
        .an     (AN),
        .dp     (DP)
    );

endmodule